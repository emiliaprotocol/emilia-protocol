// ../../../../../private/tmp/emilia-ccs-aeb.TjuCWa/extracted/emilia-ccs-l1-aeb-e94314ab/conformance/composition/ccs-l1-aeb-v1/run.mjs
import crypto13 from "node:crypto";
import { readFileSync, writeFileSync } from "node:fs";
import { dirname, resolve } from "node:path";
import { fileURLToPath } from "node:url";

// ../../../../../private/tmp/emilia-ccs-aeb.TjuCWa/extracted/emilia-ccs-l1-aeb-e94314ab/packages/verify/dist/aeb-adapter-contract.js
import crypto11 from "node:crypto";

// ../../../../../private/tmp/emilia-ccs-aeb.TjuCWa/extracted/emilia-ccs-l1-aeb-e94314ab/packages/verify/dist/evidence-chain.js
import crypto10 from "node:crypto";

// ../../../../../private/tmp/emilia-ccs-aeb.TjuCWa/extracted/emilia-ccs-l1-aeb-e94314ab/packages/verify/dist/index.js
import crypto8 from "crypto";

// ../../../../../private/tmp/emilia-ccs-aeb.TjuCWa/extracted/emilia-ccs-l1-aeb-e94314ab/packages/verify/dist/strict-json.js
var MAX_JSON_DEPTH = 64;
function hasUnpairedUtf16Surrogate(value) {
  for (let index = 0; index < value.length; index += 1) {
    const code = value.charCodeAt(index);
    if (code >= 55296 && code <= 56319) {
      const next = value.charCodeAt(index + 1);
      if (!(next >= 56320 && next <= 57343))
        return true;
      index += 1;
    } else if (code >= 56320 && code <= 57343) {
      return true;
    }
  }
  return false;
}
function strictJsonGate(raw2) {
  if (typeof raw2 !== "string")
    return { ok: false, reason: "JSON input must be text" };
  const input = raw2;
  if (hasUnpairedUtf16Surrogate(input)) {
    return { ok: false, reason: "unpaired Unicode surrogate" };
  }
  try {
    JSON.parse(input);
  } catch {
    return { ok: false, reason: "invalid JSON syntax" };
  }
  let index = 0;
  const stack = [];
  let reason = null;
  const escapes = { '"': '"', "\\": "\\", "/": "/", b: "\b", f: "\f", n: "\n", r: "\r", t: "	" };
  function readString() {
    index += 1;
    let output = "";
    while (index < input.length) {
      const character = input[index];
      if (character === '"') {
        index += 1;
        return output;
      }
      if (character !== "\\") {
        output += character;
        index += 1;
        continue;
      }
      const escape = input[index + 1];
      if (escape !== "u") {
        output += escapes[escape] ?? "";
        index += 2;
        continue;
      }
      const first = Number.parseInt(input.slice(index + 2, index + 6), 16);
      index += 6;
      if (first >= 55296 && first <= 56319) {
        if (input[index] === "\\" && input[index + 1] === "u") {
          const second = Number.parseInt(input.slice(index + 2, index + 6), 16);
          if (second >= 56320 && second <= 57343) {
            output += String.fromCharCode(first, second);
            index += 6;
            continue;
          }
        }
        reason = "unpaired high surrogate escape";
        return null;
      }
      if (first >= 56320 && first <= 57343) {
        reason = "unpaired low surrogate escape";
        return null;
      }
      output += String.fromCharCode(first);
    }
    reason = "unterminated string";
    return null;
  }
  while (index < input.length) {
    const character = input[index];
    if (character === "{") {
      stack.push({ object: true, keys: /* @__PURE__ */ new Set(), expectsKey: true });
      if (stack.length > MAX_JSON_DEPTH)
        return { ok: false, reason: `nesting depth exceeds ${MAX_JSON_DEPTH}` };
      index += 1;
    } else if (character === "[") {
      stack.push({ object: false });
      if (stack.length > MAX_JSON_DEPTH)
        return { ok: false, reason: `nesting depth exceeds ${MAX_JSON_DEPTH}` };
      index += 1;
    } else if (character === "}" || character === "]") {
      stack.pop();
      index += 1;
    } else if (character === ",") {
      const top = stack.at(-1);
      if (top?.object)
        top.expectsKey = true;
      index += 1;
    } else if (character === '"') {
      const top = stack.at(-1);
      const isKey = Boolean(top?.object && top.expectsKey);
      const value = readString();
      if (reason)
        return { ok: false, reason };
      if (isKey) {
        const frame = top;
        if (value === null)
          return { ok: false, reason: "invalid string member name" };
        if (frame.keys.has(value))
          return { ok: false, reason: "duplicate object member name" };
        frame.keys.add(value);
        frame.expectsKey = false;
      }
    } else {
      index += 1;
    }
  }
  return { ok: true };
}
function canonicalDomainError(path, reason) {
  return new TypeError(`value is outside the strict canonical JSON domain at ${path}: ${reason}`);
}
function countString(value, path, state) {
  state.stringBytes += new TextEncoder().encode(value).byteLength;
  if (state.stringBytes > state.maxStringBytes) {
    throw canonicalDomainError(path, `string bytes exceed ${state.maxStringBytes}`);
  }
}
function canonicalizeValue(value, path, ancestors, depth, state) {
  state.nodes += 1;
  if (state.nodes > state.maxNodes)
    throw canonicalDomainError(path, `node count exceeds ${state.maxNodes}`);
  if (depth > state.maxDepth)
    throw canonicalDomainError(path, `nesting depth exceeds ${state.maxDepth}`);
  if (value === null)
    return "null";
  if (typeof value === "string") {
    if (hasUnpairedUtf16Surrogate(value))
      throw canonicalDomainError(path, "unpaired Unicode surrogate");
    countString(value, path, state);
    return JSON.stringify(value);
  }
  if (typeof value === "boolean")
    return value ? "true" : "false";
  if (typeof value === "number") {
    if (!Number.isFinite(value) || state.safeIntegersOnly && !Number.isSafeInteger(value) || !state.safeIntegersOnly && Number.isInteger(value) && !Number.isSafeInteger(value)) {
      throw canonicalDomainError(path, state.safeIntegersOnly ? "numbers must be safe integers; encode other quantities as strings" : "numbers must be finite and integer values must be safe");
    }
    return JSON.stringify(value);
  }
  if (typeof value !== "object") {
    throw canonicalDomainError(path, `${typeof value} is not a JSON value`);
  }
  const object = value;
  if (ancestors.has(object))
    throw canonicalDomainError(path, "cyclic reference");
  ancestors.add(object);
  try {
    if (Array.isArray(value)) {
      const ownKeys2 = Reflect.ownKeys(value);
      if (ownKeys2.some((key) => typeof key !== "string")) {
        throw canonicalDomainError(path, "symbol members are not JSON");
      }
      const expectedKeys = /* @__PURE__ */ new Set(["length", ...Array.from({ length: value.length }, (_, index) => String(index))]);
      if (ownKeys2.length !== expectedKeys.size || ownKeys2.some((key) => !expectedKeys.has(key))) {
        throw canonicalDomainError(path, "sparse arrays and arrays with extra members are not permitted");
      }
      const entries = [];
      for (let index = 0; index < value.length; index += 1) {
        const descriptor = Object.getOwnPropertyDescriptor(value, String(index));
        if (!descriptor || !("value" in descriptor)) {
          throw canonicalDomainError(`${path}[${index}]`, "array holes and accessors are not permitted");
        }
        entries.push(canonicalizeValue(descriptor.value, `${path}[${index}]`, ancestors, depth + 1, state));
      }
      return `[${entries.join(",")}]`;
    }
    const prototype = Object.getPrototypeOf(value);
    if (prototype !== Object.prototype && prototype !== null) {
      throw canonicalDomainError(path, "only plain objects are permitted");
    }
    const ownKeys = Reflect.ownKeys(value);
    if (ownKeys.some((key) => typeof key !== "string")) {
      throw canonicalDomainError(path, "symbol members are not JSON");
    }
    const keys = ownKeys.sort();
    const members = [];
    for (const key of keys) {
      if (hasUnpairedUtf16Surrogate(key)) {
        throw canonicalDomainError(`${path}.${key}`, "member name contains an unpaired Unicode surrogate");
      }
      countString(key, `${path}.${key}`, state);
      const descriptor = Object.getOwnPropertyDescriptor(value, key);
      if (!descriptor || descriptor.enumerable !== true || !("value" in descriptor)) {
        throw canonicalDomainError(`${path}.${key}`, "non-enumerable members and accessors are not permitted");
      }
      members.push(`${JSON.stringify(key)}:${canonicalizeValue(descriptor.value, `${path}.${key}`, ancestors, depth + 1, state)}`);
    }
    return `{${members.join(",")}}`;
  } catch (error) {
    if (error instanceof TypeError && /strict canonical JSON domain/.test(error.message))
      throw error;
    throw canonicalDomainError(path, `object inspection failed: ${error instanceof Error ? error.message : String(error)}`);
  } finally {
    ancestors.delete(object);
  }
}
function canonicalizeStrictJson(value, limits = {}) {
  return canonicalizeJsonDomain(value, limits, true);
}
function canonicalizeFiniteJson(value, limits = {}) {
  return canonicalizeJsonDomain(value, limits, false);
}
function canonicalizeJsonDomain(value, limits, safeIntegersOnly) {
  const maxDepth = limits.maxDepth ?? MAX_JSON_DEPTH;
  const maxNodes = limits.maxNodes ?? Number.MAX_SAFE_INTEGER;
  const maxStringBytes = limits.maxStringBytes ?? Number.MAX_SAFE_INTEGER;
  if (!Number.isSafeInteger(maxDepth) || maxDepth < 0 || !Number.isSafeInteger(maxNodes) || maxNodes < 1 || !Number.isSafeInteger(maxStringBytes) || maxStringBytes < 0) {
    throw new TypeError("strict canonical JSON limits must be non-negative safe integers");
  }
  return canonicalizeValue(value, "$", /* @__PURE__ */ new Set(), 0, {
    nodes: 0,
    stringBytes: 0,
    maxDepth,
    maxNodes,
    maxStringBytes,
    safeIntegersOnly
  });
}
function isStrictCanonicalJson(value) {
  try {
    canonicalizeStrictJson(value);
    return true;
  } catch {
    return false;
  }
}

// ../../../../../private/tmp/emilia-ccs-aeb.TjuCWa/extracted/emilia-ccs-l1-aeb-e94314ab/packages/verify/dist/revocation.js
import crypto from "node:crypto";
var REVOCATION_VERSION = "EP-REVOCATION-v1";
var TARGET_TYPES = Object.freeze(["receipt", "commit", "delegation"]);
var RFC3339_INSTANT = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})(?:\.\d{1,9})?(?:Z|([+-])(\d{2}):(\d{2}))$/;
var STATEMENT_KEYS = /* @__PURE__ */ new Set([
  "@version",
  "target_type",
  "target_id",
  "action_hash",
  "revoker_id",
  "revoked_at",
  "reason",
  "proof"
]);
var PROOF_KEYS = /* @__PURE__ */ new Set([
  "algorithm",
  "revoker_key_id",
  "signature_b64u",
  "public_key"
]);
var FULL_REVOKER_KEY_ID = /^ep:revoker-key:sha256:[0-9a-f]{64}$/;
var LEGACY_REVOKER_KEY_ID = /^(?!ep:revoker-key:sha256:)[A-Za-z0-9._:#-]{1,128}$/;
var hexOf = (h) => {
  const s = String(h ?? "").replace(/^sha256:/, "").toLowerCase();
  return /^[0-9a-f]{64}$/.test(s) ? s : "";
};
function instantMs(value) {
  if (typeof value !== "string")
    return NaN;
  const match = value.match(RFC3339_INSTANT);
  if (!match)
    return NaN;
  const [, y, mo, d, h, mi, s, , oh, om] = match;
  const calendar = /* @__PURE__ */ new Date(0);
  calendar.setUTCFullYear(Number(y), Number(mo) - 1, Number(d));
  calendar.setUTCHours(Number(h), Number(mi), Number(s), 0);
  if (calendar.toISOString().slice(0, 19) !== `${y}-${mo}-${d}T${h}:${mi}:${s}`)
    return NaN;
  if (oh !== void 0 && (Number(oh) > 23 || Number(om) > 59))
    return NaN;
  return Date.parse(value);
}
function decisionTimeMs(value) {
  if (value === void 0)
    return Date.now();
  if (value instanceof Date)
    return value.getTime();
  if (typeof value === "number")
    return Number.isFinite(value) ? value : NaN;
  return instantMs(value);
}
function revocationSignedPayload(stmt) {
  return Buffer.from(canonicalize({
    "@version": REVOCATION_VERSION,
    action_hash: stmt.action_hash ?? null,
    reason: stmt.reason ?? null,
    revoked_at: stmt.revoked_at ?? null,
    revoker_id: stmt.revoker_id ?? null,
    target_id: stmt.target_id ?? null,
    target_type: stmt.target_type ?? null
  }), "utf8");
}
function verifyEd25519(bytes, publicKeyB64u, signatureB64u) {
  try {
    if (!bytes || !publicKeyB64u || !signatureB64u)
      return false;
    const key = crypto.createPublicKey({
      key: Buffer.from(String(publicKeyB64u), "base64url"),
      format: "der",
      type: "spki"
    });
    return crypto.verify(null, bytes, key, Buffer.from(String(signatureB64u), "base64url"));
  } catch {
    return false;
  }
}
function isWellFormedSignature(sigB64u) {
  try {
    return Buffer.from(String(sigB64u ?? ""), "base64url").length === 64;
  } catch {
    return false;
  }
}
function exactKeys(value, allowed) {
  return value !== null && typeof value === "object" && !Array.isArray(value) && Object.keys(value).length === allowed.size && Object.keys(value).every((key) => allowed.has(key));
}
function revokerKeyId(publicKeyB64u) {
  try {
    if (typeof publicKeyB64u !== "string" || publicKeyB64u.length === 0)
      return "";
    const der = Buffer.from(publicKeyB64u, "base64url");
    if (der.length === 0 || der.toString("base64url") !== publicKeyB64u)
      return "";
    const key = crypto.createPublicKey({ key: der, format: "der", type: "spki" });
    if (key.asymmetricKeyType !== "ed25519")
      return "";
    return `ep:revoker-key:sha256:${crypto.createHash("sha256").update(der).digest("hex")}`;
  } catch {
    return "";
  }
}
function isLegacyRevokerKeyId(value) {
  return typeof value === "string" && LEGACY_REVOKER_KEY_ID.test(value);
}
function verifyRevocation(target, statement2, opts = {}) {
  opts = opts && typeof opts === "object" ? opts : {};
  const revokerKeys = opts.revokerKeys || {};
  const checks = {
    version: true,
    structure: true,
    target_bound: true,
    revoker_key_pinned: true,
    revoker_key_bound: true,
    revoked_at_present: true,
    effective_at_or_before_T: true,
    revoker_signature_valid: true,
    signature_binds_statement: true
  };
  const errors = [];
  const fail3 = (key, msg) => {
    checks[key] = false;
    errors.push(msg);
  };
  if (!statement2 || typeof statement2 !== "object" || Array.isArray(statement2)) {
    fail3("signature_binds_statement", "no revocation statement presented (fail-closed)");
    fail3("revoker_signature_valid", "no revocation statement presented (fail-closed)");
    return { valid: false, checks, errors };
  }
  if (statement2["@version"] !== REVOCATION_VERSION) {
    fail3("version", `unsupported version: ${statement2["@version"]}`);
  }
  const proof = statement2.proof || null;
  if (!exactKeys(statement2, STATEMENT_KEYS) || !exactKeys(proof, PROOF_KEYS)) {
    fail3("structure", "revocation statement and proof must use the exact closed EP-REVOCATION-v1 schema");
  }
  if (!target || typeof target !== "object" || Array.isArray(target)) {
    fail3("target_bound", "no target handed to the verifier (fail-closed)");
  } else {
    const heldHash = hexOf(target.action_hash);
    const statementHash = hexOf(statement2.action_hash);
    if (!TARGET_TYPES.includes(target.target_type) || typeof target.target_id !== "string" || target.target_id.length === 0 || !heldHash) {
      fail3("target_bound", "handed target is incomplete or malformed");
    }
    if (!(typeof statement2.target_type === "string" && TARGET_TYPES.includes(statement2.target_type)) || typeof statement2.target_id !== "string" || statement2.target_id.length === 0 || !statementHash) {
      fail3("target_bound", "revocation statement target is incomplete or malformed");
    } else if (statement2.target_type !== target.target_type) {
      fail3("target_bound", `statement target_type "${statement2.target_type}" != handed "${target.target_type}"`);
    } else if (statement2.target_id !== target.target_id) {
      fail3("target_bound", `statement target_id "${statement2.target_id}" != handed "${target.target_id}"`);
    } else if (statementHash !== heldHash) {
      fail3("target_bound", `statement action_hash ${hexOf(statement2.action_hash)} != handed ${hexOf(target.action_hash)} (revoke-A-presented-for-B)`);
    }
  }
  const revokerId = statement2.revoker_id;
  const revokerIdValid = typeof revokerId === "string" && revokerId.length > 0;
  const pin = revokerIdValid && revokerKeys && typeof revokerKeys === "object" ? revokerKeys[revokerId] || {} : {};
  const pinned = pin.public_key;
  const presentedKey = proof?.public_key ?? null;
  if (!revokerIdValid) {
    fail3("revoker_key_pinned", "revoker_id must be a non-empty string");
  } else if (!pinned) {
    fail3("revoker_key_pinned", `no pinned key for revoker "${revokerId}" (identified but not trusted)`);
  } else if (typeof presentedKey !== "string" || presentedKey.length === 0 || pinned !== presentedKey) {
    fail3("revoker_key_pinned", `presented revoker key != pinned key for "${revokerId}" (key substitution)`);
  }
  const derivedKeyId = revokerKeyId(presentedKey);
  const proofKeyId = proof?.revoker_key_id;
  const fullProfile = FULL_REVOKER_KEY_ID.test(typeof proofKeyId === "string" ? proofKeyId : "") && proofKeyId === derivedKeyId && (pin.key_id === void 0 || pin.key_id === derivedKeyId);
  const legacyProfile = isLegacyRevokerKeyId(proofKeyId) && typeof presentedKey === "string" && presentedKey.length > 0 && pinned === presentedKey && (pin.key_id === void 0 || pin.key_id === proofKeyId);
  if (!derivedKeyId || !fullProfile && !legacyProfile) {
    fail3("revoker_key_bound", "revoker_key_id must be the full SPKI digest, or a historical v1 label bound to the exact pinned SPKI");
  }
  if (proof?.algorithm !== "Ed25519") {
    fail3("revoker_signature_valid", "revocation proof algorithm must be Ed25519");
  }
  if (statement2.reason !== void 0 && statement2.reason !== null && typeof statement2.reason !== "string") {
    fail3("signature_binds_statement", "reason must be a string or null");
  }
  const revokedAtMs = instantMs(statement2.revoked_at);
  if (!Number.isFinite(revokedAtMs)) {
    fail3("revoked_at_present", "revoked_at is absent or not a well-formed RFC 3339 instant");
  }
  const nowMs = decisionTimeMs(opts.now);
  if (!Number.isFinite(revokedAtMs) || !Number.isFinite(nowMs) || revokedAtMs > nowMs) {
    fail3("effective_at_or_before_T", "revoked_at must be a valid instant at or before the verifier decision time");
  }
  let recomputedBytes = null;
  try {
    recomputedBytes = revocationSignedPayload(statement2);
  } catch {
    recomputedBytes = null;
  }
  const signatureB64u = proof?.signature_b64u ?? null;
  const sigBindsPinned = pinned && recomputedBytes && verifyEd25519(recomputedBytes, pinned, signatureB64u);
  if (!sigBindsPinned) {
    const verifyKey = pinned || presentedKey;
    const sigOverRecomputed = verifyKey && recomputedBytes && verifyEd25519(recomputedBytes, verifyKey, signatureB64u);
    if (!signatureB64u || !verifyKey) {
      fail3("revoker_signature_valid", "revocation proof signature or key missing");
    } else if (!sigOverRecomputed && isWellFormedSignature(signatureB64u)) {
      fail3("signature_binds_statement", "revoker signature does not bind the presented statement bytes (recomputed payload mismatch)");
      fail3("revoker_signature_valid", "revoker signature does not verify under the pinned revoker key over the recomputed bytes");
    } else if (!sigOverRecomputed) {
      fail3("revoker_signature_valid", "revoker signature does not verify under the pinned revoker key");
    }
  }
  const valid = Object.values(checks).every(Boolean);
  return { valid, checks, errors };
}

// ../../../../../private/tmp/emilia-ccs-aeb.TjuCWa/extracted/emilia-ccs-l1-aeb-e94314ab/packages/verify/dist/effect-predicates.js
var PREDICATE_OPS = Object.freeze([
  "eq",
  // observed value is exactly the predicted string
  "lte",
  // observed decimal-string value <= predicted value
  "gte",
  // observed decimal-string value >= predicted value
  "range",
  // predicted min <= observed value <= predicted max
  "set_eq",
  // observed values (as a set) equal the predicted set
  "count_lte",
  // number of matching observed effects <= predicted value
  "absent"
  // NO observed effect may match (effect_type, target)
]);
var DIVERGENCE_OUTCOMES = Object.freeze([
  "in_bounds",
  "divergent",
  "incomparable"
]);
var OUTCOME_SOURCE_ROLES = Object.freeze([
  "executor",
  "system_of_record",
  "independent_observer"
]);
var ENTRY_KEYS = Object.freeze([
  "effect_type",
  "target",
  "predicate",
  "required_source_role",
  "required_source_class"
]);
var OBSERVED_ENTRY_KEYS = Object.freeze(["effect_type", "target", "value", "values"]);
var PREDICATE_KEYS = Object.freeze({
  eq: ["op", "value"],
  lte: ["op", "value"],
  gte: ["op", "value"],
  range: ["op", "min", "max"],
  set_eq: ["op", "values"],
  count_lte: ["op", "value"],
  absent: ["op"]
});

// ../../../../../private/tmp/emilia-ccs-aeb.TjuCWa/extracted/emilia-ccs-l1-aeb-e94314ab/packages/verify/dist/agentroa.js
var RESULT_BASE = Object.freeze({
  valid: false,
  verified: false,
  action_digest: null,
  decision: null,
  pre_execution: false,
  execution_proven: false,
  enforcement_mode: null,
  chain_depth: null
});

// ../../../../../private/tmp/emilia-ccs-aeb.TjuCWa/extracted/emilia-ccs-l1-aeb-e94314ab/packages/verify/dist/authority-program.js
var MAX_INPUT_STRING_BYTES = 1024 * 1024;

// ../../../../../private/tmp/emilia-ccs-aeb.TjuCWa/extracted/emilia-ccs-l1-aeb-e94314ab/packages/verify/dist/aeb-execution-conditions.js
var AEB_EXECUTION_CONDITIONS_SCOPE = Object.freeze({
  decision_scope: "execution_conditions_only",
  authorization_established: false,
  physical_truth_established: false,
  prevention_capable_strengths: Object.freeze(["compare-and-set", "provider-enforced"])
});

// ../../../../../private/tmp/emilia-ccs-aeb.TjuCWa/extracted/emilia-ccs-l1-aeb-e94314ab/packages/verify/vendor/caid.mjs
import { createHash } from "node:crypto";
var CAID_VERSION = "1";
var SUPPORTED_SUITES = /* @__PURE__ */ new Set(["jcs-sha256"]);
var TYPE_SEGMENT_RE = /^[a-z][a-z0-9-]*$/;
var TYPE_VERSION_RE = /^[1-9][0-9]*$/;
var AMOUNT_RE = /^-?(0|[1-9][0-9]*)(\.[0-9]+)?$/;
var DIGEST_FIELD_RE = /^sha256:[0-9a-f]{64}$/;
var TIMESTAMP_RE = /^([0-9]{4})-(0[1-9]|1[0-2])-(0[1-9]|[12][0-9]|3[01])T([01][0-9]|2[0-3]):[0-5][0-9]:[0-5][0-9](\.[0-9]+)?Z$/;
function isPlainObject(v) {
  return typeof v === "object" && v !== null && !Array.isArray(v);
}
function isValidActionType(t) {
  if (typeof t !== "string") return false;
  const segments = t.split(".");
  if (segments.length < 2) return false;
  const version = segments[segments.length - 1];
  if (!TYPE_VERSION_RE.test(version)) return false;
  for (let i = 0; i < segments.length - 1; i++) {
    if (!TYPE_SEGMENT_RE.test(segments[i])) return false;
  }
  return true;
}
function daysInMonth(year, month) {
  if (month === 2) {
    const leap = year % 4 === 0 && year % 100 !== 0 || year % 400 === 0;
    return leap ? 29 : 28;
  }
  return [4, 6, 9, 11].includes(month) ? 30 : 31;
}
function isValidTimestamp(s) {
  const m = TIMESTAMP_RE.exec(s);
  if (!m) return false;
  const year = Number(m[1]);
  const month = Number(m[2]);
  const day = Number(m[3]);
  return day <= daysInMonth(year, month);
}
function resolveDefinition(actionType, definitions) {
  if (!Array.isArray(definitions)) return null;
  for (const entry of definitions) {
    if (isPlainObject(entry) && entry.action_type === actionType) return entry;
  }
  return null;
}
function canonicalize2(value) {
  const refusals = [];
  const canonical2 = serialize(value, refusals);
  if (refusals.length > 0) {
    return { ok: false, refusals: dedupe(refusals) };
  }
  return { ok: true, canonical: canonical2 };
}
function serialize(v, refusals) {
  if (v === null) return "null";
  const t = typeof v;
  if (t === "boolean") return v ? "true" : "false";
  if (t === "number") {
    if (!Number.isFinite(v) || !Number.isInteger(v) || Math.abs(v) > Number.MAX_SAFE_INTEGER) {
      refusals.push("unsupported_number");
      return "";
    }
    return JSON.stringify(v);
  }
  if (t === "string") return JSON.stringify(v);
  if (Array.isArray(v)) {
    return "[" + v.map((x) => serialize(x, refusals)).join(",") + "]";
  }
  if (t === "object") {
    const keys = Object.keys(v).sort();
    const parts = keys.map(
      (k) => JSON.stringify(k) + ":" + serialize(v[k], refusals)
    );
    return "{" + parts.join(",") + "}";
  }
  refusals.push("unsupported_value");
  return "";
}
function dedupe(arr) {
  return [...new Set(arr)];
}
function fieldList(def, key) {
  return Array.isArray(def[key]) ? def[key].filter(isPlainObject) : [];
}
function validateAgainstDefinition(obj, def) {
  const refusals = [];
  const required = fieldList(def, "required_fields");
  const optional = fieldList(def, "optional_fields");
  for (const f of required) {
    if (typeof f.name !== "string") continue;
    if (!(f.name in obj) || obj[f.name] === void 0) {
      refusals.push("missing_material_field:" + f.name);
    }
  }
  for (const f of [...required, ...optional]) {
    if (typeof f.name !== "string") continue;
    if (!(f.name in obj) || obj[f.name] === void 0) continue;
    const code = checkFieldType(obj[f.name], f);
    if (code) refusals.push(code + ":" + f.name);
  }
  return refusals;
}
function checkFieldType(value, field) {
  switch (field.type) {
    case "string":
      return typeof value === "string" ? null : "mistyped_field";
    case "amount-string":
      if (typeof value !== "string") return "mistyped_field";
      return AMOUNT_RE.test(value) ? null : "invalid_amount";
    case "digest":
      if (typeof value !== "string") return "mistyped_field";
      return DIGEST_FIELD_RE.test(value) ? null : "mistyped_field";
    case "enum":
      if (typeof value !== "string") return "mistyped_field";
      if (Array.isArray(field.values) && !field.values.includes(value)) {
        return "mistyped_field";
      }
      return null;
    case "timestamp":
      if (typeof value !== "string") return "mistyped_field";
      return isValidTimestamp(value) ? null : "mistyped_field";
    case "integer":
      return typeof value === "number" && Number.isInteger(value) ? null : "mistyped_field";
    case "boolean":
      return typeof value === "boolean" ? null : "mistyped_field";
    case "object":
      return isPlainObject(value) ? null : "mistyped_field";
    case "array":
      return Array.isArray(value) ? null : "mistyped_field";
    default:
      return "mistyped_field";
  }
}
function sha256(canonical2) {
  return createHash("sha256").update(Buffer.from(canonical2, "utf8")).digest();
}
function computeCaid(actionObject, options) {
  const opts = isPlainObject(options) ? options : {};
  if (!isPlainObject(actionObject)) {
    return { refusals: ["invalid_action_type"] };
  }
  const actionType = actionObject.action_type;
  if (!isValidActionType(actionType)) {
    return { refusals: ["invalid_action_type"] };
  }
  const def = resolveDefinition(actionType, opts.definitions);
  if (def === null) {
    return { refusals: ["unknown_action_type"] };
  }
  const refusals = [];
  refusals.push(...validateAgainstDefinition(actionObject, def));
  const suite = opts.suite;
  if (!SUPPORTED_SUITES.has(suite)) {
    refusals.push("unknown_suite");
  }
  const canon = canonicalize2(actionObject);
  if (!canon.ok) {
    refusals.push(...canon.refusals);
  }
  if (refusals.length > 0) {
    return { refusals };
  }
  const okCanon = (
    /** @type {{ok: true, canonical: string}} */
    canon
  );
  const digestBytes2 = sha256(okCanon.canonical);
  const b64 = digestBytes2.toString("base64url");
  return {
    caid: `caid:${CAID_VERSION}:${actionType}:${suite}:${b64}`,
    digest: "sha256:" + digestBytes2.toString("hex")
  };
}

// ../../../../../private/tmp/emilia-ccs-aeb.TjuCWa/extracted/emilia-ccs-l1-aeb-e94314ab/packages/verify/dist/aeb-consequence-conformance.js
var AEB_CONSEQUENCE_LOCAL_ATOMIC_SCOPE = Object.freeze({
  profile: "local_atomic",
  guarantees: Object.freeze([
    "one_linearizable_local_admission_domain",
    "operation_and_native_replay_reserved_before_invocation",
    "execution_authority_consumed_before_provider_entry"
  ]),
  exclusions: Object.freeze([
    "remote_atomicity",
    "federated_atomicity",
    "provider_commitment",
    "observed_effect_truth",
    "downstream_exactly_once"
  ])
});
var AEB_CONSEQUENCE_LIMITS = Object.freeze({
  max_string_bytes: 4096,
  max_depth: 32,
  max_nodes: 65536,
  max_document_bytes: 1048576,
  max_evidence: 16,
  max_requirements: 16,
  max_prior_operations: 64,
  max_replay_units: 128,
  max_vectors: 256,
  max_reasons: 32
});
var AEB_CONSEQUENCE_REASONS = Object.freeze([
  "authenticated_reconciliation",
  "blind_retry_refused",
  "distinct_principal_quorum_unsatisfied",
  "evidence_revoked",
  "evidence_stale",
  "exact_action_mismatch",
  "executor_self_approval_refused",
  "initiator_self_approval_refused",
  "local_atomic_reservation_unavailable",
  "local_policy_denied",
  "native_evidence_replay",
  "native_verification_failed",
  "native_verification_indeterminate",
  "normalized_action_mismatch",
  "operation_binding_mismatch",
  "operation_replay",
  "provider_and_effect_indeterminate",
  "provider_committed_effect_diverged",
  "provider_committed_effect_observed",
  "provider_proven_not_committed",
  "reconciliation_binding_mismatch",
  "reconciliation_indeterminate",
  "required_role_unsatisfied",
  "status_authority_not_pinned",
  "status_unavailable",
  "timeout_after_dispatch",
  "unauthenticated_reconciliation"
]);
var RESULT_KEYS = Object.freeze([
  "verification",
  "acceptance",
  "action_match",
  "satisfaction",
  "authorization",
  "reservation",
  "custody",
  "provider_outcome",
  "effect_relation",
  "retry",
  "reconciliation",
  "decision",
  "reasons"
]);

// ../../../../../private/tmp/emilia-ccs-aeb.TjuCWa/extracted/emilia-ccs-l1-aeb-e94314ab/packages/verify/dist/discovery-permit-contract.js
var DISCOVERY_PERMIT_RESOLVER_ATTESTATION_VERSION = "EP-DISCOVERY-PERMIT-RESOLVER-ATTESTATION-v1";
var DISCOVERY_PERMIT_RESOLVER_ATTESTATION_DOMAIN = `${DISCOVERY_PERMIT_RESOLVER_ATTESTATION_VERSION}\0`;
var DISCOVERY_KEYS = /* @__PURE__ */ new Set([
  "@type",
  "source",
  "schema_digests",
  "mapping_digest",
  "status",
  "issued_at"
]);
var BINDING_KEYS = /* @__PURE__ */ new Set([
  ...DISCOVERY_KEYS,
  "caid",
  "action_digest"
]);

// ../../../../../private/tmp/emilia-ccs-aeb.TjuCWa/extracted/emilia-ccs-l1-aeb-e94314ab/packages/verify/dist/aeb-discovery-permit-adapter.js
var ZERO_DIGEST = `sha256:${"0".repeat(64)}`;

// ../../../../../private/tmp/emilia-ccs-aeb.TjuCWa/extracted/emilia-ccs-l1-aeb-e94314ab/packages/verify/dist/aeb-wimse-oauth-adapter.js
var WIMSE_HTTP_SIGNATURE_REVISION = "draft-ietf-wimse-http-signature-03";
var WIMSE_WORKLOAD_CREDS_REVISION = "draft-ietf-wimse-workload-creds-01";
var WIMSE_WPT_REVISION = "draft-ietf-wimse-wpt-01";
var OAUTH_TRANSACTION_TOKENS_REVISION = "draft-ietf-oauth-transaction-tokens-08";
var SPT_TRANSACTION_TOKENS_REVISION = "draft-coetzee-oauth-spt-txn-tokens-03";
var SOURCE_REVISIONS = Object.freeze([
  WIMSE_HTTP_SIGNATURE_REVISION,
  WIMSE_WORKLOAD_CREDS_REVISION,
  WIMSE_WPT_REVISION,
  OAUTH_TRANSACTION_TOKENS_REVISION,
  SPT_TRANSACTION_TOKENS_REVISION
]);
var REQUIRED_HTTP_COMPONENTS = Object.freeze([
  "@method",
  "@request-target",
  "content-digest",
  "txn-token",
  "workload-identity-token"
]);

// ../../../../../private/tmp/emilia-ccs-aeb.TjuCWa/extracted/emilia-ccs-l1-aeb-e94314ab/packages/verify/dist/oauth-rar-authorization-binding.js
var OAUTH_RAR_AUTHORIZATION_BINDING_VERSION = "EP-OAUTH-RAR-AUTHORIZATION-BINDING-v1";
var REQUIRED_KEYS = /* @__PURE__ */ new Set([
  "profile",
  "authorization_server",
  "transaction_id",
  "actor",
  "authorization_details_digest",
  "action_mapping_profile"
]);
var ALLOWED_KEYS = /* @__PURE__ */ new Set([...REQUIRED_KEYS, "delegated_subject"]);
var DIGEST_RE = /^sha256:[0-9a-f]{64}$/;
function dataRecord(value) {
  if (value === null || typeof value !== "object" || Array.isArray(value))
    return null;
  try {
    const prototype = Object.getPrototypeOf(value);
    if (prototype !== Object.prototype && prototype !== null)
      return null;
    const descriptors = Object.getOwnPropertyDescriptors(value);
    const keys = Reflect.ownKeys(descriptors);
    if (keys.some((key) => typeof key !== "string"))
      return null;
    const record2 = {};
    for (const key of keys) {
      const descriptor = descriptors[key];
      if (!descriptor.enumerable || !Object.hasOwn(descriptor, "value"))
        return null;
      record2[key] = descriptor.value;
    }
    return record2;
  } catch {
    return null;
  }
}
function nonEmptyString(value) {
  return typeof value === "string" && value.length > 0 && !/[\u0000-\u001f\u007f]/.test(value);
}
function absoluteUri(value) {
  if (!nonEmptyString(value))
    return false;
  try {
    return new URL(value).protocol.length > 1;
  } catch {
    return false;
  }
}
function parseOAuthRarAuthorizationBinding(value) {
  const record2 = dataRecord(value);
  if (!record2)
    return null;
  const keys = Object.keys(record2);
  if (!keys.every((key) => ALLOWED_KEYS.has(key)) || ![...REQUIRED_KEYS].every((key) => Object.hasOwn(record2, key)) || record2.profile !== OAUTH_RAR_AUTHORIZATION_BINDING_VERSION || !absoluteUri(record2.authorization_server) || !nonEmptyString(record2.transaction_id) || !nonEmptyString(record2.actor) || !absoluteUri(record2.action_mapping_profile) || typeof record2.authorization_details_digest !== "string" || !DIGEST_RE.test(record2.authorization_details_digest) || record2.delegated_subject !== void 0 && !nonEmptyString(record2.delegated_subject)) {
    return null;
  }
  const normalized = {
    profile: OAUTH_RAR_AUTHORIZATION_BINDING_VERSION,
    authorization_server: record2.authorization_server,
    transaction_id: record2.transaction_id,
    actor: record2.actor,
    authorization_details_digest: record2.authorization_details_digest,
    action_mapping_profile: record2.action_mapping_profile
  };
  if (record2.delegated_subject !== void 0) {
    normalized.delegated_subject = record2.delegated_subject;
  }
  return normalized;
}
function matchOAuthRarAuthorizationBinding(presented, expected) {
  const actual = parseOAuthRarAuthorizationBinding(presented);
  if (!actual) {
    return { verdict: "MISMATCH", binding: null, reason: "oauth_rar_binding_malformed" };
  }
  const independentlyDerived = parseOAuthRarAuthorizationBinding(expected);
  if (!independentlyDerived) {
    return {
      verdict: "INDETERMINATE",
      binding: null,
      reason: "native_oauth_rar_binding_unavailable"
    };
  }
  try {
    if (canonicalize3(actual) !== canonicalize3(independentlyDerived)) {
      return { verdict: "MISMATCH", binding: null, reason: "oauth_rar_binding_mismatch" };
    }
  } catch {
    return { verdict: "MISMATCH", binding: null, reason: "oauth_rar_binding_malformed" };
  }
  return { verdict: "MATCH", binding: independentlyDerived, reason: null };
}
var oauth_rar_authorization_binding_default = Object.freeze({
  OAUTH_RAR_AUTHORIZATION_BINDING_VERSION,
  parseOAuthRarAuthorizationBinding,
  matchOAuthRarAuthorizationBinding
});

// ../../../../../private/tmp/emilia-ccs-aeb.TjuCWa/extracted/emilia-ccs-l1-aeb-e94314ab/packages/verify/dist/orprg.js
var ORPRG_JSON_JCS_PROFILE = "ORPRG-JSON-JCS-ED25519-v1";
var MAX_JSON_DEPTH2 = 64;
var MAX_JSON_NODES = 5e4;
var MAX_JSON_STRING_BYTES = 1024 * 1024;
var MAX_WIRE_BYTES = 2 * 1024 * 1024;
var HASH = /^sha256:[0-9a-f]{64}$/;
var B64URL = /^[A-Za-z0-9_-]+$/;
var EFFECT_TYPE = /^[a-z][a-z0-9._:-]{0,127}$/;
var UNIT = /^[A-Za-z][A-Za-z0-9._:/-]{0,63}$/;
var NONCE = /^[A-Za-z0-9._~-]{16,128}$/;
var RFC3339_UTC = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})(?:\.(\d{1,3}))?Z$/;
var RECEIPT_KEYS = /* @__PURE__ */ new Set(["@version", "receipt_core", "status", "authenticity"]);
var CORE_KEYS = /* @__PURE__ */ new Set([
  "policy_digest",
  "epoch_id",
  "valid_from",
  "valid_to",
  "action_digest",
  "canonicalization_profile",
  "scope",
  "anti_replay"
]);
var SCOPE_KEYS = /* @__PURE__ */ new Set([
  "effect_type",
  "interface_id",
  "target_id",
  "tenant_id",
  "purpose_id",
  "jurisdiction",
  "audience",
  "budget"
]);
var REQUIRED_SCOPE_KEYS = /* @__PURE__ */ new Set(["effect_type", "interface_id", "target_id", "audience"]);
var BUDGET_KEYS = /* @__PURE__ */ new Set(["unit", "limit"]);
var ANTI_REPLAY_KEYS = /* @__PURE__ */ new Set(["mode", "nonce"]);
var STATUS_KEYS = /* @__PURE__ */ new Set(["state", "checked_at", "next_update"]);
var AUTHENTICITY_KEYS = /* @__PURE__ */ new Set(["issuer_id", "key_id", "algorithm", "signature"]);
var ACTION_KEYS = /* @__PURE__ */ new Set([
  "effect_type",
  "interface_id",
  "target_id",
  "tenant_id",
  "purpose_id",
  "jurisdiction",
  "audience",
  "budget",
  "request"
]);
var REQUIRED_ACTION_KEYS = /* @__PURE__ */ new Set([
  "effect_type",
  "interface_id",
  "target_id",
  "audience",
  "request"
]);
var ACTION_BUDGET_KEYS = /* @__PURE__ */ new Set(["unit", "amount"]);
var STATUS_STATES = /* @__PURE__ */ new Set(["good", "revoked", "unknown"]);
function isRecord(value) {
  if (value === null || typeof value !== "object" || Array.isArray(value))
    return false;
  const prototype = Object.getPrototypeOf(value);
  return prototype === Object.prototype || prototype === null;
}
function hasExactKeys(value, allowed, required = allowed) {
  if (!isRecord(value))
    return false;
  const keys = Object.keys(value);
  return keys.every((key) => allowed.has(key)) && [...required].every((key) => Object.hasOwn(value, key));
}
function validUnicodeString(value) {
  if (typeof value !== "string")
    return false;
  for (let index = 0; index < value.length; index++) {
    const unit = value.charCodeAt(index);
    if (unit >= 55296 && unit <= 56319) {
      const next = value.charCodeAt(++index);
      if (!(next >= 56320 && next <= 57343))
        return false;
    } else if (unit >= 56320 && unit <= 57343) {
      return false;
    }
  }
  return true;
}
function validText(value, maximum = 512) {
  return validUnicodeString(value) && value.length > 0 && value.length <= maximum && !/[\u0000-\u001f\u007f]/.test(value);
}
function validEpoch(value) {
  return typeof value === "string" && validText(value, 128) || Number.isSafeInteger(value) && value >= 0;
}
function validBudgetUnit(value) {
  return typeof value === "string" && UNIT.test(value);
}
function validJurisdictions(value) {
  if (!Array.isArray(value) || value.length === 0 || value.length > 32)
    return false;
  if (!value.every((entry) => validText(entry, 64)))
    return false;
  const sorted = [...value].sort();
  return sorted.every((entry, index) => entry === value[index] && (index === 0 || entry !== value[index - 1]));
}
function canonicalJsonSafety(value) {
  try {
    canonicalizeStrictJson(value, {
      maxDepth: MAX_JSON_DEPTH2,
      maxNodes: MAX_JSON_NODES,
      maxStringBytes: MAX_JSON_STRING_BYTES
    });
    return true;
  } catch {
    return false;
  }
}
function canonicalizeJcs(value) {
  try {
    return canonicalizeStrictJson(value, {
      maxDepth: MAX_JSON_DEPTH2,
      maxNodes: MAX_JSON_NODES,
      maxStringBytes: MAX_JSON_STRING_BYTES
    });
  } catch {
    return null;
  }
}
function parseInstant(value) {
  if (typeof value !== "string")
    return NaN;
  const match = value.match(RFC3339_UTC);
  if (!match)
    return NaN;
  const [, year, month, day, hour, minute, second] = match;
  const calendar = /* @__PURE__ */ new Date(0);
  calendar.setUTCFullYear(Number(year), Number(month) - 1, Number(day));
  calendar.setUTCHours(Number(hour), Number(minute), Number(second), 0);
  if (calendar.toISOString().slice(0, 19) !== `${year}-${month}-${day}T${hour}:${minute}:${second}`) {
    return NaN;
  }
  const parsed = Date.parse(value);
  return Number.isFinite(parsed) ? parsed : NaN;
}
function decodeCanonicalBase64url(value, expectedLength) {
  if (typeof value !== "string" || !B64URL.test(value))
    return null;
  try {
    const bytes = Buffer.from(value, "base64url");
    if (bytes.toString("base64url") !== value)
      return null;
    if (expectedLength !== void 0 && bytes.length !== expectedLength)
      return null;
    return bytes;
  } catch {
    return null;
  }
}
function actionShapeValid(action) {
  if (!hasExactKeys(action, ACTION_KEYS, REQUIRED_ACTION_KEYS))
    return false;
  if (typeof action.effect_type !== "string" || !EFFECT_TYPE.test(action.effect_type))
    return false;
  for (const field of ["interface_id", "target_id", "audience"]) {
    if (!validText(action[field]))
      return false;
  }
  for (const field of ["tenant_id", "purpose_id"]) {
    if (Object.hasOwn(action, field) && !validText(action[field]))
      return false;
  }
  if (Object.hasOwn(action, "jurisdiction") && !validJurisdictions(action.jurisdiction))
    return false;
  if (!isRecord(action.request))
    return false;
  if (Object.hasOwn(action, "budget")) {
    if (!hasExactKeys(action.budget, ACTION_BUDGET_KEYS))
      return false;
    if (!validBudgetUnit(action.budget.unit))
      return false;
    if (!Number.isSafeInteger(action.budget.amount) || action.budget.amount < 0)
      return false;
  }
  return canonicalJsonSafety(action);
}
function scopeShapeValid(scope) {
  if (!hasExactKeys(scope, SCOPE_KEYS, REQUIRED_SCOPE_KEYS))
    return false;
  if (typeof scope.effect_type !== "string" || !EFFECT_TYPE.test(scope.effect_type))
    return false;
  for (const field of ["interface_id", "target_id", "audience"]) {
    if (!validText(scope[field]))
      return false;
  }
  for (const field of ["tenant_id", "purpose_id"]) {
    if (Object.hasOwn(scope, field) && !validText(scope[field]))
      return false;
  }
  if (Object.hasOwn(scope, "jurisdiction") && !validJurisdictions(scope.jurisdiction))
    return false;
  if (Object.hasOwn(scope, "budget")) {
    if (!hasExactKeys(scope.budget, BUDGET_KEYS))
      return false;
    if (!validBudgetUnit(scope.budget.unit))
      return false;
    if (!Number.isSafeInteger(scope.budget.limit) || scope.budget.limit < 0)
      return false;
  }
  return true;
}
function receiptShapeValid(receipt) {
  if (!hasExactKeys(receipt, RECEIPT_KEYS))
    return false;
  if (receipt["@version"] !== ORPRG_JSON_JCS_PROFILE)
    return false;
  if (!hasExactKeys(receipt.receipt_core, CORE_KEYS))
    return false;
  if (!hasExactKeys(receipt.status, STATUS_KEYS))
    return false;
  if (!hasExactKeys(receipt.authenticity, AUTHENTICITY_KEYS))
    return false;
  const core = receipt.receipt_core;
  if (!HASH.test(core.policy_digest) || !validEpoch(core.epoch_id))
    return false;
  if (!HASH.test(core.action_digest))
    return false;
  if (!validText(core.canonicalization_profile, 128))
    return false;
  if (!scopeShapeValid(core.scope))
    return false;
  if (!hasExactKeys(core.anti_replay, ANTI_REPLAY_KEYS))
    return false;
  if (core.anti_replay.mode !== "single-use" || typeof core.anti_replay.nonce !== "string" || !NONCE.test(core.anti_replay.nonce))
    return false;
  if (!STATUS_STATES.has(receipt.status.state))
    return false;
  if (!Number.isFinite(parseInstant(core.valid_from)) || !Number.isFinite(parseInstant(core.valid_to)) || !Number.isFinite(parseInstant(receipt.status.checked_at)) || !Number.isFinite(parseInstant(receipt.status.next_update)))
    return false;
  const authenticity = receipt.authenticity;
  if (!validText(authenticity.issuer_id, 1024) || !validText(authenticity.key_id, 256) || authenticity.algorithm !== "Ed25519" || decodeCanonicalBase64url(authenticity.signature, 64) === null)
    return false;
  return canonicalJsonSafety(receipt);
}
function sameOptionalField(scope, action, field) {
  const scopeHas = Object.hasOwn(scope, field);
  const actionHas = Object.hasOwn(action, field);
  if (scopeHas !== actionHas)
    return false;
  if (!scopeHas)
    return true;
  const left = canonicalizeJcs(scope[field]);
  const right = canonicalizeJcs(action[field]);
  return left !== null && left === right;
}
function scopeMatchesAction(scope, action, requireBudget) {
  if (scope.effect_type !== action.effect_type || scope.interface_id !== action.interface_id || scope.target_id !== action.target_id || scope.audience !== action.audience)
    return false;
  for (const field of ["tenant_id", "purpose_id", "jurisdiction"]) {
    if (!sameOptionalField(scope, action, field))
      return false;
  }
  const receiptHasBudget = Object.hasOwn(scope, "budget");
  const actionHasBudget = Object.hasOwn(action, "budget");
  if (receiptHasBudget !== actionHasBudget)
    return false;
  if (requireBudget === true && !receiptHasBudget)
    return false;
  if (!receiptHasBudget)
    return true;
  return scope.budget.unit === action.budget.unit && action.budget.amount <= scope.budget.limit;
}
function signedPayload(receipt) {
  return {
    "@version": receipt["@version"],
    receipt_core: receipt.receipt_core,
    status: receipt.status,
    authenticity: {
      issuer_id: receipt.authenticity.issuer_id,
      key_id: receipt.authenticity.key_id,
      algorithm: receipt.authenticity.algorithm
    }
  };
}
var __orprgSecurityInternals = Object.freeze({
  validUnicodeString,
  canonicalJsonSafety,
  canonicalizeJcs,
  parseInstant,
  actionShapeValid,
  scopeShapeValid,
  receiptShapeValid,
  scopeMatchesAction,
  signedPayload
});

// ../../../../../private/tmp/emilia-ccs-aeb.TjuCWa/extracted/emilia-ccs-l1-aeb-e94314ab/packages/verify/dist/aeb-psea-adapter.js
var REQUIRED_CLAIMS = /* @__PURE__ */ new Set([
  "jti",
  "aud",
  "iss",
  "iat",
  "exp",
  "ueid",
  "eat_profile",
  "psea_tier",
  "psea_op",
  "psea_counter",
  "psea_payload_hash",
  "psea_uv",
  "psea_proof_version"
]);
var OPTIONAL_CLAIMS = /* @__PURE__ */ new Set([
  "eat_nonce",
  "submods",
  "psea_chain_prev",
  "psea_caller_package",
  "psea_sdk_version",
  "psea_user_hash",
  "psea_chain_pending",
  "psea_last_confirmed_head",
  "psea_rp_context_hash"
]);
var CLAIM_KEYS = /* @__PURE__ */ new Set([...REQUIRED_CLAIMS, ...OPTIONAL_CLAIMS]);

// ../../../../../private/tmp/emilia-ccs-aeb.TjuCWa/extracted/emilia-ccs-l1-aeb-e94314ab/packages/verify/dist/fido-ap2-bridge.js
var FIDO_AP2_SOURCE_REVISION = "google-agentic-commerce/AP2@e1ea56db72a6385bce3e5c1112b3a56ce60acb43";
var FIDO_AP2_CAID_MAPPER_ID = "mapper:fido-ap2-closed-payment-v1";
var FIDO_AP2_ACTION_TYPE = "payment.purchase.1";
var FLAG_UP = 1;
var FLAG_UV = 4;
var FLAG_BE = 8;
var FLAG_BS = 16;
var ALLOWED_ASSERTION_FLAGS = FLAG_UP | FLAG_UV | FLAG_BE | FLAG_BS;
var MAX_NATIVE_SOURCE_BYTES = 8 * 1024 * 1024;
var MAX_CLIENT_DATA_BYTES = 8 * 1024;
var FIDO_AP2_CAID_ACTION_DEFINITIONS = Object.freeze([Object.freeze({
  action_type: FIDO_AP2_ACTION_TYPE,
  required_fields: Object.freeze([
    Object.freeze({ name: "checkout_mandate_digest", type: "digest" }),
    Object.freeze({ name: "payment_mandate_digest", type: "digest" }),
    Object.freeze({ name: "checkout_payload_jwt_digest", type: "digest" }),
    Object.freeze({ name: "transaction_id", type: "string" }),
    Object.freeze({ name: "amount_minor", type: "integer" }),
    Object.freeze({ name: "currency", type: "string" }),
    Object.freeze({ name: "payee_id", type: "string" }),
    Object.freeze({ name: "payee_name", type: "string" }),
    Object.freeze({ name: "payee_website_digest", type: "digest" }),
    Object.freeze({ name: "pisp_digest", type: "digest" }),
    Object.freeze({ name: "payment_instrument_id", type: "string" }),
    Object.freeze({ name: "payment_instrument_type", type: "string" }),
    Object.freeze({ name: "payment_instrument_description_digest", type: "digest" }),
    Object.freeze({ name: "risk_data_digest", type: "digest" }),
    Object.freeze({ name: "execution", type: "enum", values: Object.freeze(["immediate"]) }),
    Object.freeze({ name: "source_expires_at", type: "timestamp" })
  ]),
  optional_fields: Object.freeze([])
})]);
var FIDO_AP2_CAID_RESOLVER_DESCRIPTOR = Object.freeze({
  mapper_id: FIDO_AP2_CAID_MAPPER_ID,
  version: "1",
  source_revision: FIDO_AP2_SOURCE_REVISION,
  projection: "ap2-v0.2-closed-checkout-payment-immediate-v1",
  action_type: FIDO_AP2_ACTION_TYPE,
  suite: "jcs-sha256",
  definitions: FIDO_AP2_CAID_ACTION_DEFINITIONS
});

// ../../../../../private/tmp/emilia-ccs-aeb.TjuCWa/extracted/emilia-ccs-l1-aeb-e94314ab/packages/verify/dist/a2a-receipt-binding.js
var A2A_RECEIPT_BINDING_VERSION = "EP-A2A-RECEIPT-BINDING-v1";
var A2A_RECEIPT_BINDING_DOMAIN = `${A2A_RECEIPT_BINDING_VERSION}\0`;

// ../../../../../private/tmp/emilia-ccs-aeb.TjuCWa/extracted/emilia-ccs-l1-aeb-e94314ab/packages/verify/dist/memory-projection.js
import crypto2 from "node:crypto";
var MEMORY_PROJECTION_RECORD_VERSION = "MEMORY-PROJECTION-RECORD-v1";
var MEMORY_PROJECTION_RECORD_DOMAIN = "MEMORY-PROJECTION-RECORD-v1\0";
var MEMORY_PROJECTION_NONCLAIMS = Object.freeze({
  model_use: "NOT_ESTABLISHED",
  action_linkage: "NOT_ESTABLISHED",
  action_authorization: "NOT_ESTABLISHED",
  execution_outcome: "NOT_ESTABLISHED"
});
var MemoryProjectionVerificationError = class extends Error {
  code;
  constructor(code, message) {
    super(message);
    this.name = "MemoryProjectionVerificationError";
    this.code = code;
  }
};
var SHA256 = /^sha256:[0-9a-f]{64}$/;
var BASE64URL = /^[A-Za-z0-9_-]+$/;
var RFC3339_UTC2 = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})(?:\.(\d{1,9}))?Z$/;
var RECORD_KEYS = /* @__PURE__ */ new Set([
  "@version",
  "source_profile",
  "projection_id",
  "created_at",
  "adapter",
  "selection_context",
  "delivered",
  "exclusions",
  "projection",
  "nonclaims",
  "proof"
]);
var ADAPTER_KEYS = /* @__PURE__ */ new Set(["id", "key_id"]);
var SELECTION_KEYS = /* @__PURE__ */ new Set([
  "recall_request_digest",
  "selection_policy_digest",
  "trust_snapshot_digest",
  "trust_evaluated_at",
  "context_frame_profile"
]);
var DELIVERED_KEYS = /* @__PURE__ */ new Set([
  "position",
  "object",
  "context_fragment_digest",
  "derived_trust",
  "authorship",
  "author_key_id_b64u",
  "custody_present"
]);
var OBJECT_KEYS = /* @__PURE__ */ new Set(["format_version", "sealed_object_digest"]);
var EXCLUSION_KEYS = /* @__PURE__ */ new Set(["total", "by_reason"]);
var EXCLUSION_REASON_KEYS = /* @__PURE__ */ new Set([
  "authentication_failed",
  "schema_invalid",
  "policy_filtered",
  "context_limit"
]);
var PROJECTION_KEYS = /* @__PURE__ */ new Set(["encoding", "byte_length", "digest"]);
var NONCLAIM_KEYS = /* @__PURE__ */ new Set([
  "model_use",
  "action_linkage",
  "action_authorization",
  "execution_outcome"
]);
var PROOF_KEYS2 = /* @__PURE__ */ new Set(["alg", "key_id", "signature_b64u"]);
function fail(code, message) {
  throw new MemoryProjectionVerificationError(code, message);
}
function isDataObject(value) {
  if (value === null || typeof value !== "object" || Array.isArray(value))
    return false;
  const prototype = Object.getPrototypeOf(value);
  if (prototype !== Object.prototype && prototype !== null)
    return false;
  return Reflect.ownKeys(value).every((key) => {
    if (typeof key !== "string")
      return false;
    const descriptor = Object.getOwnPropertyDescriptor(value, key);
    return descriptor?.enumerable === true && Object.hasOwn(descriptor, "value");
  });
}
function exactKeys2(value, expected, path) {
  if (!isDataObject(value))
    fail("record_invalid", `${path} must be a plain data object`);
  const keys = Object.keys(value);
  if (keys.length !== expected.size || keys.some((key) => !expected.has(key))) {
    fail("record_invalid", `${path} has an unknown, missing, or duplicated semantic member`);
  }
}
function safeInteger(value, path, minimum = 0) {
  if (!Number.isSafeInteger(value) || value < minimum || Object.is(value, -0)) {
    fail("record_invalid", `${path} must be a safe integer >= ${minimum}`);
  }
}
function boundedString(value, path, maximum = 1024) {
  if (typeof value !== "string" || value.length === 0 || value.length > maximum || /[\u0000-\u001f\u007f]/.test(value) || hasUnpairedSurrogate(value)) {
    fail("record_invalid", `${path} must be a bounded I-JSON string`);
  }
}
function hasUnpairedSurrogate(value) {
  for (let index = 0; index < value.length; index += 1) {
    const code = value.charCodeAt(index);
    if (code >= 55296 && code <= 56319) {
      const next = value.charCodeAt(index + 1);
      if (!(next >= 56320 && next <= 57343))
        return true;
      index += 1;
    } else if (code >= 56320 && code <= 57343) {
      return true;
    }
  }
  return false;
}
function absoluteUri2(value, path) {
  boundedString(value, path, 2048);
  try {
    const parsed = new URL(value);
    if (!parsed.protocol)
      throw new Error("missing scheme");
  } catch {
    fail("record_invalid", `${path} must be an absolute URI`);
  }
}
function instantMs2(value, path) {
  if (typeof value !== "string")
    fail("record_invalid", `${path} must be a UTC RFC 3339 timestamp`);
  const match = value.match(RFC3339_UTC2);
  if (!match)
    fail("record_invalid", `${path} must be a UTC RFC 3339 timestamp`);
  const [, year, month, day, hour, minute, second] = match;
  const calendar = /* @__PURE__ */ new Date(0);
  calendar.setUTCFullYear(Number(year), Number(month) - 1, Number(day));
  calendar.setUTCHours(Number(hour), Number(minute), Number(second), 0);
  if (calendar.toISOString().slice(0, 19) !== `${year}-${month}-${day}T${hour}:${minute}:${second}`) {
    fail("record_invalid", `${path} must be a real UTC calendar instant`);
  }
  const parsed = Date.parse(value);
  if (!Number.isFinite(parsed))
    fail("record_invalid", `${path} must be a UTC RFC 3339 timestamp`);
  return parsed;
}
function digest2(value, path) {
  if (typeof value !== "string" || !SHA256.test(value)) {
    fail("record_invalid", `${path} must be a lowercase SHA-256 digest`);
  }
}
function canonicalBase64url(value, path, exactBytes) {
  if (typeof value !== "string" || value.length === 0 || !BASE64URL.test(value)) {
    fail("record_invalid", `${path} must be unpadded base64url`);
  }
  const bytes = Buffer.from(value, "base64url");
  if (bytes.toString("base64url") !== value || exactBytes !== void 0 && bytes.length !== exactBytes) {
    fail("record_invalid", `${path} must be canonical unpadded base64url`);
  }
}
function canonicalize4(value) {
  if (value === null)
    return "null";
  if (typeof value === "string") {
    if (hasUnpairedSurrogate(value))
      fail("record_invalid", "signed record contains invalid Unicode");
    return JSON.stringify(value);
  }
  if (typeof value === "boolean")
    return value ? "true" : "false";
  if (typeof value === "number") {
    if (!Number.isSafeInteger(value) || Object.is(value, -0)) {
      fail("record_invalid", "signed record numbers must be safe integers");
    }
    return JSON.stringify(value);
  }
  if (Array.isArray(value))
    return `[${value.map(canonicalize4).join(",")}]`;
  if (!isDataObject(value))
    fail("record_invalid", "signed record must be I-JSON data");
  return `{${Object.keys(value).sort().map((key) => `${JSON.stringify(key)}:${canonicalize4(value[key])}`).join(",")}}`;
}
function digestBytes(bytes) {
  return `sha256:${crypto2.createHash("sha256").update(bytes).digest("hex")}`;
}
function unsignedRecord(record2) {
  const { proof: _proof, ...unsigned } = record2;
  return unsigned;
}
function signingBytes(record2) {
  return Buffer.concat([
    Buffer.from(MEMORY_PROJECTION_RECORD_DOMAIN, "utf8"),
    Buffer.from(canonicalize4(unsignedRecord(record2)), "utf8")
  ]);
}
function keyObject(publicKeySpkiB64u) {
  canonicalBase64url(publicKeySpkiB64u, "adapter key");
  try {
    const key = crypto2.createPublicKey({
      key: Buffer.from(publicKeySpkiB64u, "base64url"),
      format: "der",
      type: "spki"
    });
    if (key.asymmetricKeyType !== "ed25519") {
      fail("adapter_key_invalid", "adapter key must be Ed25519");
    }
    return key;
  } catch (error) {
    if (error instanceof MemoryProjectionVerificationError)
      throw error;
    fail("adapter_key_invalid", "adapter key must be canonical Ed25519 SPKI");
  }
}
function validateAdapterKey(entry, createdAt, verificationTime) {
  const keys = /* @__PURE__ */ new Set(["public_key_spki_b64u", "status", "valid_from", "valid_to", "revoked_at"]);
  exactKeys2(entry, keys, "adapter key");
  if (!["active", "revoked", "superseded"].includes(entry.status)) {
    fail("adapter_key_invalid", "adapter key status is invalid");
  }
  const validFrom = instantMs2(entry.valid_from, "adapter key valid_from");
  const validTo = instantMs2(entry.valid_to, "adapter key valid_to");
  const revokedAt = entry.revoked_at === null ? null : instantMs2(entry.revoked_at, "adapter key revoked_at");
  if (validFrom > validTo)
    fail("adapter_key_invalid", "adapter key validity interval is inverted");
  if (createdAt < validFrom || createdAt > validTo) {
    fail("adapter_key_inactive", "adapter key was not valid when the projection was created");
  }
  if (entry.status === "revoked" && revokedAt !== null && verificationTime >= revokedAt) {
    fail("adapter_key_revoked", "adapter key is revoked at verification time");
  }
  if (entry.status !== "active" || verificationTime < validFrom || verificationTime > validTo) {
    fail("adapter_key_inactive", "adapter key is not current at verification time");
  }
  return keyObject(entry.public_key_spki_b64u);
}
function validateDeliveredEntry(entry, position) {
  const path = `record.delivered[${position}]`;
  exactKeys2(entry, DELIVERED_KEYS, path);
  if (entry.position !== position) {
    fail("delivered_order_invalid", `${path}.position must equal ${position}`);
  }
  exactKeys2(entry.object, OBJECT_KEYS, `${path}.object`);
  safeInteger(entry.object.format_version, `${path}.object.format_version`, 1);
  digest2(entry.object.sealed_object_digest, `${path}.object.sealed_object_digest`);
  digest2(entry.context_fragment_digest, `${path}.context_fragment_digest`);
  if (!["self", "trusted", "unverified"].includes(entry.derived_trust)) {
    fail("record_invalid", `${path}.derived_trust is invalid`);
  }
  if (!["signed", "attested", "unknown"].includes(entry.authorship)) {
    fail("record_invalid", `${path}.authorship is invalid`);
  }
  if (entry.author_key_id_b64u !== null) {
    canonicalBase64url(entry.author_key_id_b64u, `${path}.author_key_id_b64u`);
  }
  if (typeof entry.custody_present !== "boolean") {
    fail("record_invalid", `${path}.custody_present must be boolean`);
  }
  if (entry.authorship === "attested" && entry.custody_present !== true) {
    fail("source_result_invalid", `${path}: attested authorship requires custody`);
  }
  if (entry.derived_trust === "unverified") {
    if (entry.authorship !== "unknown" || entry.author_key_id_b64u !== null) {
      fail("source_result_invalid", `${path}: unverified content must not report an author`);
    }
  } else if (entry.authorship === "unknown" || entry.author_key_id_b64u === null) {
    fail("source_result_invalid", `${path}: verified content must report an author`);
  }
}
function validateRecordShape(record2) {
  exactKeys2(record2, RECORD_KEYS, "record");
  if (record2["@version"] !== MEMORY_PROJECTION_RECORD_VERSION) {
    fail("version_unsupported", `record @version must be ${MEMORY_PROJECTION_RECORD_VERSION}`);
  }
  boundedString(record2.source_profile, "record.source_profile", 512);
  absoluteUri2(record2.projection_id, "record.projection_id");
  const createdAt = instantMs2(record2.created_at, "record.created_at");
  exactKeys2(record2.adapter, ADAPTER_KEYS, "record.adapter");
  absoluteUri2(record2.adapter.id, "record.adapter.id");
  boundedString(record2.adapter.key_id, "record.adapter.key_id", 512);
  exactKeys2(record2.selection_context, SELECTION_KEYS, "record.selection_context");
  digest2(record2.selection_context.recall_request_digest, "record.selection_context.recall_request_digest");
  digest2(record2.selection_context.selection_policy_digest, "record.selection_context.selection_policy_digest");
  digest2(record2.selection_context.trust_snapshot_digest, "record.selection_context.trust_snapshot_digest");
  const trustEvaluatedAt = instantMs2(record2.selection_context.trust_evaluated_at, "record.selection_context.trust_evaluated_at");
  boundedString(record2.selection_context.context_frame_profile, "record.selection_context.context_frame_profile", 1024);
  if (!Array.isArray(record2.delivered))
    fail("record_invalid", "record.delivered must be an array");
  record2.delivered.forEach(validateDeliveredEntry);
  exactKeys2(record2.exclusions, EXCLUSION_KEYS, "record.exclusions");
  safeInteger(record2.exclusions.total, "record.exclusions.total");
  exactKeys2(record2.exclusions.by_reason, EXCLUSION_REASON_KEYS, "record.exclusions.by_reason");
  let total = 0;
  for (const reason of EXCLUSION_REASON_KEYS) {
    safeInteger(record2.exclusions.by_reason[reason], `record.exclusions.by_reason.${reason}`);
    total += record2.exclusions.by_reason[reason];
  }
  if (total !== record2.exclusions.total) {
    fail("exclusion_count_mismatch", "record.exclusions.total must equal the four reason counters");
  }
  exactKeys2(record2.projection, PROJECTION_KEYS, "record.projection");
  if (record2.projection.encoding !== "utf-8") {
    fail("record_invalid", "record.projection.encoding must be utf-8");
  }
  safeInteger(record2.projection.byte_length, "record.projection.byte_length");
  digest2(record2.projection.digest, "record.projection.digest");
  exactKeys2(record2.nonclaims, NONCLAIM_KEYS, "record.nonclaims");
  for (const [key, expected] of Object.entries(MEMORY_PROJECTION_NONCLAIMS)) {
    if (record2.nonclaims[key] !== expected) {
      fail("nonclaim_invalid", `record.nonclaims.${key} must be ${expected}`);
    }
  }
  exactKeys2(record2.proof, PROOF_KEYS2, "record.proof");
  if (record2.proof.alg !== "Ed25519")
    fail("record_invalid", "record.proof.alg must be Ed25519");
  boundedString(record2.proof.key_id, "record.proof.key_id", 512);
  canonicalBase64url(record2.proof.signature_b64u, "record.proof.signature_b64u", 64);
  if (record2.proof.key_id !== record2.adapter.key_id) {
    fail("proof_key_mismatch", "record.proof.key_id must equal record.adapter.key_id");
  }
  canonicalize4(record2);
  return { value: record2, createdAt, trustEvaluatedAt };
}
function normalizePolicy(policy) {
  if (!isDataObject(policy))
    fail("verification_policy_invalid", "verification policy is required");
  const verificationTime = instantMs2(policy.verificationTime, "verificationTime");
  safeInteger(policy.maxProjectionAgeSec, "maxProjectionAgeSec");
  safeInteger(policy.maxTrustAgeSec, "maxTrustAgeSec");
  if (!isDataObject(policy.adapterKeys)) {
    fail("verification_policy_invalid", "adapterKeys must be a pinned key directory");
  }
  return {
    verificationTime,
    maxProjectionAgeSec: policy.maxProjectionAgeSec,
    maxTrustAgeSec: policy.maxTrustAgeSec
  };
}
function verifyMemoryProjectionRecordV1Envelope(record2, policy) {
  const { value, createdAt, trustEvaluatedAt } = validateRecordShape(record2);
  const normalized = normalizePolicy(policy);
  if (policy.expectedSourceProfile !== void 0 && value.source_profile !== policy.expectedSourceProfile) {
    fail("source_profile_mismatch", "record source profile is not pinned by the relying party");
  }
  if (policy.expectedContextFrameProfile !== void 0 && value.selection_context.context_frame_profile !== policy.expectedContextFrameProfile) {
    fail("context_frame_profile_mismatch", "record context-frame profile is not pinned");
  }
  const projectionAge = (normalized.verificationTime - createdAt) / 1e3;
  if (projectionAge < 0)
    fail("projection_from_future", "record creation time is in the future");
  if (projectionAge > normalized.maxProjectionAgeSec) {
    fail("projection_stale", "record creation time is outside relying-party freshness policy");
  }
  const trustAge = (normalized.verificationTime - trustEvaluatedAt) / 1e3;
  if (trustAge < 0)
    fail("trust_snapshot_from_future", "trust evaluation time is in the future");
  if (trustAge > normalized.maxTrustAgeSec) {
    fail("trust_snapshot_stale", "trust evaluation is outside relying-party freshness policy");
  }
  if (trustEvaluatedAt > createdAt) {
    fail("trust_snapshot_from_future", "trust evaluation cannot occur after record creation");
  }
  const pinned = policy.adapterKeys[value.adapter.key_id];
  if (pinned === void 0) {
    fail("adapter_key_not_pinned", "record adapter key is not pinned by the relying party");
  }
  const key = validateAdapterKey(pinned, createdAt, normalized.verificationTime);
  const signatureValid = crypto2.verify(null, signingBytes(value), key, Buffer.from(value.proof.signature_b64u, "base64url"));
  if (!signatureValid)
    fail("signature_invalid", "record signature is invalid");
  return {
    valid: true,
    verification_scope: "SIGNED_ENVELOPE_ONLY",
    projection_id: value.projection_id,
    projection_digest: value.projection.digest,
    delivered_count: value.delivered.length,
    excluded_count: value.exclusions.total,
    created_at: value.created_at,
    trust_evaluated_at: value.selection_context.trust_evaluated_at
  };
}
function verifyMemoryProjectionRecordV1(record2, material, policy, options = {}) {
  const envelope = verifyMemoryProjectionRecordV1Envelope(record2, policy);
  const value = record2;
  if (!isDataObject(material)) {
    fail("verification_material_missing", "complete verification material is required");
  }
  const bytes = (candidate, path) => {
    if (!(candidate instanceof Uint8Array)) {
      fail("verification_material_missing", `${path} must be exact bytes`);
    }
    return Buffer.from(candidate);
  };
  if (typeof material.verifySourceEntry !== "function") {
    fail("native_source_verifier_missing", "a source-profile native verifier is required");
  }
  if (digestBytes(bytes(material.recallRequestBytes, "recallRequestBytes")) !== value.selection_context.recall_request_digest) {
    fail("recall_request_digest_mismatch", "recall request bytes do not match the record");
  }
  if (digestBytes(bytes(material.selectionPolicyBytes, "selectionPolicyBytes")) !== value.selection_context.selection_policy_digest) {
    fail("selection_policy_digest_mismatch", "selection policy bytes do not match the record");
  }
  if (digestBytes(bytes(material.trustSnapshotBytes, "trustSnapshotBytes")) !== value.selection_context.trust_snapshot_digest) {
    fail("trust_snapshot_digest_mismatch", "trust snapshot bytes do not match the record");
  }
  const sourceObjects = material.sourceObjectBytesByPosition;
  const fragments = material.fragmentBytesByPosition;
  if (!Array.isArray(sourceObjects) || sourceObjects.length !== value.delivered.length) {
    fail("source_object_material_mismatch", "source-object material must match delivered length");
  }
  if (!Array.isArray(fragments) || fragments.length !== value.delivered.length) {
    fail("fragment_material_mismatch", "fragment material must match delivered length");
  }
  const exactFragments = [];
  for (let position = 0; position < value.delivered.length; position += 1) {
    const entry = value.delivered[position];
    const sourceObjectBytes = bytes(sourceObjects[position], `sourceObjectBytesByPosition[${position}]`);
    const fragmentBytes = bytes(fragments[position], `fragmentBytesByPosition[${position}]`);
    if (digestBytes(sourceObjectBytes) !== entry.object.sealed_object_digest) {
      fail("source_object_digest_mismatch", `source object ${position} does not match its commitment`);
    }
    if (digestBytes(fragmentBytes) !== entry.context_fragment_digest) {
      fail("fragment_digest_mismatch", `fragment ${position} does not match its commitment`);
    }
    const native = material.verifySourceEntry({
      sourceProfile: value.source_profile,
      position,
      sourceObjectBytes,
      deliveredEntry: entry
    });
    if (!isDataObject(native) || native.valid !== true || native.formatVersion !== entry.object.format_version || native.sealedObjectDigest !== entry.object.sealed_object_digest || native.derivedTrust !== entry.derived_trust || native.authorship !== entry.authorship || native.authorKeyIdB64u !== entry.author_key_id_b64u || native.custodyPresent !== entry.custody_present) {
      fail("native_source_result_mismatch", `source-profile result ${position} does not match the record`);
    }
    exactFragments.push(fragmentBytes);
  }
  const projectionBytes = bytes(material.projectionBytes, "projectionBytes");
  const concatenated = Buffer.concat(exactFragments);
  if (concatenated.length !== projectionBytes.length || !crypto2.timingSafeEqual(concatenated, projectionBytes)) {
    fail("projection_fragment_concatenation_mismatch", "fragments do not concatenate to projection bytes");
  }
  if (projectionBytes.length !== value.projection.byte_length) {
    fail("projection_length_mismatch", "projection bytes do not match record byte_length");
  }
  if (digestBytes(projectionBytes) !== value.projection.digest) {
    fail("projection_digest_mismatch", "projection bytes do not match record digest");
  }
  if (options.requireSingleUse) {
    if (!options.projectionIdRegistry) {
      fail("projection_registry_missing", "single-use verification requires an atomic projection registry");
    }
    if (!options.projectionIdRegistry.register(value.projection_id)) {
      fail("projection_replay", "projection identifier was already registered");
    }
  }
  return {
    valid: true,
    verification_scope: "FULL_PROJECTION_AND_NATIVE_SOURCE_RESULTS",
    projection_id: envelope.projection_id,
    projection_digest: envelope.projection_digest,
    delivered_count: envelope.delivered_count,
    excluded_count: envelope.excluded_count
  };
}
function createMemoryProjectionRecordV1(input) {
  if (!isDataObject(input))
    fail("producer_input_invalid", "producer input is required");
  if (!Array.isArray(input.delivered)) {
    fail("producer_input_invalid", "producer delivered entries are required");
  }
  const recallRequestBytes = Buffer.from(input.selectionContext.recallRequestBytes);
  const selectionPolicyBytes = Buffer.from(input.selectionContext.selectionPolicyBytes);
  const trustSnapshotBytes = Buffer.from(input.selectionContext.trustSnapshotBytes);
  const sourceObjectBytesByPosition = input.delivered.map((entry) => Buffer.from(entry.sealedObjectBytes));
  const fragmentBytesByPosition = input.delivered.map((entry) => Buffer.from(entry.contextFragmentBytes));
  const projectionBytes = Buffer.concat(fragmentBytesByPosition);
  const byReason = {
    authentication_failed: input.exclusions.authenticationFailed,
    schema_invalid: input.exclusions.schemaInvalid,
    policy_filtered: input.exclusions.policyFiltered,
    context_limit: input.exclusions.contextLimit
  };
  for (const [reason, count] of Object.entries(byReason))
    safeInteger(count, `exclusions.${reason}`);
  const unsigned = {
    "@version": MEMORY_PROJECTION_RECORD_VERSION,
    source_profile: input.sourceProfile,
    projection_id: input.projectionId,
    created_at: input.createdAt,
    adapter: {
      id: input.adapter.id,
      key_id: input.adapter.keyId
    },
    selection_context: {
      recall_request_digest: digestBytes(recallRequestBytes),
      selection_policy_digest: digestBytes(selectionPolicyBytes),
      trust_snapshot_digest: digestBytes(trustSnapshotBytes),
      trust_evaluated_at: input.selectionContext.trustEvaluatedAt,
      context_frame_profile: input.selectionContext.contextFrameProfile
    },
    delivered: input.delivered.map((entry, position) => ({
      position,
      object: {
        format_version: entry.formatVersion,
        sealed_object_digest: digestBytes(sourceObjectBytesByPosition[position])
      },
      context_fragment_digest: digestBytes(fragmentBytesByPosition[position]),
      derived_trust: entry.derivedTrust,
      authorship: entry.authorship,
      author_key_id_b64u: entry.authorKeyIdB64u,
      custody_present: entry.custodyPresent
    })),
    exclusions: {
      total: Object.values(byReason).reduce((sum, count) => sum + count, 0),
      by_reason: byReason
    },
    projection: {
      encoding: "utf-8",
      byte_length: projectionBytes.length,
      digest: digestBytes(projectionBytes)
    },
    nonclaims: { ...MEMORY_PROJECTION_NONCLAIMS }
  };
  validateRecordShape({
    ...unsigned,
    proof: {
      alg: "Ed25519",
      key_id: input.adapter.keyId,
      signature_b64u: Buffer.alloc(64).toString("base64url")
    }
  });
  const signature = crypto2.sign(null, Buffer.concat([
    Buffer.from(MEMORY_PROJECTION_RECORD_DOMAIN, "utf8"),
    Buffer.from(canonicalize4(unsigned), "utf8")
  ]), input.privateKey);
  const record2 = {
    ...unsigned,
    proof: {
      alg: "Ed25519",
      key_id: input.adapter.keyId,
      signature_b64u: signature.toString("base64url")
    }
  };
  return {
    record: record2,
    verificationMaterial: {
      recallRequestBytes,
      selectionPolicyBytes,
      trustSnapshotBytes,
      sourceObjectBytesByPosition,
      fragmentBytesByPosition,
      projectionBytes
    }
  };
}
function memoryProjectionRecordDigest(record2) {
  validateRecordShape(record2);
  return digestBytes(Buffer.from(canonicalize4(record2), "utf8"));
}
var memory_projection_default = Object.freeze({
  MEMORY_PROJECTION_RECORD_VERSION,
  MEMORY_PROJECTION_RECORD_DOMAIN,
  createMemoryProjectionRecordV1,
  verifyMemoryProjectionRecordV1Envelope,
  verifyMemoryProjectionRecordV1,
  memoryProjectionRecordDigest
});

// ../../../../../private/tmp/emilia-ccs-aeb.TjuCWa/extracted/emilia-ccs-l1-aeb-e94314ab/packages/verify/dist/agent-edge-continuity.js
var AGENT_CONTINUITY_VERSION = "EP-AGENT-EDGE-CONTINUITY-v1";
var AGENT_CONTINUITY_DOMAIN = `${AGENT_CONTINUITY_VERSION}\0`;

// ../../../../../private/tmp/emilia-ccs-aeb.TjuCWa/extracted/emilia-ccs-l1-aeb-e94314ab/packages/verify/dist/status.js
var STATUS_VERSION = "EP-STATUS-v1";
var STATUS_DOMAIN = `${STATUS_VERSION}\0`;
var REVOCER_AUTHORITY_VERSION = "EP-REVOKER-AUTHORITY-v1";
var REVOCER_AUTHORITY_DOMAIN = `${REVOCER_AUTHORITY_VERSION}\0`;
var STATUS_TARGET_TYPES = Object.freeze([
  "receipt",
  "commit",
  "delegation"
]);
var STATUS_TARGET_USAGES = Object.freeze([
  "authorization",
  "execution",
  "delegation"
]);

// ../../../../../private/tmp/emilia-ccs-aeb.TjuCWa/extracted/emilia-ccs-l1-aeb-e94314ab/packages/verify/dist/gate-qualification.js
var CANDIDATE_MANIFEST_VERSION = "EP-CANDIDATE-MANIFEST-v1";
var EVALUATION_CAMPAIGN_PREDICATE = "https://emiliaprotocol.ai/attestation/evaluation-campaign/v1";
var TEST_RESULT_PREDICATE = "https://in-toto.io/attestation/test-result/v0.1";
var AGENT_EVALUATION_EVIDENCE_PREDICATE = "https://emiliaprotocol.ai/attestation/agent-evaluation-evidence/v1";
var QUALIFICATION_STATEMENT_PREDICATE = "https://in-toto.io/attestation/svr/v0.2";
var QUALIFICATION_STATUS_VERSION = "EP-QUALIFICATION-STATUS-v1";
var RUNTIME_CANDIDATE_MEASUREMENT_VERSION = "EP-RUNTIME-CANDIDATE-MEASUREMENT-v1";
var IN_TOTO_STATEMENT_V1 = "https://in-toto.io/Statement/v1";
var TERMINAL_OUTCOMES = Object.freeze(["PASS", "FAIL", "ABORTED", "EXPIRED"]);
var QUALIFICATION_DECISIONS = Object.freeze(["QUALIFIED", "NOT_QUALIFIED", "INDETERMINATE"]);
var MODEL_PINNING_STRENGTHS = Object.freeze([
  "UNPINNABLE",
  "MUTABLE_ALIAS",
  "VERSION_PINNED",
  "IMMUTABLE_DIGEST"
]);
var GATE_QUALIFICATION_LIMITS = Object.freeze({
  max_payload_bytes: 1048576,
  max_string_bytes: 4096,
  max_signatures: 8,
  max_campaigns: 32,
  max_status_entries: 256,
  max_test_results: 4096,
  max_agent_evidence: 32,
  max_terminal_outcomes: 4096,
  max_challenges: 512,
  max_batches: 128,
  max_attempts_per_challenge: 16,
  max_measurements: 256,
  max_test_names: 4096,
  max_configuration_refs: 32,
  max_properties: 128,
  max_object_depth: 32,
  max_object_nodes: 65536
});
var SHA2562 = /^sha256:[0-9a-f]{64}$/;
var HEX256 = /^[0-9a-f]{64}$/;
var RFC3339 = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})(?:\.(\d{1,9}))?(?:Z|([+-])(\d{2}):(\d{2}))$/;
var FATAL_UTF8 = new TextDecoder("utf-8", { fatal: true });
var own = (value, key) => Object.prototype.hasOwnProperty.call(value, key);
function record(value) {
  if (value === null || typeof value !== "object" || Array.isArray(value))
    return false;
  const prototype = Object.getPrototypeOf(value);
  return prototype === Object.prototype || prototype === null;
}
function exactObject(value, required, optional = []) {
  if (!record(value))
    return false;
  const allowed = /* @__PURE__ */ new Set([...required, ...optional]);
  const keys = Object.keys(value);
  return required.every((key) => own(value, key)) && keys.every((key) => allowed.has(key));
}
function validUnicode(value) {
  for (let index = 0; index < value.length; index += 1) {
    const code = value.charCodeAt(index);
    if (code >= 55296 && code <= 56319) {
      const next = value.charCodeAt(index + 1);
      if (!(next >= 56320 && next <= 57343))
        return false;
      index += 1;
    } else if (code >= 56320 && code <= 57343)
      return false;
  }
  return true;
}
function nonEmptyString2(value, maxBytes = GATE_QUALIFICATION_LIMITS.max_string_bytes) {
  return typeof value === "string" && value.length > 0 && validUnicode(value) && Buffer.byteLength(value, "utf8") <= maxBytes && !/[\u0000-\u001f\u007f]/.test(value);
}
function digest3(value) {
  return typeof value === "string" && SHA2562.test(value);
}
function safeNonNegativeInteger(value) {
  return Number.isSafeInteger(value) && value >= 0;
}
function instantMs3(value) {
  if (typeof value !== "string")
    return NaN;
  const match = RFC3339.exec(value);
  if (!match)
    return NaN;
  const [, year, month, day, hour, minute, second, , , offsetHour, offsetMinute] = match;
  if (offsetHour !== void 0 && (Number(offsetHour) > 23 || Number(offsetMinute) > 59))
    return NaN;
  const calendar = /* @__PURE__ */ new Date(0);
  calendar.setUTCFullYear(Number(year), Number(month) - 1, Number(day));
  calendar.setUTCHours(Number(hour), Number(minute), Number(second), 0);
  if (calendar.toISOString().slice(0, 19) !== `${year}-${month}-${day}T${hour}:${minute}:${second}`)
    return NaN;
  return Date.parse(value);
}
function uri(value) {
  if (!nonEmptyString2(value))
    return false;
  try {
    return Boolean(new URL(value).protocol);
  } catch {
    return false;
  }
}
function sortedUniqueStrings(value, min, max, predicate) {
  if (!Array.isArray(value) || value.length < min || value.length > max || !value.every(predicate))
    return false;
  for (let index = 1; index < value.length; index += 1) {
    if (Buffer.compare(Buffer.from(value[index - 1]), Buffer.from(value[index])) >= 0)
      return false;
  }
  return true;
}
function canonicalizeQualification(value) {
  return canonicalizeStrictJson(value, {
    maxDepth: GATE_QUALIFICATION_LIMITS.max_object_depth,
    maxNodes: GATE_QUALIFICATION_LIMITS.max_object_nodes
  });
}
function resourceDescriptor(value) {
  return exactObject(value, ["name", "digest"]) && nonEmptyString2(value.name) && exactObject(value.digest, ["sha256"]) && typeof value.digest.sha256 === "string" && HEX256.test(value.digest.sha256);
}
function resourceMatches(value, name, expected) {
  return resourceDescriptor(value) && value.name === name && expected === `sha256:${value.digest.sha256}`;
}
function statement(value, predicateType) {
  return exactObject(value, ["_type", "subject", "predicateType", "predicate"]) && value._type === IN_TOTO_STATEMENT_V1 && value.predicateType === predicateType && Array.isArray(value.subject) && value.subject.length > 0 && value.subject.length <= 16 && value.subject.every(resourceDescriptor) && record(value.predicate);
}
function validModel(value) {
  if (!exactObject(value, ["provider", "identity", "version", "artifact_digest", "pinning_strength"]) || !nonEmptyString2(value.provider) || !nonEmptyString2(value.identity) || !nonEmptyString2(value.version) || !MODEL_PINNING_STRENGTHS.includes(value.pinning_strength))
    return false;
  if (value.artifact_digest !== null && !digest3(value.artifact_digest))
    return false;
  return value.pinning_strength !== "IMMUTABLE_DIGEST" || digest3(value.artifact_digest);
}
function validStaticCandidate(value) {
  return exactObject(value, [
    "code_digests",
    "dependency_digests",
    "prompt_template_digests",
    "tool_definition_digests",
    "effective_permissions_digest",
    "model",
    "retrieval_configuration_digest",
    "builder_orchestrator_digest"
  ]) && sortedUniqueStrings(value.code_digests, 1, 256, digest3) && sortedUniqueStrings(value.dependency_digests, 0, 1024, digest3) && sortedUniqueStrings(value.prompt_template_digests, 1, 256, digest3) && sortedUniqueStrings(value.tool_definition_digests, 1, 512, digest3) && digest3(value.effective_permissions_digest) && validModel(value.model) && digest3(value.retrieval_configuration_digest) && digest3(value.builder_orchestrator_digest);
}
function validateCandidateManifest(value) {
  try {
    if (!exactObject(value, ["profile", "candidate_id", "static"]) || value.profile !== CANDIDATE_MANIFEST_VERSION || !nonEmptyString2(value.candidate_id) || !validStaticCandidate(value.static))
      return { valid: false, reason: "invalid_candidate_manifest" };
    canonicalizeQualification(value);
    return { valid: true, value };
  } catch {
    return { valid: false, reason: "invalid_candidate_manifest" };
  }
}
function validHiddenChallenges(value) {
  if (!record(value) || !own(value, "scheme"))
    return false;
  if (value.scheme === "SALTED_SHA256_SET") {
    return exactObject(value, ["scheme", "commitments"]) && sortedUniqueStrings(value.commitments, 1, GATE_QUALIFICATION_LIMITS.max_challenges, digest3);
  }
  return value.scheme === "MERKLE_SHA256" && exactObject(value, ["scheme", "root_digest", "challenge_count"]) && digest3(value.root_digest) && safeNonNegativeInteger(value.challenge_count) && value.challenge_count >= 1 && value.challenge_count <= GATE_QUALIFICATION_LIMITS.max_challenges;
}
function validateEvaluationCampaign(value) {
  try {
    if (!statement(value, EVALUATION_CAMPAIGN_PREDICATE) || value.subject.length !== 1)
      return { valid: false, reason: "invalid_evaluation_campaign" };
    const p = value.predicate;
    if (!exactObject(p, [
      "campaign_id",
      "candidate_manifest_digest",
      "assignment_digest",
      "qualification_policy_digest",
      "harness_digest",
      "evaluator_configuration_digest",
      "environment_digest",
      "hidden_challenges",
      "scenario_selection_commitment_digest",
      "planned_batches",
      "maximum_batches",
      "attempt_ceiling",
      "not_before",
      "not_after",
      "predecessor_campaign_payload_digest"
    ]) || !nonEmptyString2(p.campaign_id) || !digest3(p.candidate_manifest_digest) || !digest3(p.assignment_digest) || !digest3(p.qualification_policy_digest) || !digest3(p.harness_digest) || !digest3(p.evaluator_configuration_digest) || !digest3(p.environment_digest) || !validHiddenChallenges(p.hidden_challenges) || !digest3(p.scenario_selection_commitment_digest) || !safeNonNegativeInteger(p.planned_batches) || !safeNonNegativeInteger(p.maximum_batches) || p.planned_batches < 1 || p.maximum_batches < p.planned_batches || p.maximum_batches > GATE_QUALIFICATION_LIMITS.max_batches || !safeNonNegativeInteger(p.attempt_ceiling) || p.attempt_ceiling < 1 || p.attempt_ceiling > GATE_QUALIFICATION_LIMITS.max_attempts_per_challenge || !Number.isFinite(instantMs3(p.not_before)) || !Number.isFinite(instantMs3(p.not_after)) || instantMs3(p.not_before) >= instantMs3(p.not_after) || p.predecessor_campaign_payload_digest !== null && !digest3(p.predecessor_campaign_payload_digest) || !resourceMatches(value.subject[0], "candidate-manifest", p.candidate_manifest_digest)) {
      return { valid: false, reason: "invalid_evaluation_campaign" };
    }
    return { valid: true, value };
  } catch {
    return { valid: false, reason: "invalid_evaluation_campaign" };
  }
}
function validStringList(value) {
  return sortedUniqueStrings(value, 0, GATE_QUALIFICATION_LIMITS.max_test_names, (entry) => nonEmptyString2(entry));
}
function validateTestResultReference(value) {
  try {
    if (!statement(value, TEST_RESULT_PREDICATE) || value.subject.length !== 1)
      return { valid: false, reason: "invalid_test_result" };
    const p = value.predicate;
    if (!exactObject(p, ["result", "configuration"], ["url", "passedTests", "warnedTests", "failedTests"]) || !["PASSED", "WARNED", "FAILED"].includes(p.result) || !Array.isArray(p.configuration) || p.configuration.length < 1 || p.configuration.length > GATE_QUALIFICATION_LIMITS.max_configuration_refs || !p.configuration.every(resourceDescriptor) || own(p, "url") && !uri(p.url) || own(p, "passedTests") && !validStringList(p.passedTests) || own(p, "warnedTests") && !validStringList(p.warnedTests) || own(p, "failedTests") && !validStringList(p.failedTests))
      return { valid: false, reason: "invalid_test_result" };
    return { valid: true, value };
  } catch {
    return { valid: false, reason: "invalid_test_result" };
  }
}
function validMerkleProof(value) {
  return Array.isArray(value) && value.length <= 16 && value.every((entry) => exactObject(entry, ["side", "digest"]) && ["LEFT", "RIGHT"].includes(entry.side) && digest3(entry.digest));
}
function validTerminalReference(value) {
  if (!exactObject(value, [
    "batch",
    "challenge_index",
    "attempt",
    "challenge_commitment",
    "challenge_proof",
    "scenario_selection_commitment_digest",
    "outcome",
    "test_result_payload_digest",
    "terminal_evidence_payload_digest",
    "started_at",
    "finished_at"
  ]) || !safeNonNegativeInteger(value.batch) || value.batch < 1 || !safeNonNegativeInteger(value.challenge_index) || !safeNonNegativeInteger(value.attempt) || value.attempt < 1 || !digest3(value.challenge_commitment) || !validMerkleProof(value.challenge_proof) || !digest3(value.scenario_selection_commitment_digest) || !TERMINAL_OUTCOMES.includes(value.outcome) || !digest3(value.terminal_evidence_payload_digest) || !Number.isFinite(instantMs3(value.started_at)) || !Number.isFinite(instantMs3(value.finished_at)) || instantMs3(value.started_at) > instantMs3(value.finished_at))
    return false;
  if (value.outcome === "PASS" || value.outcome === "FAIL")
    return digest3(value.test_result_payload_digest);
  return value.test_result_payload_digest === null;
}
function validOutcomeCounts(value) {
  return exactObject(value, ["PASS", "FAIL", "ABORTED", "EXPIRED"]) && TERMINAL_OUTCOMES.every((outcome) => safeNonNegativeInteger(value[outcome]));
}
function terminalReferenceKey(value) {
  return `${String(value.batch).padStart(3, "0")}:${String(value.challenge_index).padStart(4, "0")}:${String(value.attempt).padStart(3, "0")}`;
}
function validMeasurements(value) {
  if (!Array.isArray(value) || value.length > GATE_QUALIFICATION_LIMITS.max_measurements)
    return false;
  let prior = "";
  for (const measurement of value) {
    if (!exactObject(measurement, ["name", "value", "unit"]) || !nonEmptyString2(measurement.name) || !nonEmptyString2(measurement.value) || measurement.unit !== null && !nonEmptyString2(measurement.unit))
      return false;
    if (prior && Buffer.compare(Buffer.from(prior), Buffer.from(measurement.name)) >= 0)
      return false;
    prior = measurement.name;
  }
  return true;
}
function validateAgentEvaluationEvidence(value) {
  try {
    if (!statement(value, AGENT_EVALUATION_EVIDENCE_PREDICATE) || value.subject.length !== 1)
      return { valid: false, reason: "invalid_agent_evaluation_evidence" };
    const p = value.predicate;
    if (!exactObject(p, [
      "campaign_payload_digest",
      "candidate_manifest_digest",
      "assignment_digest",
      "qualification_policy_digest",
      "completed_batches",
      "issued_challenges",
      "terminal_outcomes",
      "outcome_counts",
      "terminal_outcomes_root",
      "measurements",
      "started_at",
      "completed_at"
    ]) || !digest3(p.campaign_payload_digest) || !digest3(p.candidate_manifest_digest) || !digest3(p.assignment_digest) || !digest3(p.qualification_policy_digest) || !safeNonNegativeInteger(p.completed_batches) || p.completed_batches < 1 || !safeNonNegativeInteger(p.issued_challenges) || !Array.isArray(p.terminal_outcomes) || p.terminal_outcomes.length < 1 || p.terminal_outcomes.length > GATE_QUALIFICATION_LIMITS.max_terminal_outcomes || !p.terminal_outcomes.every(validTerminalReference) || !validOutcomeCounts(p.outcome_counts) || !digest3(p.terminal_outcomes_root) || !validMeasurements(p.measurements) || !Number.isFinite(instantMs3(p.started_at)) || !Number.isFinite(instantMs3(p.completed_at)) || instantMs3(p.started_at) > instantMs3(p.completed_at) || !resourceMatches(value.subject[0], "candidate-manifest", p.candidate_manifest_digest)) {
      return { valid: false, reason: "invalid_agent_evaluation_evidence" };
    }
    for (let index = 1; index < p.terminal_outcomes.length; index += 1) {
      if (terminalReferenceKey(p.terminal_outcomes[index - 1]) >= terminalReferenceKey(p.terminal_outcomes[index])) {
        return { valid: false, reason: "terminal_outcomes_not_canonical" };
      }
    }
    return { valid: true, value };
  } catch {
    return { valid: false, reason: "invalid_agent_evaluation_evidence" };
  }
}
function validateQualificationStatement(value) {
  try {
    if (!statement(value, QUALIFICATION_STATEMENT_PREDICATE) || value.subject.length !== 3)
      return { valid: false, reason: "invalid_qualification_statement" };
    const p = value.predicate;
    if (!exactObject(p, ["verifier", "timeCreated", "properties"]) || !exactObject(p.verifier, ["id", "policies"]) || !uri(p.verifier.id) || !Array.isArray(p.verifier.policies) || p.verifier.policies.length !== 2 || !p.verifier.policies.every(resourceDescriptor) || !Number.isFinite(instantMs3(p.timeCreated)) || !sortedUniqueStrings(p.properties, 1, GATE_QUALIFICATION_LIMITS.max_properties, (entry) => nonEmptyString2(entry))) {
      return { valid: false, reason: "invalid_qualification_statement" };
    }
    return { valid: true, value };
  } catch {
    return { valid: false, reason: "invalid_qualification_statement" };
  }
}
function validateQualificationStatus(value) {
  try {
    if (!exactObject(value, [
      "profile",
      "authority_id",
      "qualification_statement_payload_digest",
      "candidate_manifest_digest",
      "assignment_digest",
      "qualification_policy_digest",
      "status",
      "sequence",
      "previous_status_payload_digest",
      "issued_at",
      "next_update",
      "valid_until"
    ]) || value.profile !== QUALIFICATION_STATUS_VERSION || !nonEmptyString2(value.authority_id) || !digest3(value.qualification_statement_payload_digest) || !digest3(value.candidate_manifest_digest) || !digest3(value.assignment_digest) || !digest3(value.qualification_policy_digest) || !["QUALIFIED", "SUSPENDED", "REVOKED", "EXPIRED"].includes(value.status) || !safeNonNegativeInteger(value.sequence) || value.previous_status_payload_digest !== null && !digest3(value.previous_status_payload_digest) || !Number.isFinite(instantMs3(value.issued_at)) || !Number.isFinite(instantMs3(value.next_update)) || !Number.isFinite(instantMs3(value.valid_until)) || instantMs3(value.issued_at) >= instantMs3(value.next_update) || instantMs3(value.issued_at) >= instantMs3(value.valid_until))
      return { valid: false, reason: "invalid_qualification_status" };
    return { valid: true, value };
  } catch {
    return { valid: false, reason: "invalid_qualification_status" };
  }
}
function validateRuntimeCandidateMeasurement(value) {
  try {
    if (!exactObject(value, [
      "profile",
      "measurement_id",
      "authority_id",
      "measurement_mechanism_digest",
      "candidate_manifest_digest",
      "assignment_digest",
      "measured_at",
      "candidate_influence_cutoff",
      "remains_in_execution_path",
      "static",
      "dynamic_retrieval_root",
      "memory_state_snapshot_digest",
      "user_input_digest",
      "protected_request_digest"
    ]) || value.profile !== RUNTIME_CANDIDATE_MEASUREMENT_VERSION || !nonEmptyString2(value.measurement_id) || !nonEmptyString2(value.authority_id) || !digest3(value.measurement_mechanism_digest) || !digest3(value.candidate_manifest_digest) || !digest3(value.assignment_digest) || !Number.isFinite(instantMs3(value.measured_at)) || !Number.isFinite(instantMs3(value.candidate_influence_cutoff)) || instantMs3(value.measured_at) > instantMs3(value.candidate_influence_cutoff) || typeof value.remains_in_execution_path !== "boolean" || !validStaticCandidate(value.static) || !digest3(value.dynamic_retrieval_root) || !digest3(value.memory_state_snapshot_digest) || !digest3(value.user_input_digest) || !digest3(value.protected_request_digest))
      return { valid: false, reason: "invalid_runtime_measurement" };
    return { valid: true, value };
  } catch {
    return { valid: false, reason: "invalid_runtime_measurement" };
  }
}
var CandidateManifestSchema = Object.freeze({ validate: validateCandidateManifest });
var EvaluationCampaignSchema = Object.freeze({ validate: validateEvaluationCampaign });
var TestResultReferenceSchema = Object.freeze({ validate: validateTestResultReference });
var AgentEvaluationEvidenceSchema = Object.freeze({ validate: validateAgentEvaluationEvidence });
var QualificationStatementSchema = Object.freeze({ validate: validateQualificationStatement });
var QualificationStatusSchema = Object.freeze({ validate: validateQualificationStatus });
var RuntimeCandidateMeasurementSchema = Object.freeze({ validate: validateRuntimeCandidateMeasurement });

// ../../../../../private/tmp/emilia-ccs-aeb.TjuCWa/extracted/emilia-ccs-l1-aeb-e94314ab/packages/verify/dist/gate-qualification-promptfoo.js
var PROMPTFOO_QUALIFICATION_LIMITS = Object.freeze({
  max_input_bytes: 8 * 1024 * 1024,
  max_input_nodes: 65536,
  max_input_depth: 32,
  max_summary_results: 1e5
});
var MAX_ATTEMPTS = PROMPTFOO_QUALIFICATION_LIMITS.max_summary_results;
var MANIFEST_PIN_KEYS = /* @__PURE__ */ new Set([
  "id",
  "immutable_ref",
  "manifest",
  "manifest_digest"
]);
var HARNESS_PIN_KEYS = /* @__PURE__ */ new Set([
  ...MANIFEST_PIN_KEYS,
  "config_digest"
]);

// ../../../../../private/tmp/emilia-ccs-aeb.TjuCWa/extracted/emilia-ccs-l1-aeb-e94314ab/packages/verify/dist/consistency.js
import crypto3 from "crypto";
var HASH_PREFIX = /^sha256:/i;
function hexOf2(h) {
  return String(h || "").replace(HASH_PREFIX, "").toLowerCase();
}
function hashChildrenV2(left, right) {
  return crypto3.createHash("sha256").update(Buffer.concat([Buffer.from([1]), Buffer.from(left, "utf8"), Buffer.from(right, "utf8")])).digest("hex");
}
function isPowerOfTwo(n) {
  return n > 0 && (n & n - 1) === 0;
}
function verifyCheckpointConsistency(oldRoot, oldSize, newRoot, newSize, proof) {
  if (!Number.isInteger(oldSize) || !Number.isInteger(newSize))
    return false;
  if (oldSize < 0 || newSize < 0 || oldSize > newSize)
    return false;
  if (!Array.isArray(proof))
    return false;
  if (proof.length > 64)
    return false;
  const oldR = hexOf2(oldRoot);
  const newR = hexOf2(newRoot);
  if (!oldR || !newR)
    return false;
  if (oldSize === newSize) {
    return proof.length === 0 && oldR === newR;
  }
  if (oldSize === 0)
    return false;
  if (proof.length === 0)
    return false;
  const path = proof.map(hexOf2);
  if (path.some((h) => !h))
    return false;
  let node = path;
  let seed;
  if (isPowerOfTwo(oldSize)) {
    seed = oldR;
  } else {
    seed = node[0];
    node = node.slice(1);
  }
  let fn = oldSize - 1;
  let sn = newSize - 1;
  while (fn % 2 === 1) {
    fn = Math.floor(fn / 2);
    sn = Math.floor(sn / 2);
  }
  let fr = seed;
  let sr = seed;
  for (const c of node) {
    if (sn === 0)
      return false;
    if (fn % 2 === 1 || fn === sn) {
      fr = hashChildrenV2(c, fr);
      sr = hashChildrenV2(c, sr);
      while (fn % 2 === 0 && fn !== 0) {
        fn = Math.floor(fn / 2);
        sn = Math.floor(sn / 2);
      }
    } else {
      sr = hashChildrenV2(sr, c);
    }
    fn = Math.floor(fn / 2);
    sn = Math.floor(sn / 2);
  }
  return sn === 0 && fr === oldR && sr === newR;
}

// ../../../../../private/tmp/emilia-ccs-aeb.TjuCWa/extracted/emilia-ccs-l1-aeb-e94314ab/packages/verify/dist/witness.js
import crypto4 from "crypto";
var WITNESS_VERSION = "EP-WITNESS-v1";
var WITNESS_DOMAIN_TAG = "EP-WITNESS-COSIGN-v1\0";
var HASH_PREFIX2 = /^sha256:/i;
function hexOf3(h) {
  return String(h || "").replace(HASH_PREFIX2, "").toLowerCase();
}
function committedCheckpoint(checkpoint) {
  if (!checkpoint || typeof checkpoint !== "object" || Array.isArray(checkpoint))
    return null;
  const signed = { ...checkpoint };
  delete signed.log_signature;
  return signed;
}
function witnessSigningDigest(checkpoint) {
  const signed = committedCheckpoint(checkpoint);
  if (signed === null)
    return null;
  const preimage = Buffer.concat([
    Buffer.from(WITNESS_DOMAIN_TAG, "utf8"),
    Buffer.from(canonicalize(signed), "utf8")
  ]);
  return crypto4.createHash("sha256").update(preimage).digest();
}
function refuse(reason) {
  return { verified: false, witness_id: null, reason };
}
function verifyWitnessCosignature(checkpoint, cosignature, pinnedWitnessKey) {
  if (!checkpoint || typeof checkpoint !== "object" || Array.isArray(checkpoint)) {
    return refuse("checkpoint is missing or not an object");
  }
  if (!cosignature || typeof cosignature !== "object" || Array.isArray(cosignature)) {
    return refuse("cosignature is missing or not an object");
  }
  if (!pinnedWitnessKey || typeof pinnedWitnessKey !== "object") {
    return refuse("pinnedWitnessKey is missing");
  }
  const pinnedId = pinnedWitnessKey.witness_id;
  const pinnedPub = pinnedWitnessKey.public_key;
  if (typeof pinnedId !== "string" || !pinnedId) {
    return refuse("pinnedWitnessKey.witness_id is missing");
  }
  if (typeof pinnedPub !== "string" || !pinnedPub) {
    return refuse("pinnedWitnessKey.public_key is missing");
  }
  const coId = cosignature.witness_id;
  if (typeof coId !== "string" || !coId) {
    return refuse("cosignature.witness_id is missing");
  }
  if (coId !== pinnedId) {
    return refuse("cosignature witness_id is not the pinned witness (unpinned witness refused)");
  }
  if (cosignature.alg !== void 0 && cosignature.alg !== WITNESS_VERSION) {
    return refuse(`cosignature alg must be ${WITNESS_VERSION} when present`);
  }
  if (typeof cosignature.signature !== "string" || !cosignature.signature) {
    return refuse("cosignature.signature is missing");
  }
  if (cosignature.tree_size !== void 0 && cosignature.tree_size !== checkpoint.tree_size) {
    return refuse("cosignature tree_size does not match the checkpoint (cosignature for a different head)");
  }
  if (cosignature.root_hash !== void 0 && hexOf3(cosignature.root_hash) !== hexOf3(checkpoint.root_hash)) {
    return refuse("cosignature root_hash does not match the checkpoint (cosignature for a different head)");
  }
  if (cosignature.log_key_id !== void 0 && cosignature.log_key_id !== checkpoint.log_key_id) {
    return refuse("cosignature log_key_id does not match the checkpoint (cosignature for a different log)");
  }
  const digest4 = witnessSigningDigest(checkpoint);
  if (digest4 === null)
    return refuse("checkpoint could not be canonicalized");
  let ok = false;
  try {
    const keyObject2 = crypto4.createPublicKey({
      key: Buffer.from(pinnedPub, "base64url"),
      format: "der",
      type: "spki"
    });
    ok = crypto4.verify(null, digest4, keyObject2, Buffer.from(cosignature.signature, "base64url"));
  } catch (e) {
    return refuse(`cosignature verification failed: ${e instanceof Error ? e.message : String(e)}`);
  }
  if (!ok) {
    return refuse("cosignature does not verify over the checkpoint committed bytes");
  }
  return { verified: true, witness_id: coId };
}
function requireWitnessQuorum(checkpoint, cosignatures, pinnedWitnessKeys, k) {
  const reasons = [];
  const empty = { ok: false, met: 0, required: 0, witness_ids: [], reasons };
  if (!Number.isInteger(k) || k < 1) {
    reasons.push("k must be an integer >= 1");
    return { ...empty, required: typeof k === "number" ? k : 0 };
  }
  empty.required = k;
  if (!checkpoint || typeof checkpoint !== "object" || Array.isArray(checkpoint)) {
    reasons.push("checkpoint is missing or not an object");
    return { ok: false, met: 0, required: k, witness_ids: [], reasons };
  }
  if (!Array.isArray(cosignatures)) {
    reasons.push("cosignatures must be an array");
    return { ok: false, met: 0, required: k, witness_ids: [], reasons };
  }
  if (!Array.isArray(pinnedWitnessKeys)) {
    reasons.push("pinnedWitnessKeys must be an array");
    return { ok: false, met: 0, required: k, witness_ids: [], reasons };
  }
  const pinnedById = /* @__PURE__ */ new Map();
  const seenPinned = /* @__PURE__ */ new Set();
  const dupPinned = /* @__PURE__ */ new Set();
  for (const w of pinnedWitnessKeys) {
    const id = w && typeof w === "object" ? w.witness_id : void 0;
    if (typeof id !== "string" || !id) {
      reasons.push("a pinned witness entry is missing witness_id (dropped)");
      continue;
    }
    if (seenPinned.has(id)) {
      dupPinned.add(id);
      continue;
    }
    seenPinned.add(id);
    pinnedById.set(id, w);
  }
  for (const id of dupPinned) {
    pinnedById.delete(id);
    reasons.push(`pinned witness_id "${id}" appears more than once (dropped as ambiguous)`);
  }
  const met = /* @__PURE__ */ new Set();
  for (const cosig of cosignatures) {
    const id = cosig && typeof cosig === "object" ? cosig.witness_id : void 0;
    if (typeof id !== "string" || !id) {
      reasons.push("a cosignature is missing witness_id (ignored)");
      continue;
    }
    if (met.has(id)) {
      reasons.push(`duplicate cosignature from witness "${id}" (counted once)`);
      continue;
    }
    const pinned = pinnedById.get(id);
    if (!pinned) {
      reasons.push(`cosignature from unpinned witness "${id}" (ignored)`);
      continue;
    }
    const res = verifyWitnessCosignature(checkpoint, cosig, pinned);
    if (res.verified) {
      if (res.witness_id !== null)
        met.add(res.witness_id);
    } else {
      reasons.push(`cosignature from "${id}" did not verify: ${res.reason}`);
    }
  }
  const witness_ids = [...met].sort();
  return {
    ok: met.size >= k,
    met: met.size,
    required: k,
    witness_ids,
    reasons
  };
}

// ../../../../../private/tmp/emilia-ccs-aeb.TjuCWa/extracted/emilia-ccs-l1-aeb-e94314ab/packages/verify/dist/timestamp-proof.js
import crypto5 from "node:crypto";
var OID_SIGNED_DATA = "1.2.840.113549.1.7.2";
var OID_CT_TSTINFO = "1.2.840.113549.1.9.16.1.4";
var OID_CONTENT_TYPE = "1.2.840.113549.1.9.3";
var OID_MESSAGE_DIGEST = "1.2.840.113549.1.9.4";
var OID_SHA256 = "2.16.840.1.101.3.4.2.1";
var OID_SHA384 = "2.16.840.1.101.3.4.2.2";
var OID_SHA512 = "2.16.840.1.101.3.4.2.3";
var OID_RSA_ENCRYPTION = "1.2.840.113549.1.1.1";
var OID_ECDSA_WITH_SHA256 = "1.2.840.10045.4.3.2";
var OID_ECDSA_WITH_SHA384 = "1.2.840.10045.4.3.3";
var OID_ECDSA_WITH_SHA512 = "1.2.840.10045.4.3.4";
var DIGEST_OID_TO_NAME = {
  [OID_SHA256]: "sha256",
  [OID_SHA384]: "sha384",
  [OID_SHA512]: "sha512"
};
var DerError = class extends Error {
};
function readTLV(buf, offset) {
  if (offset + 2 > buf.length)
    throw new DerError("truncated TLV header");
  const first = buf[offset];
  const cls = (first & 192) >> 6;
  const constructed = (first & 32) !== 0;
  let tag = first & 31;
  let p = offset + 1;
  if (tag === 31) {
    tag = 0;
    let b;
    do {
      if (p >= buf.length)
        throw new DerError("truncated high tag");
      b = buf[p++];
      tag = tag << 7 | b & 127;
    } while (b & 128);
  }
  if (p >= buf.length)
    throw new DerError("truncated length");
  let len = buf[p++];
  if (len & 128) {
    const numBytes = len & 127;
    if (numBytes === 0)
      throw new DerError("indefinite length not allowed in DER");
    if (numBytes > 4)
      throw new DerError("length too large");
    if (p + numBytes > buf.length)
      throw new DerError("truncated long length");
    len = 0;
    for (let i = 0; i < numBytes; i++)
      len = len << 8 | buf[p++];
  }
  const contentStart = p;
  const contentEnd = p + len;
  if (contentEnd > buf.length)
    throw new DerError("content exceeds buffer");
  return { cls, constructed, tag, headerLen: contentStart - offset, contentStart, contentEnd, buf };
}
function* children(node) {
  let p = node.contentStart;
  while (p < node.contentEnd) {
    const child = readTLV(node.buf, p);
    yield child;
    p = child.contentEnd;
  }
}
function content(node) {
  return node.buf.subarray(node.contentStart, node.contentEnd);
}
function raw(node) {
  return node.buf.subarray(node.contentStart - node.headerLen, node.contentEnd);
}
function decodeOID(node) {
  if (node.tag !== 6 || node.cls !== 0)
    throw new DerError("expected OID");
  const b = content(node);
  if (b.length === 0)
    throw new DerError("empty OID");
  const first = b[0];
  const parts = [Math.floor(first / 40), first % 40];
  let value = 0;
  for (let i = 1; i < b.length; i++) {
    value = value << 7 | b[i] & 127;
    if (!(b[i] & 128)) {
      parts.push(value);
      value = 0;
    }
  }
  return parts.join(".");
}
function decodeGeneralizedTime(node) {
  const s = content(node).toString("latin1");
  let m = /^(\d{4})(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})(\.\d+)?Z$/.exec(s);
  if (node.tag === 24 && m) {
    const frac = m[7] ? m[7] : "";
    const iso = `${m[1]}-${m[2]}-${m[3]}T${m[4]}:${m[5]}:${m[6]}${frac}Z`;
    const ms = Date.parse(iso);
    return Number.isNaN(ms) ? null : { iso, ms };
  }
  m = /^(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})(\d{2})Z$/.exec(s);
  if (node.tag === 23 && m) {
    const yy = parseInt(m[1], 10);
    const year = yy < 50 ? 2e3 + yy : 1900 + yy;
    const iso = `${year}-${m[2]}-${m[3]}T${m[4]}:${m[5]}:${m[6]}Z`;
    const ms = Date.parse(iso);
    return Number.isNaN(ms) ? null : { iso, ms };
  }
  return null;
}
function hexOf4(h) {
  if (Buffer.isBuffer(h))
    return h.toString("hex").toLowerCase();
  const s = String(h ?? "").replace(/^sha256:/i, "").replace(/^sha384:/i, "").replace(/^sha512:/i, "").toLowerCase();
  return /^[0-9a-f]+$/.test(s) && s.length % 2 === 0 && s.length >= 40 ? s : "";
}
function keyIdOfSpki(spkiDer) {
  return "sha256:" + crypto5.createHash("sha256").update(spkiDer).digest("hex");
}
function loadPinnedKey(pinned) {
  try {
    if (!pinned)
      return null;
    if (typeof pinned === "string" && pinned.includes("-----BEGIN")) {
      return { key: crypto5.createPublicKey(pinned), spkiDer: crypto5.createPublicKey(pinned).export({ type: "spki", format: "der" }) };
    }
    const der = Buffer.from(String(pinned).replace(/\s+/g, ""), "base64");
    if (der.length === 0)
      return null;
    const key = crypto5.createPublicKey({ key: der, format: "der", type: "spki" });
    return { key, spkiDer: key.export({ type: "spki", format: "der" }) };
  } catch {
    return null;
  }
}
function resolveSignatureAlg(sigAlgOid, digestName, keyType) {
  if (sigAlgOid === OID_RSA_ENCRYPTION || keyType === "rsa") {
    return digestName ? { hash: digestName } : null;
  }
  if (sigAlgOid === OID_ECDSA_WITH_SHA256)
    return { hash: "sha256", dsaEncoding: "der" };
  if (sigAlgOid === OID_ECDSA_WITH_SHA384)
    return { hash: "sha384", dsaEncoding: "der" };
  if (sigAlgOid === OID_ECDSA_WITH_SHA512)
    return { hash: "sha512", dsaEncoding: "der" };
  return null;
}
function verifyTimestampProof(timestampProof, expectedDigest, pinnedTsaKeys) {
  const refuse2 = (reason) => ({ verified: false, tsa_key_id: null, gen_time: null, reason });
  if (timestampProof === void 0 || timestampProof === null || typeof timestampProof !== "string" && !Buffer.isBuffer(timestampProof) || typeof timestampProof === "string" && timestampProof.trim() === "") {
    return refuse2("missing_token");
  }
  const wantDigest = hexOf4(expectedDigest);
  if (!wantDigest)
    return refuse2("missing_or_malformed_expected_digest");
  const pinnedList = [];
  if (Array.isArray(pinnedTsaKeys))
    pinnedList.push(...pinnedTsaKeys);
  else if (pinnedTsaKeys && typeof pinnedTsaKeys === "object")
    pinnedList.push(...Object.values(pinnedTsaKeys));
  else if (pinnedTsaKeys)
    pinnedList.push(pinnedTsaKeys);
  const loadedKeys = pinnedList.map(loadPinnedKey).filter((key) => key !== null);
  if (loadedKeys.length === 0)
    return refuse2("unpinned_tsa");
  let der;
  try {
    der = Buffer.isBuffer(timestampProof) ? timestampProof : Buffer.from(timestampProof.replace(/\s+/g, ""), "base64");
    if (der.length === 0)
      return refuse2("unparseable_token");
  } catch {
    return refuse2("unparseable_token");
  }
  let parsed;
  try {
    parsed = parseTimeStampToken(der);
  } catch {
    return refuse2("unparseable_token");
  }
  if (parsed.error || !parsed.tstInfo || !parsed.signerInfo || !parsed.eContentRaw)
    return refuse2(parsed.error ?? "unparseable_token");
  const { tstInfo, signerInfo, eContentRaw } = parsed;
  const imprintHex = tstInfo.messageImprintHex;
  if (imprintHex !== wantDigest)
    return refuse2("digest_mismatch");
  if (!tstInfo.genTime)
    return refuse2("unparseable_token");
  const sigResult = verifySignerInfo(signerInfo, eContentRaw, loadedKeys);
  if (!sigResult.ok)
    return refuse2(sigResult.reason);
  return {
    verified: true,
    // sigResult.ok was just checked truthy above; verifySignerInfo only sets
    // tsaKeyId on its `{ ok: true, tsaKeyId }` return (line 490), so it's
    // guaranteed present here even though TS can't correlate the two
    // optional props across the inferred union.
    tsa_key_id: (
      /** @type {string} */
      sigResult.tsaKeyId
    ),
    gen_time: tstInfo.genTime
  };
}
function parseTimeStampToken(der) {
  const contentInfo = readTLV(der, 0);
  if (contentInfo.tag !== 16 || !contentInfo.constructed)
    return { error: "unparseable_token" };
  const ciKids = [...children(contentInfo)];
  if (ciKids.length < 2)
    return { error: "unparseable_token" };
  if (decodeOID(ciKids[0]) !== OID_SIGNED_DATA)
    return { error: "not_signed_data" };
  const explicit0 = ciKids[1];
  if (explicit0.cls !== 2 || explicit0.tag !== 0 || !explicit0.constructed)
    return { error: "unparseable_token" };
  const signedData = [...children(explicit0)][0];
  if (!signedData || signedData.tag !== 16)
    return { error: "unparseable_token" };
  const sdKids = [...children(signedData)];
  if (sdKids.length < 4)
    return { error: "unparseable_token" };
  const encap = sdKids[2];
  let signerInfos = null;
  for (let i = sdKids.length - 1; i >= 3; i--) {
    if (sdKids[i].tag === 17 && sdKids[i].cls === 0) {
      signerInfos = sdKids[i];
      break;
    }
  }
  if (!encap || encap.tag !== 16)
    return { error: "unparseable_token" };
  if (!signerInfos)
    return { error: "unparseable_token" };
  const encapKids = [...children(encap)];
  if (encapKids.length < 2)
    return { error: "unparseable_token" };
  if (decodeOID(encapKids[0]) !== OID_CT_TSTINFO)
    return { error: "not_a_timestamp_token" };
  const eContentExplicit = encapKids[1];
  if (eContentExplicit.cls !== 2 || eContentExplicit.tag !== 0)
    return { error: "unparseable_token" };
  const octet = [...children(eContentExplicit)][0];
  if (!octet || octet.tag !== 4)
    return { error: "unparseable_token" };
  const eContentRaw = content(octet);
  const tstInfo = parseTstInfo(eContentRaw);
  if ("error" in tstInfo && tstInfo.error)
    return { error: tstInfo.error };
  const siList = [...children(signerInfos)];
  if (siList.length !== 1)
    return { error: "unsupported_signerinfo_count" };
  const signerInfo = parseSignerInfo(siList[0]);
  if ("error" in signerInfo && signerInfo.error)
    return { error: signerInfo.error };
  return { tstInfo, signerInfo, eContentRaw };
}
function parseTstInfo(der) {
  try {
    const seq = readTLV(der, 0);
    if (seq.tag !== 16)
      return { error: "unparseable_token" };
    const kids = [...children(seq)];
    if (kids.length < 5)
      return { error: "unparseable_token" };
    const mi = kids[2];
    if (mi.tag !== 16)
      return { error: "unparseable_token" };
    const miKids = [...children(mi)];
    if (miKids.length < 2)
      return { error: "unparseable_token" };
    const hashAlgSeq = miKids[0];
    const hashAlgOid = decodeOID([...children(hashAlgSeq)][0]);
    const hashedMessage = miKids[1];
    if (hashedMessage.tag !== 4)
      return { error: "unparseable_token" };
    const messageImprintHex = content(hashedMessage).toString("hex").toLowerCase();
    let genTime = null;
    for (let i = 3; i < kids.length; i++) {
      if (kids[i].tag === 24 || kids[i].tag === 23) {
        const t = decodeGeneralizedTime(kids[i]);
        if (t)
          genTime = t.iso;
        break;
      }
    }
    return { messageImprintHex, imprintAlgOid: hashAlgOid, genTime };
  } catch {
    return { error: "unparseable_token" };
  }
}
function parseSignerInfo(node) {
  try {
    if (node.tag !== 16)
      return { error: "unparseable_token" };
    const kids = [...children(node)];
    let idx = 0;
    const version = kids[idx++];
    if (!version || version.tag !== 2)
      return { error: "unparseable_token" };
    const sid = kids[idx++];
    if (!sid)
      return { error: "unparseable_token" };
    const digestAlg = kids[idx++];
    if (!digestAlg || digestAlg.tag !== 16)
      return { error: "unparseable_token" };
    const digestAlgOid = decodeOID([...children(digestAlg)][0]);
    let signedAttrs = null;
    if (kids[idx] && kids[idx].cls === 2 && kids[idx].tag === 0 && kids[idx].constructed) {
      signedAttrs = kids[idx++];
    }
    const sigAlg = kids[idx++];
    if (!sigAlg || sigAlg.tag !== 16)
      return { error: "unparseable_token" };
    const sigAlgOid = decodeOID([...children(sigAlg)][0]);
    const sigOctet = kids[idx++];
    if (!sigOctet || sigOctet.tag !== 4)
      return { error: "unparseable_token" };
    const signature = content(sigOctet);
    return {
      digestAlgOid,
      digestName: DIGEST_OID_TO_NAME[digestAlgOid] || null,
      signedAttrs,
      sigAlgOid,
      signature
    };
  } catch {
    return { error: "unparseable_token" };
  }
}
function parseAttributes(setNode) {
  const out = {};
  for (const attr of children(setNode)) {
    if (attr.tag !== 16)
      continue;
    const kids = [...children(attr)];
    if (kids.length < 2)
      continue;
    const oid = decodeOID(kids[0]);
    const valuesSet = kids[1];
    out[oid] = [...children(valuesSet)];
  }
  return out;
}
function verifySignerInfo(signerInfo, eContentRaw, loadedKeys) {
  const { digestName, signedAttrs, sigAlgOid, signature } = signerInfo;
  if (!digestName)
    return { ok: false, reason: "unsupported_digest_algorithm" };
  let signedBytes;
  if (signedAttrs) {
    const attrs = parseAttributes(signedAttrs);
    const ctNodes = attrs[OID_CONTENT_TYPE];
    if (!ctNodes || ctNodes.length !== 1)
      return { ok: false, reason: "missing_content_type_attr" };
    let ctOid;
    try {
      ctOid = decodeOID(ctNodes[0]);
    } catch {
      return { ok: false, reason: "unparseable_token" };
    }
    if (ctOid !== OID_CT_TSTINFO)
      return { ok: false, reason: "content_type_attr_mismatch" };
    const mdNodes = attrs[OID_MESSAGE_DIGEST];
    if (!mdNodes || mdNodes.length !== 1 || mdNodes[0].tag !== 4) {
      return { ok: false, reason: "missing_message_digest_attr" };
    }
    const attrDigest = content(mdNodes[0]);
    const eContentDigest = crypto5.createHash(digestName).update(eContentRaw).digest();
    if (!attrDigest.equals(eContentDigest))
      return { ok: false, reason: "message_digest_attr_mismatch" };
    const attrsBody = raw(signedAttrs).subarray(signedAttrs.headerLen);
    signedBytes = Buffer.concat([derSetHeader(attrsBody.length), attrsBody]);
  } else {
    signedBytes = eContentRaw;
  }
  for (const { key, spkiDer } of loadedKeys) {
    const keyType = key.asymmetricKeyType;
    const alg = resolveSignatureAlg(sigAlgOid, digestName, keyType);
    if (!alg)
      continue;
    if (sigAlgOid === OID_RSA_ENCRYPTION && keyType !== "rsa")
      continue;
    if ((sigAlgOid === OID_ECDSA_WITH_SHA256 || sigAlgOid === OID_ECDSA_WITH_SHA384 || sigAlgOid === OID_ECDSA_WITH_SHA512) && keyType !== "ec")
      continue;
    try {
      const verifyOpts = { key };
      if (alg.dsaEncoding)
        verifyOpts.dsaEncoding = alg.dsaEncoding;
      const ok = crypto5.verify(alg.hash, signedBytes, verifyOpts, signature);
      if (ok)
        return { ok: true, tsaKeyId: keyIdOfSpki(spkiDer) };
    } catch {
    }
  }
  return { ok: false, reason: "bad_signature" };
}
function derSetHeader(len) {
  if (len < 128)
    return Buffer.from([49, len]);
  const bytes = [];
  let n = len;
  while (n > 0) {
    bytes.unshift(n & 255);
    n >>= 8;
  }
  return Buffer.from([49, 128 | bytes.length, ...bytes]);
}

// ../../../../../private/tmp/emilia-ccs-aeb.TjuCWa/extracted/emilia-ccs-l1-aeb-e94314ab/packages/verify/dist/currency.js
var hexOf5 = (h) => {
  const s = String(h ?? "").replace(/^sha256:/, "").toLowerCase();
  return /^[0-9a-f]{64}$/.test(s) ? s : "";
};
var RFC3339_INSTANT2 = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})(?:\.\d{1,9})?(?:Z|([+-])(\d{2}):(\d{2}))$/;
function instantMs4(value) {
  if (typeof value !== "string")
    return NaN;
  const match = value.match(RFC3339_INSTANT2);
  if (!match)
    return NaN;
  const [, y, mo, d, h, mi, s, , oh, om] = match;
  const calendar = /* @__PURE__ */ new Date(0);
  calendar.setUTCFullYear(Number(y), Number(mo) - 1, Number(d));
  calendar.setUTCHours(Number(h), Number(mi), Number(s), 0);
  if (calendar.toISOString().slice(0, 19) !== `${y}-${mo}-${d}T${h}:${mi}:${s}`)
    return NaN;
  if (oh !== void 0 && (Number(oh) > 23 || Number(om) > 59))
    return NaN;
  return Date.parse(value);
}
function referenceTimeMs(value) {
  if (value === void 0)
    return Date.now();
  if (value instanceof Date)
    return value.getTime();
  if (typeof value === "number")
    return Number.isFinite(value) ? value : NaN;
  return instantMs4(value);
}
var CURRENCY_STATUS = Object.freeze(["fresh", "stale", "unknown"]);
var CURRENCY_REASON = Object.freeze({
  // status: 'unknown'
  offline_only_no_fresh_head: "offline_only_no_fresh_head",
  fresh_head_malformed: "fresh_head_malformed",
  now_invalid: "now_invalid",
  // status: 'stale'
  fresh_head_stale: "fresh_head_stale",
  fresh_head_in_future: "fresh_head_in_future",
  fresh_head_required_but_absent: "fresh_head_required_but_absent",
  revoked_by_fresh_head: "revoked_by_fresh_head",
  max_staleness_invalid: "max_staleness_invalid",
  // status: 'fresh'
  fresh_head_within_window: "fresh_head_within_window"
});
function headRevokesReceipt(freshHead, receipt) {
  if (freshHead && freshHead.revoked === true)
    return true;
  const list = freshHead && freshHead.revoked_target_hashes;
  if (Array.isArray(list) && list.length > 0) {
    const targets = new Set(list.map(hexOf5).filter(Boolean));
    if (targets.size === 0)
      return false;
    const receiptActionHash = hexOf5(receipt?.action_hash);
    const explicitTarget = hexOf5(freshHead?.target_hash);
    if (receiptActionHash && targets.has(receiptActionHash))
      return true;
    if (explicitTarget && targets.has(explicitTarget))
      return true;
  }
  return false;
}
function evaluateCurrency(args = {}) {
  const { receipt, authentic_as_of_commit, now, maxStalenessSeconds, freshHead, freshHeadRequired } = args && typeof args === "object" ? args : {};
  const authentic = authentic_as_of_commit === true;
  const nowMs = referenceTimeMs(now);
  const evaluated_at = Number.isFinite(nowMs) ? new Date(nowMs).toISOString() : null;
  const result = (status, reason) => ({
    authentic_as_of_commit: authentic,
    currency_at_T: { status, evaluated_at, reason }
  });
  if (freshHead === void 0 || freshHead === null) {
    if (freshHeadRequired === true) {
      return result("stale", CURRENCY_REASON.fresh_head_required_but_absent);
    }
    return result("unknown", CURRENCY_REASON.offline_only_no_fresh_head);
  }
  if (!Number.isFinite(nowMs)) {
    return result("unknown", CURRENCY_REASON.now_invalid);
  }
  if (typeof freshHead !== "object") {
    return result("unknown", CURRENCY_REASON.fresh_head_malformed);
  }
  let headMs = instantMs4(freshHead.observed_at);
  if (!Number.isFinite(headMs))
    headMs = instantMs4(freshHead.issued_at);
  if (!Number.isFinite(headMs)) {
    return result("unknown", CURRENCY_REASON.fresh_head_malformed);
  }
  if (typeof maxStalenessSeconds !== "number" || !Number.isFinite(maxStalenessSeconds) || maxStalenessSeconds < 0) {
    return result("stale", CURRENCY_REASON.max_staleness_invalid);
  }
  const ageSeconds = (nowMs - headMs) / 1e3;
  if (ageSeconds < 0) {
    return result("stale", CURRENCY_REASON.fresh_head_in_future);
  }
  if (headRevokesReceipt(freshHead, receipt)) {
    return result("stale", CURRENCY_REASON.revoked_by_fresh_head);
  }
  if (ageSeconds > maxStalenessSeconds) {
    return result("stale", CURRENCY_REASON.fresh_head_stale);
  }
  return result("fresh", CURRENCY_REASON.fresh_head_within_window);
}

// ../../../../../private/tmp/emilia-ccs-aeb.TjuCWa/extracted/emilia-ccs-l1-aeb-e94314ab/packages/verify/dist/consumption-proof.js
import crypto6 from "crypto";
var SMT_DEPTH = 32;
var HASH_PREFIX3 = /^sha256:/i;
var HEX_ONLY = /^[0-9a-f]+$/;
function hexOf6(h) {
  return String(h == null ? "" : h).replace(HASH_PREFIX3, "").toLowerCase();
}
function isHex64(h) {
  return typeof h === "string" && h.length === 64 && HEX_ONLY.test(h);
}
function hashBranch(left, right) {
  return crypto6.createHash("sha256").update(Buffer.concat([Buffer.from([1]), Buffer.from(left, "utf8"), Buffer.from(right, "utf8")])).digest("hex");
}
function presentLeaf(keyHex, valueHex) {
  return crypto6.createHash("sha256").update(Buffer.concat([Buffer.from([2]), Buffer.from(keyHex, "utf8"), Buffer.from(valueHex, "utf8")])).digest("hex");
}
function defaultLeaf() {
  return crypto6.createHash("sha256").update(Buffer.from([3])).digest("hex");
}
function nonceKeyHex(nonce) {
  return crypto6.createHash("sha256").update(Buffer.from(String(nonce), "utf8")).digest("hex");
}
function pathBit(keyHex, i) {
  const byteIndex = i >> 3;
  const byte = parseInt(keyHex.substr(byteIndex * 2, 2), 16);
  return byte >> 7 - (i & 7) & 1;
}
function foldToRoot(leafHex, siblings, keyHex, depth) {
  if (!isHex64(leafHex))
    return null;
  if (!Array.isArray(siblings) || siblings.length !== depth)
    return null;
  let node = leafHex;
  for (let level = depth - 1; level >= 0; level--) {
    const sib = hexOf6(siblings[level]);
    if (!isHex64(sib))
      return null;
    const bit = pathBit(keyHex, level);
    node = bit === 0 ? hashBranch(node, sib) : hashBranch(sib, node);
  }
  return node;
}
function checkSub(sub, keyHex, label) {
  if (!sub || typeof sub !== "object")
    return { ok: false, reason: `${label}_missing` };
  const proof = sub;
  const root = hexOf6(proof.root);
  if (!isHex64(root))
    return { ok: false, reason: `${label}_root_malformed` };
  if (!Array.isArray(proof.siblings) || proof.siblings.length !== SMT_DEPTH) {
    return { ok: false, reason: `${label}_siblings_wrong_length` };
  }
  let leaf;
  if (proof.present === true) {
    const value = hexOf6(proof.value);
    if (!isHex64(value))
      return { ok: false, reason: `${label}_present_value_malformed` };
    leaf = presentLeaf(keyHex, value);
  } else if (proof.present === false) {
    leaf = defaultLeaf();
  } else {
    return { ok: false, reason: `${label}_present_flag_missing` };
  }
  const reconstructed = foldToRoot(leaf, proof.siblings, keyHex, SMT_DEPTH);
  if (reconstructed === null)
    return { ok: false, reason: `${label}_sibling_malformed` };
  if (reconstructed !== root)
    return { ok: false, reason: `${label}_does_not_reconstruct_root` };
  return { ok: true };
}
function verifyConsumptionProof(bundle) {
  const checks = { non_inclusion: false, inclusion: false, consistency: false };
  const fail3 = (reason) => ({ valid: false, checks, reason });
  if (!bundle || typeof bundle !== "object")
    return fail3("bundle_missing");
  const b = bundle;
  if (typeof b.nonce !== "string" || b.nonce.length === 0)
    return fail3("nonce_missing");
  const keyHex = nonceKeyHex(b.nonce);
  const ni = b.non_inclusion_proof;
  if (!ni || typeof ni !== "object")
    return fail3("non_inclusion_proof_missing");
  if (ni.present !== false)
    return fail3("non_inclusion_proof_must_assert_absent");
  const niRes = checkSub(ni, keyHex, "non_inclusion");
  if (!niRes.ok)
    return fail3(niRes.reason ?? "non_inclusion_invalid");
  checks.non_inclusion = true;
  const inc = b.inclusion_proof;
  if (!inc || typeof inc !== "object")
    return fail3("inclusion_proof_missing");
  if (inc.present !== true)
    return fail3("inclusion_proof_must_assert_present");
  const incRes = checkSub(inc, keyHex, "inclusion");
  if (!incRes.ok)
    return fail3(incRes.reason ?? "inclusion_invalid");
  checks.inclusion = true;
  if (hexOf6(ni.root) === hexOf6(inc.root))
    return fail3("smt_root_unchanged_no_transition");
  const cps = b.checkpoints;
  if (!cps || typeof cps !== "object" || !cps.h1 || !cps.h2)
    return fail3("checkpoints_missing");
  const h1Size = cps.h1.tree_size;
  const h2Size = cps.h2.tree_size;
  const h1Root = hexOf6(cps.h1.root_hash);
  const h2Root = hexOf6(cps.h2.root_hash);
  if (typeof h1Size !== "number" || !Number.isInteger(h1Size) || h1Size < 1 || !isHex64(h1Root))
    return fail3("checkpoint_h1_malformed");
  if (typeof h2Size !== "number" || !Number.isInteger(h2Size) || h2Size < 1 || !isHex64(h2Root))
    return fail3("checkpoint_h2_malformed");
  if (!(h1Size < h2Size))
    return fail3("checkpoint_h1_not_before_h2");
  if (!Array.isArray(b.consistency_proof))
    return fail3("consistency_proof_missing");
  if (!verifyCheckpointConsistency(h1Root, h1Size, h2Root, h2Size, b.consistency_proof)) {
    return fail3("consistency_proof_not_append_only");
  }
  checks.consistency = true;
  return { valid: true, checks, reason: null };
}

// ../../../../../private/tmp/emilia-ccs-aeb.TjuCWa/extracted/emilia-ccs-l1-aeb-e94314ab/packages/verify/dist/hostile-text.js
var BIDI_CODEPOINTS = /* @__PURE__ */ new Set([
  8234,
  8235,
  8236,
  8237,
  8238,
  // LRE RLE PDF LRO RLO
  8294,
  8295,
  8296,
  8297,
  // LRI RLI FSI PDI
  8206,
  8207,
  1564
  // LRM RLM ALM
]);
var INVISIBLE_CODEPOINTS = /* @__PURE__ */ new Set([
  8203,
  8204,
  8205,
  8288,
  65279
]);
function isControlCodepoint(cp) {
  return cp <= 31 && cp !== 9 && cp !== 10 && cp !== 13 || cp >= 127 && cp <= 159;
}
function isHostileCodepoint(cp) {
  return BIDI_CODEPOINTS.has(cp) || INVISIBLE_CODEPOINTS.has(cp) || isControlCodepoint(cp);
}
function escapeCodepoint(cp) {
  return `<U+${cp.toString(16).toUpperCase().padStart(4, "0")}>`;
}

// ../../../../../private/tmp/emilia-ccs-aeb.TjuCWa/extracted/emilia-ccs-l1-aeb-e94314ab/packages/verify/dist/initiator-attestation.js
var INITIATOR_ATTESTATION_VERSION = "EP-INITIATOR-ATTESTATION-v1";
var INITIATOR_STATEMENT_MAX = 280;
var ATTESTATION_MEMBERS = Object.freeze([
  "@version",
  "model_id",
  "model_version",
  "tool_chain_digest",
  "statement"
]);
var ATTESTATION_MEMBER_SET = new Set(ATTESTATION_MEMBERS);
var REQUIRED_STRING_MEMBERS = Object.freeze(["model_id", "model_version"]);
function normalizeDigest(h) {
  const s = String(h ?? "").replace(/^sha256:/i, "").toLowerCase();
  return /^[0-9a-f]{64}$/.test(s) ? s : "";
}
var CYRILLIC_RE = /[Ѐ-ӿ]/;
var GREEK_RE = /[Ͱ-Ͽ]/;
var ASCII_LETTER_RE = /[A-Za-z]/;
function neutralizeStatement(statement2) {
  const raw2 = typeof statement2 === "string" ? statement2 : "";
  const cps = Array.from(raw2);
  const truncated = cps.length > INITIATOR_STATEMENT_MAX;
  const bounded = truncated ? cps.slice(0, INITIATOR_STATEMENT_MAX) : cps;
  const escaped = [];
  let changed = false;
  let hasNonAsciiLetter = false;
  let hasAsciiLetter = false;
  let hasConfusableScript = false;
  const out = bounded.map((ch) => {
    const cp = ch.codePointAt(0);
    if (ASCII_LETTER_RE.test(ch))
      hasAsciiLetter = true;
    if (cp > 127 && /\p{L}/u.test(ch))
      hasNonAsciiLetter = true;
    if (CYRILLIC_RE.test(ch) || GREEK_RE.test(ch))
      hasConfusableScript = true;
    if (isHostileCodepoint(cp)) {
      changed = true;
      escaped.push(cp);
      return escapeCodepoint(cp);
    }
    return ch;
  });
  const homoglyph_risk = hasConfusableScript || hasNonAsciiLetter && hasAsciiLetter;
  return {
    safe: out.join(""),
    changed,
    homoglyph_risk,
    escaped_codepoints: escaped,
    truncated
  };
}
function validateInitiatorAttestation(att) {
  const errors = [];
  const fail3 = () => ({ ok: false, normalized: null, errors, statement_report: null });
  if (!att || typeof att !== "object" || Array.isArray(att)) {
    errors.push("initiator attestation must be a non-array object");
    return fail3();
  }
  const a = att;
  for (const key of Object.keys(att)) {
    if (!ATTESTATION_MEMBER_SET.has(key)) {
      errors.push(`unknown member "${key}" (allowed: ${ATTESTATION_MEMBERS.join(", ")})`);
    }
  }
  if (a["@version"] !== void 0 && a["@version"] !== INITIATOR_ATTESTATION_VERSION) {
    errors.push(`@version must be ${INITIATOR_ATTESTATION_VERSION} when present`);
  }
  for (const key of REQUIRED_STRING_MEMBERS) {
    const v = a[key];
    if (typeof v !== "string" || v.length === 0) {
      errors.push(`${key} is required and must be a non-empty string`);
    }
  }
  const digestHex = normalizeDigest(a.tool_chain_digest);
  if (a.tool_chain_digest === void 0 || a.tool_chain_digest === null) {
    errors.push("tool_chain_digest is required");
  } else if (digestHex === "") {
    errors.push('tool_chain_digest must be a well-formed SHA-256 (optionally "sha256:"-prefixed 64-hex)');
  }
  let statementReport = null;
  if (a.statement !== void 0) {
    if (typeof a.statement !== "string") {
      errors.push("statement, when present, must be a string");
    } else if (Array.from(a.statement).length > INITIATOR_STATEMENT_MAX) {
      errors.push(`statement exceeds the ${INITIATOR_STATEMENT_MAX}-character cap`);
    }
  }
  if (errors.length)
    return fail3();
  if (a.statement !== void 0) {
    statementReport = neutralizeStatement(a.statement);
  }
  const normalized = {
    "@version": INITIATOR_ATTESTATION_VERSION,
    model_id: a.model_id,
    model_version: a.model_version,
    tool_chain_digest: `sha256:${digestHex}`
  };
  if (statementReport)
    normalized.statement = statementReport.safe;
  return { ok: true, normalized, errors, statement_report: statementReport };
}

// ../../../../../private/tmp/emilia-ccs-aeb.TjuCWa/extracted/emilia-ccs-l1-aeb-e94314ab/packages/verify/dist/surface-binding.js
var BINDING_MEMBERS = Object.freeze([
  "@version",
  "surface_kind",
  "attestation_digest",
  "verifier_hint"
]);
var BINDING_MEMBER_SET = new Set(BINDING_MEMBERS);

// ../../../../../private/tmp/emilia-ccs-aeb.TjuCWa/extracted/emilia-ccs-l1-aeb-e94314ab/packages/verify/dist/quorum.js
import crypto7 from "node:crypto";
function rosterSlotKey(role, approver) {
  return JSON.stringify([role, approver]);
}
function spkiFingerprint(value) {
  try {
    const key = crypto7.createPublicKey({
      key: Buffer.from(String(value), "base64url"),
      format: "der",
      type: "spki"
    });
    const der = key.export({ type: "spki", format: "der" });
    return crypto7.createHash("sha256").update(der).digest("hex");
  } catch {
    return null;
  }
}
function verifyQuorum(quorum, opts = {}) {
  const checks = {
    all_signatures_valid: false,
    // every member's device assertion verifies
    action_binding: false,
    // every member signed the SAME quorum action_hash
    distinct_humans: false,
    // no human fills two slots (separation of duties)
    distinct_keys: false,
    // no single device key fills two slots
    initiator_excluded: false,
    // the action's initiator is not one of the approvers (SoD)
    roles_admitted: false,
    // each (role, approver) is an eligible policy slot
    threshold_met: false,
    // >= required distinct valid approvers
    order_satisfied: false,
    // ordered mode: signed in policy sequence, increasing time
    chain_linked: false,
    // ordered mode: each signoff cryptographically chains to its predecessor
    within_window: false
    // all signatures within window_sec
  };
  const memberResults = [];
  try {
    const policy = quorum?.policy;
    const members = Array.isArray(quorum?.members) ? quorum.members : null;
    const actionHash = quorum?.action_hash;
    if (!policy || !members || members.length === 0 || typeof actionHash !== "string" || !actionHash) {
      return { valid: false, checks, members: memberResults };
    }
    const mode = policy.mode;
    if (mode !== "ordered" && mode !== "threshold") {
      return { valid: false, checks, members: memberResults };
    }
    const distinctHumans = policy.distinct_humans !== false;
    const windowSec = typeof policy.window_sec === "number" && Number.isFinite(policy.window_sec) ? policy.window_sec : 900;
    const eligible = Array.isArray(policy.approvers) ? policy.approvers : [];
    const required = typeof policy.required === "number" && Number.isInteger(policy.required) && policy.required > 0 ? policy.required : NaN;
    if (!Number.isInteger(required) || required <= 0 || eligible.length === 0 || required > eligible.length) {
      return { valid: false, checks, members: memberResults };
    }
    let allSigsValid = true;
    let allBound = true;
    const approverIds = [];
    const issuedAts = [];
    for (const m of members) {
      const r = verifyWebAuthnSignoff(m?.signoff, String(m?.approver_public_key ?? ""), opts);
      const approver = m?.signoff?.context?.approver ?? null;
      const role = m?.role ?? null;
      memberResults.push({ approver, role, valid: !!r.valid });
      if (!r.valid)
        allSigsValid = false;
      if (m?.signoff?.context?.action_hash !== actionHash)
        allBound = false;
      approverIds.push(approver);
      const t = Date.parse(typeof m?.signoff?.context?.issued_at === "string" ? m.signoff.context.issued_at : "");
      issuedAts.push(Number.isNaN(t) ? null : t);
    }
    checks.all_signatures_valid = allSigsValid;
    checks.action_binding = allBound;
    const counted = members.map((m, i) => ({ m, i, ok: memberResults[i].valid && m?.signoff?.context?.action_hash === actionHash })).filter((x) => x.ok);
    const countedApprovers = counted.map((x) => x.m?.signoff?.context?.approver);
    checks.distinct_humans = distinctHumans ? new Set(countedApprovers).size === countedApprovers.length : true;
    const countedKeys = counted.map((x) => spkiFingerprint(x.m?.approver_public_key));
    checks.distinct_keys = countedKeys.every(Boolean) && new Set(countedKeys).size === countedKeys.length;
    const countedInitiators = counted.map((x) => x.m?.signoff?.context?.initiator);
    const initiator = countedInitiators[0];
    checks.initiator_excluded = counted.length > 0 && typeof initiator === "string" && initiator.length > 0 && countedInitiators.every((v) => v === initiator) && !countedApprovers.includes(initiator);
    const eligibleSet = new Set(eligible.map((e) => rosterSlotKey(e.role, e.approver)));
    checks.roles_admitted = counted.length > 0 && counted.every((x) => eligibleSet.has(rosterSlotKey(x.m?.role, x.m?.signoff?.context?.approver)));
    const distinctEligible = new Set(counted.filter((x) => eligibleSet.has(rosterSlotKey(x.m?.role, x.m?.signoff?.context?.approver))).map((x) => x.m?.signoff?.context?.approver));
    checks.threshold_met = distinctEligible.size >= required;
    if (mode === "ordered") {
      const seqRolesOk = members.length <= eligible.length && members.every((member, idx) => member?.role === eligible[idx]?.role && member?.signoff?.context?.approver === eligible[idx]?.approver);
      const times = issuedAts.slice(0, members.length);
      const timesOk = times.every((t, idx) => {
        const previous = times[idx - 1];
        return t !== null && (idx === 0 || typeof previous === "number" && t > previous);
      });
      checks.order_satisfied = members.length >= required && seqRolesOk && timesOk;
    } else {
      checks.order_satisfied = true;
    }
    if (mode === "ordered" && policy.ordered_chain === true) {
      const seq = members;
      let linked = seq.length >= required && seq.length <= eligible.length;
      for (let idx = 0; idx < seq.length; idx++) {
        const prev = seq[idx]?.signoff?.context?.prev_context_hash;
        if (idx === 0) {
          if (prev !== void 0 && prev !== null)
            linked = false;
        } else if (prev !== contextChainHash(seq[idx - 1]?.signoff?.context ?? {})) {
          linked = false;
        }
      }
      checks.chain_linked = linked;
    } else {
      checks.chain_linked = true;
    }
    const ts = counted.map((x) => issuedAts[x.i]).filter((t) => t !== null);
    checks.within_window = ts.length === counted.length && counted.length > 0 && Math.max(...ts) - Math.min(...ts) <= windowSec * 1e3;
  } catch {
    return { valid: false, checks, members: memberResults };
  }
  const valid = checks.all_signatures_valid && checks.action_binding && checks.distinct_humans && checks.distinct_keys && checks.initiator_excluded && checks.roles_admitted && checks.threshold_met && checks.order_satisfied && checks.chain_linked && checks.within_window;
  return { valid, checks, members: memberResults };
}

// ../../../../../private/tmp/emilia-ccs-aeb.TjuCWa/extracted/emilia-ccs-l1-aeb-e94314ab/packages/verify/dist/index.js
var FATAL_UTF82 = new TextDecoder("utf-8", { fatal: true });
function decodeBase64url(value) {
  if (typeof value !== "string" || value.length === 0 || !/^[A-Za-z0-9_-]+$/.test(value) || value.length % 4 === 1) {
    throw new Error("value is not canonical base64url");
  }
  const decoded = Buffer.from(value, "base64url");
  if (decoded.toString("base64url") !== value)
    throw new Error("value is not canonical base64url");
  return decoded;
}
function sha2562(input) {
  return crypto8.createHash("sha256").update(input, "utf8").digest("hex");
}
var canonicalize = canonicalizeStrictJson;
function isCanonicalizable(value) {
  return isStrictCanonicalJson(value);
}
function contextChainHash(context) {
  return sha2562(canonicalize(context));
}
function hashPair(a, b) {
  const sorted = [a, b].sort();
  return sha2562(sorted[0] + sorted[1]);
}
var MERKLE_V2_ALG = "EP-MERKLE-v2";
function leafHashV2(canonicalPayload) {
  return crypto8.createHash("sha256").update(Buffer.concat([Buffer.from([0]), Buffer.from(canonicalPayload, "utf8")])).digest("hex");
}
function hashPairV2(left, right) {
  return crypto8.createHash("sha256").update(Buffer.concat([Buffer.from([1]), Buffer.from(left, "utf8"), Buffer.from(right, "utf8")])).digest("hex");
}
function verifyMerkleAnchor(leafHash, proof, expectedRoot, opts = {}) {
  if (typeof leafHash !== "string" || !leafHash)
    return false;
  if (typeof expectedRoot !== "string" || !expectedRoot)
    return false;
  if (!Array.isArray(proof))
    return false;
  if (proof.length > 20)
    return false;
  const pair = opts.v2 === true ? hashPairV2 : hashPair;
  let current = leafHash;
  for (const step of proof) {
    if (!step || typeof step.hash !== "string")
      return false;
    if (step.position !== "left" && step.position !== "right")
      return false;
    current = step.position === "left" ? pair(step.hash, current) : pair(current, step.hash);
  }
  return current === expectedRoot;
}
var FLAG_UP2 = 1;
var FLAG_UV2 = 4;
var FLAG_BE2 = 8;
var FLAG_BS2 = 16;
function webauthnAuthenticatorMetadata(authData, opts) {
  const flags = authData[32];
  const signCount = authData.readUInt32BE(33);
  const previous = opts.previousSignCount;
  let counterStatus = "untracked";
  if (signCount === 0) {
    counterStatus = "unsupported";
  } else if (previous !== void 0) {
    counterStatus = signCount > previous ? "advanced" : "not_advanced";
  }
  return {
    sign_count: signCount,
    backup_eligible: (flags & FLAG_BE2) === FLAG_BE2,
    backup_state: (flags & FLAG_BS2) === FLAG_BS2,
    counter_status: counterStatus
  };
}
function webauthnCounterPolicyError(metadata, opts) {
  if (opts.previousSignCount !== void 0 && (!Number.isInteger(opts.previousSignCount) || opts.previousSignCount < 0 || opts.previousSignCount > 4294967295)) {
    return "previousSignCount must be a 32-bit unsigned integer";
  }
  if (opts.counterPolicy !== void 0 && opts.counterPolicy !== "observe" && opts.counterPolicy !== "enforce") {
    return 'counterPolicy must be "observe" or "enforce"';
  }
  if (metadata.backup_state && !metadata.backup_eligible) {
    return "WebAuthn backup state is set while backup eligibility is not set";
  }
  if (opts.counterPolicy === "enforce" && metadata.counter_status === "not_advanced") {
    return "WebAuthn signCount did not advance; possible clone, malfunction, or reordered assertion";
  }
  return null;
}
function verifyWebAuthnSignoff(signoff, approverPublicKeySpkiB64u, opts = {}) {
  const checks = {
    challenge_binding: false,
    client_data_type: false,
    user_present: false,
    user_verified: false,
    rp_id_hash: null,
    signature: false
  };
  let authenticator = null;
  if (opts.mode !== void 0 && opts.mode !== "relying-party" && opts.mode !== "offline-integrity") {
    return { valid: false, checks, authenticator, error: 'mode must be "relying-party" or "offline-integrity"' };
  }
  if (opts.mode === "relying-party") {
    const rpIdPinned = typeof opts.rpId === "string" && opts.rpId.length > 0;
    const originsPinned = Array.isArray(opts.allowedOrigins) && opts.allowedOrigins.length > 0 && opts.allowedOrigins.every((origin) => typeof origin === "string" && origin.length > 0);
    if (!rpIdPinned || !originsPinned) {
      checks.rp_id_hash = false;
      return { valid: false, checks, authenticator, error: "rp_pins_required" };
    }
  }
  try {
    if (!signoff?.context || !signoff?.webauthn) {
      return { valid: false, checks, authenticator, error: "Missing context or webauthn evidence" };
    }
    const { authenticator_data, client_data_json, signature } = signoff.webauthn;
    if (!authenticator_data || !client_data_json || !signature) {
      return { valid: false, checks, authenticator, error: "Missing webauthn fields" };
    }
    const clientDataBytes = decodeBase64url(client_data_json);
    const clientDataText = FATAL_UTF82.decode(clientDataBytes);
    const clientDataGate = strictJsonGate(clientDataText);
    if (!clientDataGate.ok) {
      return { valid: false, checks, authenticator, error: `Invalid clientDataJSON: ${clientDataGate.reason}` };
    }
    const clientData = JSON.parse(clientDataText);
    const expectedChallenge = crypto8.createHash("sha256").update(canonicalize(signoff.context), "utf8").digest().toString("base64url");
    checks.challenge_binding = clientData.challenge === expectedChallenge;
    checks.client_data_type = clientData.type === "webauthn.get";
    if (Array.isArray(opts.allowedOrigins)) {
      if (opts.allowedOrigins.length === 0 || !opts.allowedOrigins.includes(clientData.origin) || clientData.crossOrigin === true) {
        return { valid: false, checks, authenticator, error: "WebAuthn origin is not allowed" };
      }
    }
    const authData = decodeBase64url(authenticator_data);
    if (authData.length < 37) {
      return { valid: false, checks, authenticator, error: "authenticator_data too short" };
    }
    const flags = authData[32];
    checks.user_present = (flags & FLAG_UP2) === FLAG_UP2;
    checks.user_verified = (flags & FLAG_UV2) === FLAG_UV2;
    authenticator = webauthnAuthenticatorMetadata(authData, opts);
    const policyError = webauthnCounterPolicyError(authenticator, opts);
    if (policyError) {
      return { valid: false, checks, authenticator, error: policyError };
    }
    if (opts.rpId) {
      const expectedRpIdHash = crypto8.createHash("sha256").update(opts.rpId, "utf8").digest();
      checks.rp_id_hash = expectedRpIdHash.equals(authData.subarray(0, 32));
    }
    const signedData = Buffer.concat([
      authData,
      crypto8.createHash("sha256").update(clientDataBytes).digest()
    ]);
    const keyObject2 = crypto8.createPublicKey({
      key: decodeBase64url(approverPublicKeySpkiB64u),
      format: "der",
      type: "spki"
    });
    checks.signature = crypto8.verify("sha256", signedData, keyObject2, decodeBase64url(signature));
  } catch (e) {
    return { valid: false, checks, authenticator, error: `WebAuthn verification failed: ${e instanceof Error ? e.message : String(e)}` };
  }
  const valid = checks.challenge_binding && checks.client_data_type && checks.user_present && checks.user_verified && checks.signature && (checks.rp_id_hash === null || checks.rp_id_hash === true);
  return { valid, checks, authenticator };
}
var HASH_PREFIX4 = /^sha256:/;
function hexOf7(h) {
  return String(h || "").replace(HASH_PREFIX4, "").toLowerCase();
}
function sha256Bytes(input) {
  return crypto8.createHash("sha256").update(input, "utf8").digest();
}
function usdMinorUnits(value) {
  if (typeof value !== "string" || !/^(?:0|[1-9]\d*)(?:\.\d{1,2})?$/.test(value))
    return null;
  const [whole, fraction = ""] = value.split(".");
  return BigInt(whole) * 100n + BigInt(fraction.padEnd(2, "0"));
}
function isHighValueFinancialAction(action) {
  const actionType = typeof action?.action_type === "string" ? action.action_type.toLowerCase() : "";
  const financial = /(?:^|[._-])(wire|payment|transfer|disbursement|purchase|refund|financial)(?:$|[._-])/.test(actionType);
  const currency = action?.parameters?.currency;
  const amount = usdMinorUnits(action?.parameters?.amount);
  return financial && currency === "USD" && amount !== null && amount >= 10000000n;
}
function auditApproverKeyDirectoryTransition(previousApproverKeys, nextApproverKeys, opts = {}) {
  const errors = [];
  const transitions = [];
  const now = parseInstant2(opts.now);
  if (Number.isNaN(now)) {
    return {
      valid: false,
      errors: ["approver-key transition audit requires a parseable opts.now"],
      transitions
    };
  }
  if (!previousApproverKeys || typeof previousApproverKeys !== "object" || Array.isArray(previousApproverKeys) || !nextApproverKeys || typeof nextApproverKeys !== "object" || Array.isArray(nextApproverKeys)) {
    return {
      valid: false,
      errors: ["previousApproverKeys and nextApproverKeys must be key-directory objects"],
      transitions
    };
  }
  for (const [keyId, nextEntry] of Object.entries(nextApproverKeys)) {
    const previousEntry = previousApproverKeys[keyId];
    if (!previousEntry || typeof previousEntry !== "object" || !nextEntry || typeof nextEntry !== "object")
      continue;
    if (nextEntry.compromised_at !== void 0 && nextEntry.compromised_at !== null) {
      const compromisedAt = parseInstant2(nextEntry.compromised_at);
      if (Number.isNaN(compromisedAt)) {
        errors.push(`${keyId}: compromised_at is not a parseable instant`);
      }
    }
    if (nextEntry.valid_to === void 0 || nextEntry.valid_to === null)
      continue;
    const nextValidTo = parseInstant2(nextEntry.valid_to);
    if (Number.isNaN(nextValidTo)) {
      errors.push(`${keyId}: next valid_to is not a parseable instant`);
      continue;
    }
    const previousValidTo = previousEntry.valid_to === void 0 || previousEntry.valid_to === null ? Number.POSITIVE_INFINITY : parseInstant2(previousEntry.valid_to);
    if (Number.isNaN(previousValidTo)) {
      errors.push(`${keyId}: previous valid_to is not a parseable instant`);
      continue;
    }
    if (nextValidTo < previousValidTo) {
      const retroactive = nextValidTo < now;
      const compromiseRecorded = nextEntry.compromised_at !== void 0 && nextEntry.compromised_at !== null;
      const allowedByException = opts.allowRetroactiveExpiryWithoutCompromise === true;
      transitions.push({
        approver_key_id: keyId,
        kind: retroactive ? "retroactive_valid_to_narrowing" : "future_valid_to_narrowing",
        previous_valid_to: previousEntry.valid_to ?? null,
        next_valid_to: nextEntry.valid_to,
        compromised_at: nextEntry.compromised_at ?? null,
        exception_recorded: allowedByException
      });
      if (retroactive && !compromiseRecorded && !allowedByException) {
        errors.push(`${keyId}: retroactive valid_to narrowing requires compromised_at or an explicit allowRetroactiveExpiryWithoutCompromise exception`);
      }
    }
  }
  return { valid: errors.length === 0, errors, transitions };
}
var RFC3339_OFFSET = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})(?:\.\d+)?(?:Z|([+-])(\d{2}):(\d{2}))$/;
function parseInstant2(value) {
  if (typeof value !== "string")
    return NaN;
  const match = value.match(RFC3339_OFFSET);
  if (!match)
    return NaN;
  const [, year, month, day, hour, minute, second, , offsetHour, offsetMinute] = match;
  const calendar = /* @__PURE__ */ new Date(0);
  calendar.setUTCFullYear(Number(year), Number(month) - 1, Number(day));
  calendar.setUTCHours(Number(hour), Number(minute), Number(second), 0);
  if (calendar.toISOString().slice(0, 19) !== `${year}-${month}-${day}T${hour}:${minute}:${second}`)
    return NaN;
  if (offsetHour !== void 0 && (Number(offsetHour) > 23 || Number(offsetMinute) > 59))
    return NaN;
  const parsed = Date.parse(value);
  return Number.isFinite(parsed) ? parsed : NaN;
}
function withinWindow(t, from, to) {
  const ts = parseInstant2(t);
  if (Number.isNaN(ts))
    return false;
  if (from) {
    const f = parseInstant2(from);
    if (Number.isNaN(f) || ts < f)
      return false;
  }
  if (to) {
    const g = parseInstant2(to);
    if (Number.isNaN(g) || ts > g)
      return false;
  }
  return true;
}
function parseClassAAssertion(webauthn) {
  try {
    const clientDataBytes = decodeBase64url(webauthn.client_data_json);
    const clientDataText = FATAL_UTF82.decode(clientDataBytes);
    if (!strictJsonGate(clientDataText).ok)
      return null;
    const clientData = JSON.parse(clientDataText);
    const authData = decodeBase64url(webauthn.authenticator_data);
    if (authData.length < 37)
      return null;
    return { authData, clientData, clientDataBytes };
  } catch {
    return null;
  }
}
function verifyClassAOverDigest(webauthn, digestBytes2, publicKeySpkiB64u, opts = {}) {
  try {
    const parsed = parseClassAAssertion(webauthn);
    if (!parsed)
      return { valid: false, authenticator: null, error: "invalid WebAuthn assertion" };
    const { authData, clientData, clientDataBytes } = parsed;
    const authenticator = webauthnAuthenticatorMetadata(authData, opts);
    const policyError = webauthnCounterPolicyError(authenticator, opts);
    if (policyError)
      return { valid: false, authenticator, error: policyError };
    if (clientData.type !== "webauthn.get")
      return { valid: false, authenticator };
    if (clientData.challenge !== Buffer.from(digestBytes2).toString("base64url"))
      return { valid: false, authenticator };
    if (opts.rpId) {
      const expectedRpIdHash = crypto8.createHash("sha256").update(opts.rpId, "utf8").digest();
      if (!expectedRpIdHash.equals(authData.subarray(0, 32)))
        return { valid: false, authenticator };
    }
    if (Array.isArray(opts.allowedOrigins)) {
      if (opts.allowedOrigins.length === 0 || !opts.allowedOrigins.includes(clientData.origin) || clientData.crossOrigin === true)
        return { valid: false, authenticator };
    }
    if ((authData[32] & FLAG_UP2) !== FLAG_UP2)
      return { valid: false, authenticator };
    if ((authData[32] & FLAG_UV2) !== FLAG_UV2)
      return { valid: false, authenticator };
    const signedData = Buffer.concat([authData, crypto8.createHash("sha256").update(clientDataBytes).digest()]);
    const keyObject2 = crypto8.createPublicKey({
      key: decodeBase64url(publicKeySpkiB64u),
      format: "der",
      type: "spki"
    });
    return {
      valid: crypto8.verify("sha256", signedData, keyObject2, decodeBase64url(webauthn.signature)),
      authenticator
    };
  } catch {
    return { valid: false, authenticator: null, error: "WebAuthn verification failed" };
  }
}
function verifyEd25519OverDigest(signatureB64u, digestBytes2, publicKeySpkiB64u) {
  try {
    const keyObject2 = crypto8.createPublicKey({
      key: decodeBase64url(publicKeySpkiB64u),
      format: "der",
      type: "spki"
    });
    return crypto8.verify(null, digestBytes2, keyObject2, decodeBase64url(signatureB64u));
  } catch {
    return false;
  }
}
var STRICT_CHECK_NAMES = [
  "pinned_keys",
  "rp_id",
  "origin",
  "user_presence",
  "user_verification",
  "key_windows",
  "policy_hash",
  "no_unsigned"
];
function createStrictReport(enabled) {
  return {
    enabled,
    valid: !enabled,
    checks: enabled ? Object.fromEntries(STRICT_CHECK_NAMES.map((name) => [name, false])) : {},
    errors: []
  };
}
function parseableTimestamp(value) {
  return typeof value === "string" && !Number.isNaN(parseInstant2(value));
}
function coerceRequiredApprovals(value) {
  if (value === void 0 || value === null)
    return 1;
  if (typeof value !== "number" || !Number.isInteger(value) || value < 1)
    return null;
  return value;
}
function markStrict(report, name, ok, message) {
  report.checks[name] = Boolean(ok);
  if (!ok && message)
    report.errors.push(message);
}
function evaluateTrustReceiptStrict(report, receipt, contexts, signoffs, contextByHash, approverKeys, logPublicKey, opts) {
  const classASignoffs = [];
  let pinnedKeysOk = Boolean(logPublicKey);
  if (!logPublicKey) {
    report.errors.push("strict pinned_keys requires a trusted logPublicKey");
  }
  for (const s of signoffs) {
    if (!s?.approver_key_id) {
      pinnedKeysOk = false;
      report.errors.push("strict pinned_keys requires every signoff to name approver_key_id");
      continue;
    }
    const keyEntry = approverKeys[s.approver_key_id];
    if (!keyEntry?.public_key) {
      pinnedKeysOk = false;
      report.errors.push(`strict pinned_keys has no pinned public key for ${s.approver_key_id}`);
    }
    const keyClass = keyEntry?.key_class === "A" ? "A" : "B";
    if (keyClass === "A")
      classASignoffs.push({ signoff: s, keyEntry });
  }
  markStrict(report, "pinned_keys", pinnedKeysOk);
  let rpOk = true;
  if (classASignoffs.length > 0 && !opts.rpId) {
    rpOk = false;
    report.errors.push("strict rp_id requires opts.rpId for Class-A WebAuthn signoffs");
  }
  for (const { signoff } of classASignoffs) {
    const parsed = parseClassAAssertion(signoff.webauthn);
    if (!parsed) {
      rpOk = false;
      report.errors.push("strict rp_id could not parse Class-A WebAuthn authenticator data");
      continue;
    }
    if (opts.rpId) {
      const expectedRpHash = sha256Bytes(opts.rpId);
      if (!parsed.authData.subarray(0, 32).equals(expectedRpHash)) {
        rpOk = false;
        report.errors.push("strict rp_id WebAuthn rpIdHash does not match opts.rpId");
      }
    }
  }
  markStrict(report, "rp_id", rpOk);
  let originOk = true;
  if (classASignoffs.length > 0 && (!Array.isArray(opts.allowedOrigins) || opts.allowedOrigins.length === 0)) {
    originOk = false;
    report.errors.push("strict origin requires a non-empty opts.allowedOrigins for Class-A WebAuthn signoffs");
  }
  for (const { signoff } of classASignoffs) {
    const parsed = parseClassAAssertion(signoff.webauthn);
    if (!parsed || !opts.allowedOrigins?.includes(parsed.clientData.origin) || parsed.clientData.crossOrigin === true) {
      originOk = false;
      report.errors.push("strict origin rejects the Class-A WebAuthn origin");
    }
  }
  markStrict(report, "origin", originOk);
  let upOk = true;
  let uvOk = true;
  for (const { signoff } of classASignoffs) {
    const parsed = parseClassAAssertion(signoff.webauthn);
    const flags = parsed?.authData?.[32] || 0;
    if (!parsed || (flags & FLAG_UP2) !== FLAG_UP2) {
      upOk = false;
      report.errors.push("strict user_presence requires Class-A WebAuthn UP");
    }
    if (!parsed || (flags & FLAG_UV2) !== FLAG_UV2) {
      uvOk = false;
      report.errors.push("strict user_verification requires Class-A WebAuthn UV");
    }
  }
  markStrict(report, "user_presence", upOk);
  markStrict(report, "user_verification", uvOk);
  let keyWindowsOk = true;
  for (const s of signoffs) {
    const digestHex = hexOf7(s?.context_hash);
    const ctx = contextByHash.get(digestHex);
    const keyEntry = approverKeys[s?.approver_key_id];
    if (!ctx || !keyEntry?.public_key) {
      keyWindowsOk = false;
      report.errors.push("strict key_windows cannot bind a signoff to both context and pinned key");
      continue;
    }
    if (!parseableTimestamp(keyEntry.valid_from) || !parseableTimestamp(keyEntry.valid_to)) {
      keyWindowsOk = false;
      report.errors.push(`strict key_windows requires valid_from and valid_to for ${s.approver_key_id}`);
      continue;
    }
    if (!withinWindow(ctx.issued_at, keyEntry.valid_from, keyEntry.valid_to)) {
      keyWindowsOk = false;
      report.errors.push(`strict key_windows rejects ${s.approver_key_id} at context issued_at`);
    }
  }
  markStrict(report, "key_windows", keyWindowsOk);
  let policyHashOk = true;
  const expectedPolicyHash = opts.expectedPolicyHash ? hexOf7(opts.expectedPolicyHash) : null;
  if (!expectedPolicyHash) {
    policyHashOk = false;
    report.errors.push("strict policy_hash requires opts.expectedPolicyHash");
  }
  for (const ctx of contexts) {
    if (!ctx?.policy_hash) {
      policyHashOk = false;
      report.errors.push("strict policy_hash requires every context to carry policy_hash");
      continue;
    }
    if (expectedPolicyHash && hexOf7(ctx.policy_hash) !== expectedPolicyHash) {
      policyHashOk = false;
      report.errors.push("strict policy_hash context policy_hash does not match opts.expectedPolicyHash");
    }
  }
  markStrict(report, "policy_hash", policyHashOk);
  let noUnsignedOk = true;
  const requireField = (value, message) => {
    if (value === void 0 || value === null || value === "") {
      noUnsignedOk = false;
      report.errors.push(message);
    }
  };
  requireField(receipt.action_hash, "strict no_unsigned requires action_hash");
  requireField(receipt.consumption?.committed_at, "strict no_unsigned requires consumption.committed_at");
  requireField(receipt.log_proof?.checkpoint?.log_signature, "strict no_unsigned requires checkpoint.log_signature");
  if (!Array.isArray(receipt.log_proof?.inclusion_path)) {
    noUnsignedOk = false;
    report.errors.push("strict no_unsigned requires log_proof.inclusion_path");
  }
  for (const ctx of contexts) {
    requireField(ctx?.action_hash, "strict no_unsigned requires every context to carry action_hash");
    requireField(ctx?.policy_hash, "strict no_unsigned requires every context to carry policy_hash");
    requireField(ctx?.approver, "strict no_unsigned requires every context to name approver");
    requireField(ctx?.issued_at, "strict no_unsigned requires every context to carry issued_at");
    requireField(ctx?.expires_at, "strict no_unsigned requires every context to carry expires_at");
  }
  for (const s of signoffs) {
    requireField(s?.context_hash, "strict no_unsigned requires every signoff to carry context_hash");
    requireField(s?.approver_key_id, "strict no_unsigned requires every signoff to carry approver_key_id");
    requireField(s?.key_class, "strict no_unsigned requires every signoff to carry key_class");
    requireField(s?.signed_at, "strict no_unsigned requires every signoff to carry signed_at");
    const keyClass = approverKeys[s?.approver_key_id]?.key_class === "A" ? "A" : "B";
    if (keyClass === "A") {
      requireField(s?.webauthn?.authenticator_data, "strict no_unsigned requires Class-A authenticator_data");
      requireField(s?.webauthn?.client_data_json, "strict no_unsigned requires Class-A client_data_json");
      requireField(s?.webauthn?.signature, "strict no_unsigned requires Class-A WebAuthn signature");
    } else {
      requireField(s?.signature, "strict no_unsigned requires Ed25519 signoff signature");
    }
  }
  markStrict(report, "no_unsigned", noUnsignedOk);
  report.valid = STRICT_CHECK_NAMES.every((name) => report.checks[name] === true);
}
var ATTESTATION_TRIGGERS = /* @__PURE__ */ new Set([
  "irreversibility",
  "magnitude",
  "uncertainty",
  "novelty",
  "authority_gap",
  "policy_rule"
]);
var ATTESTATION_MEMBERS2 = /* @__PURE__ */ new Set(["escalation_trigger", "policy_basis", "statement"]);
var ATTESTATION_STATEMENT_MAX = 280;
function buildAttestationReport(contexts) {
  const withAtt = contexts.filter((c) => c && c.initiator_attestation !== void 0);
  if (withAtt.length === 0) {
    return { present: false, consistent: true, issues: [] };
  }
  const issues = [];
  let consistent = true;
  if (withAtt.length !== contexts.length) {
    consistent = false;
    issues.push("initiator_attestation is present in some contexts but not all (PIP-007 \xA71 requires it in every context)");
  }
  const canonForms = new Set(withAtt.map((c) => canonicalize(c.initiator_attestation)));
  if (canonForms.size > 1) {
    consistent = false;
    issues.push("initiator_attestation differs across contexts (PIP-007 \xA71 requires an identical canonical form in every context)");
  }
  for (const ctx of withAtt) {
    const att = ctx.initiator_attestation;
    const who = ctx.approver || "unknown approver";
    if (!att || typeof att !== "object" || Array.isArray(att)) {
      issues.push(`initiator_attestation for ${who} is not an object`);
      continue;
    }
    for (const key of Object.keys(att)) {
      if (!ATTESTATION_MEMBERS2.has(key)) {
        issues.push(`initiator_attestation for ${who} has an unknown member "${key}" (PIP-007 \xA71 allows only escalation_trigger, policy_basis, statement)`);
      }
    }
    if (!ATTESTATION_TRIGGERS.has(att.escalation_trigger)) {
      issues.push(`initiator_attestation for ${who} has an invalid escalation_trigger "${att.escalation_trigger}"`);
    }
    if (att.escalation_trigger === "policy_rule" && !att.policy_basis) {
      issues.push(`initiator_attestation for ${who} uses escalation_trigger "policy_rule" without policy_basis (PIP-007 \xA71)`);
    }
    if (typeof att.statement === "string" && att.statement.length > ATTESTATION_STATEMENT_MAX) {
      issues.push(`initiator_attestation statement for ${who} exceeds the ${ATTESTATION_STATEMENT_MAX}-character cap (PIP-007 \xA71)`);
    }
  }
  return { present: true, consistent, issues };
}
function trustReceiptCanonicalProfileError(receipt) {
  try {
    if (!isCanonicalizable(receipt))
      return "Trust Receipt body";
    const leafContent = { ...receipt };
    delete leafContent.log_proof;
    delete leafContent.approver_key_proofs;
    if (!isCanonicalizable(leafContent))
      return "Trust Receipt body";
    const checkpoint = receipt?.log_proof?.checkpoint;
    if (checkpoint && typeof checkpoint === "object") {
      const signedCheckpoint = { ...checkpoint };
      delete signedCheckpoint.log_signature;
      if (!isCanonicalizable(signedCheckpoint))
        return "Trust Receipt checkpoint";
    }
    return null;
  } catch {
    return "Trust Receipt body";
  }
}
function verifyTrustReceipt(receipt, opts = {}) {
  opts = opts && typeof opts === "object" ? opts : {};
  const checks = {
    action_hash: false,
    // step 1
    context_commitments: false,
    // step 2
    signoff_signatures: false,
    // step 3
    sod: false,
    // step 4
    inclusion: false,
    // step 5a
    checkpoint_signature: false,
    // step 5b
    windows: false
    // step 6
  };
  const errors = [];
  const optionalResults = {};
  const decisionScope = {
    authenticity_only: true,
    admission_authorized: false,
    replay_status: "not_evaluated",
    revocation_status: "unknown",
    quorum_ordering: {
      presented: false,
      evaluated: false,
      verifier: "verifyQuorum"
    },
    warning: "AUTHENTICITY IS NOT ADMISSION OR REPLAY PREVENTION"
  };
  const verificationMode = opts.verificationMode ?? "historical";
  if (verificationMode !== "historical" && verificationMode !== "current") {
    return {
      valid: false,
      checks,
      errors: ['verificationMode must be "historical" or "current"'],
      decision_scope: decisionScope
    };
  }
  const verifierNow = opts.now === void 0 || opts.now === null ? null : parseInstant2(opts.now);
  if (verifierNow !== null && Number.isNaN(verifierNow)) {
    return {
      valid: false,
      checks,
      errors: ["opts.now is not a parseable instant"],
      decision_scope: decisionScope
    };
  }
  if (verificationMode === "current" && verifierNow === null) {
    return {
      valid: false,
      checks,
      errors: ['verificationMode "current" requires opts.now from the relying-party clock'],
      decision_scope: decisionScope
    };
  }
  const strict = createStrictReport(opts.strict === true);
  let attestation = { present: false, consistent: true, issues: [] };
  const fail3 = (msg) => {
    errors.push(msg);
    return {
      valid: false,
      checks,
      errors,
      attestation,
      strict,
      decision_scope: decisionScope,
      ...optionalResults
    };
  };
  if (!receipt || typeof receipt !== "object")
    return fail3("Missing receipt");
  const profileError = trustReceiptCanonicalProfileError(receipt);
  if (profileError) {
    return fail3(`${profileError} is outside the EP canonicalization profile; only plain JSON data is accepted`);
  }
  const attestationContexts = Array.isArray(receipt.contexts) ? receipt.contexts : [];
  attestation = buildAttestationReport(attestationContexts);
  const { approverKeys = {}, logPublicKey } = opts;
  const contexts = Array.isArray(receipt.contexts) ? receipt.contexts : [];
  const signoffs = Array.isArray(receipt.signoffs) ? receipt.signoffs : [];
  decisionScope.quorum_ordering.presented = contexts.some((context) => context && typeof context === "object" && Object.hasOwn(context, "prev_context_hash"));
  if (!receipt.action || !receipt.action_hash)
    return fail3("Missing action or action_hash");
  if (contexts.length === 0 || signoffs.length === 0)
    return fail3("Missing contexts or signoffs");
  const { signoffs: _s, log_proof: _lp, approver_key_proofs: _akp, ...canonicalScope } = receipt;
  if (!isCanonicalizable(canonicalScope)) {
    return fail3("Receipt contains a value outside the EP canonicalization profile; use strings or safe integers in signed material");
  }
  if (opts.previousApproverKeys !== void 0) {
    checks.key_directory_transition = false;
    const transition = auditApproverKeyDirectoryTransition(opts.previousApproverKeys, approverKeys, {
      now: opts.now,
      allowRetroactiveExpiryWithoutCompromise: opts.allowRetroactiveExpiryWithoutCompromise === true
    });
    optionalResults.key_directory_transition = transition;
    checks.key_directory_transition = transition.valid === true;
    if (!checks.key_directory_transition) {
      errors.push(...transition.errors.map((error) => `approver-key directory: ${error}`));
    }
  }
  const actionHashHex = sha2562(canonicalize(receipt.action));
  checks.action_hash = actionHashHex === hexOf7(receipt.action_hash);
  if (!checks.action_hash)
    errors.push("action_hash does not match the canonical Action Object");
  const contextByHash = /* @__PURE__ */ new Map();
  let commitmentsOk = true;
  const policyHashes = /* @__PURE__ */ new Set();
  for (const ctx of contexts) {
    const digestHex = sha2562(canonicalize(ctx));
    contextByHash.set(digestHex, ctx);
    if (hexOf7(ctx.action_hash) !== actionHashHex) {
      commitmentsOk = false;
      errors.push(`context for ${ctx.approver || "unknown approver"} does not commit to the action hash`);
    }
    if (!ctx.policy_hash) {
      commitmentsOk = false;
      errors.push("context is missing policy_hash");
    } else {
      policyHashes.add(hexOf7(ctx.policy_hash));
    }
    if (!ctx.approver) {
      commitmentsOk = false;
      errors.push("context is missing approver");
    }
  }
  if (policyHashes.size > 1) {
    commitmentsOk = false;
    errors.push("contexts commit to different policy hashes");
  }
  checks.context_commitments = commitmentsOk;
  const validSignoffs = [];
  const validApprovals = [];
  const webauthnSignoffs = [];
  let signaturesOk = signoffs.length > 0;
  for (const s of signoffs) {
    const digestHex = hexOf7(s.context_hash);
    const ctx = contextByHash.get(digestHex);
    if (!ctx) {
      signaturesOk = false;
      errors.push("signoff references a context hash not present in this receipt");
      continue;
    }
    const keyEntry = approverKeys[s.approver_key_id];
    if (!keyEntry?.public_key) {
      signaturesOk = false;
      errors.push(`no pinned key entry for ${s.approver_key_id}`);
      continue;
    }
    if (typeof keyEntry.approver_id !== "string" || keyEntry.approver_id.length === 0) {
      signaturesOk = false;
      errors.push(`pinned key ${s.approver_key_id} is missing approver_id`);
      continue;
    }
    if (keyEntry.approver_id !== ctx.approver) {
      signaturesOk = false;
      errors.push(`pinned key ${s.approver_key_id} belongs to ${keyEntry.approver_id}, not context approver ${ctx.approver}`);
      continue;
    }
    if (keyEntry.compromised_at !== void 0 && keyEntry.compromised_at !== null) {
      const compromisedAt = parseInstant2(keyEntry.compromised_at);
      if (Number.isNaN(compromisedAt)) {
        signaturesOk = false;
        errors.push(`pinned key ${s.approver_key_id} has an unparseable compromised_at`);
        continue;
      }
      signaturesOk = false;
      errors.push(`approver key ${s.approver_key_id} is marked compromised; no claimed issued_at can clear it`);
      continue;
    }
    if (!withinWindow(ctx.issued_at, keyEntry.valid_from, keyEntry.valid_to)) {
      signaturesOk = false;
      errors.push(`approver key ${s.approver_key_id} was not valid at issued_at`);
      continue;
    }
    if (verificationMode === "current") {
      const currentFrom = parseInstant2(keyEntry.valid_from);
      const currentTo = parseInstant2(keyEntry.valid_to);
      if (Number.isNaN(currentFrom) || Number.isNaN(currentTo) || verifierNow < currentFrom || verifierNow > currentTo) {
        signaturesOk = false;
        errors.push(`approver key ${s.approver_key_id} is not current at the verifier decision time`);
        continue;
      }
    }
    if (verifierNow !== null && parseInstant2(ctx.issued_at) > verifierNow) {
      signaturesOk = false;
      errors.push(`issued_at for ${s.approver_key_id} is in the future relative to the verifier clock`);
      continue;
    }
    if (verifierNow !== null && parseInstant2(s.signed_at) > verifierNow) {
      signaturesOk = false;
      errors.push(`signed_at for ${s.approver_key_id} is in the future relative to the verifier clock`);
      continue;
    }
    const digestBytes2 = Buffer.from(digestHex, "hex");
    const keyClass = keyEntry.key_class === "A" ? "A" : "B";
    let sigOk;
    if (keyClass === "A") {
      const counterOptions = {
        ...opts,
        previousSignCount: opts.webauthnSignCounts?.[s.approver_key_id],
        counterPolicy: opts.webauthnCounterPolicy ?? "observe"
      };
      const webauthnResult = Boolean(s.webauthn) ? verifyClassAOverDigest(s.webauthn, digestBytes2, keyEntry.public_key, counterOptions) : { valid: false, authenticator: null, error: "missing WebAuthn assertion" };
      webauthnSignoffs.push({
        approver_key_id: s.approver_key_id,
        approver: ctx.approver,
        authenticator: webauthnResult.authenticator,
        counter_policy: counterOptions.counterPolicy,
        valid: webauthnResult.valid === true,
        ...webauthnResult.error ? { error: webauthnResult.error } : {}
      });
      sigOk = webauthnResult.valid === true;
    } else {
      sigOk = verifyEd25519OverDigest(s.signature, digestBytes2, keyEntry.public_key);
    }
    if (!sigOk) {
      signaturesOk = false;
      errors.push(`signoff by ${ctx.approver} does not verify`);
      continue;
    }
    const verifiedSignoff = { approver: ctx.approver, signedAt: s.signed_at, ctx };
    validSignoffs.push(verifiedSignoff);
    if (ctx.decision === void 0 || ctx.decision === "approved") {
      validApprovals.push(verifiedSignoff);
    } else if (ctx.decision === "denied") {
      errors.push(`signed denial by ${ctx.approver} does not authorize the action`);
    } else {
      errors.push(`signed decision by ${ctx.approver} is not a recognized approval outcome`);
    }
  }
  checks.signoff_signatures = signaturesOk;
  if (webauthnSignoffs.length > 0)
    optionalResults.webauthn_signoffs = webauthnSignoffs;
  const initiator = receipt.action.initiator;
  const approvers = validApprovals.map((a) => a.approver);
  const coerced = contexts.map((c) => coerceRequiredApprovals(c.required_approvals));
  let sodOk = true;
  if (coerced.some((n) => n === null)) {
    sodOk = false;
    errors.push("required_approvals must be an integer >= 1 (fail-closed on non-integer)");
  }
  const requiredApprovals = Math.max(1, ...coerced.map((n) => n ?? 1));
  if (initiator && approvers.includes(initiator)) {
    sodOk = false;
    errors.push("initiator appears in an approver slot (SoD violation)");
  }
  if (new Set(approvers).size !== approvers.length) {
    sodOk = false;
    errors.push("approvers are not pairwise distinct");
  }
  if (validApprovals.length < requiredApprovals) {
    sodOk = false;
    errors.push(`approval count ${validApprovals.length} < required_approvals ${requiredApprovals}`);
  }
  checks.sod = sodOk;
  const lp = receipt.log_proof;
  if (lp?.checkpoint && Array.isArray(lp.inclusion_path)) {
    const leafContent = { ...receipt };
    delete leafContent.log_proof;
    delete leafContent.approver_key_proofs;
    const canonicalLeaf = canonicalize(leafContent);
    const merkleAlg = lp.alg || lp.checkpoint?.merkle_alg || null;
    let emptyPathRefusal = null;
    if (lp.inclusion_path.length === 0) {
      if (lp.checkpoint.tree_size !== 1) {
        emptyPathRefusal = "empty inclusion_path requires checkpoint tree_size 1 (single-leaf tree)";
      } else if (lp.leaf_index !== void 0 && lp.leaf_index !== 0) {
        emptyPathRefusal = "empty inclusion_path requires leaf_index 0 in a single-leaf tree";
      }
    }
    if (emptyPathRefusal) {
      checks.inclusion = false;
      errors.push(emptyPathRefusal);
    } else if (merkleAlg === MERKLE_V2_ALG) {
      const leafHash = leafHashV2(canonicalLeaf);
      const presentedLeaf = lp.leaf_hash ? hexOf7(lp.leaf_hash) : leafHash;
      checks.inclusion = presentedLeaf === leafHash && verifyMerkleAnchor(leafHash, lp.inclusion_path, hexOf7(lp.checkpoint.root_hash), { v2: true });
      if (presentedLeaf !== leafHash)
        errors.push("Trust Receipt log_proof leaf_hash does not bind this receipt");
      else if (!checks.inclusion)
        errors.push("EP-MERKLE-v2 inclusion proof does not reconstruct the checkpoint root");
    } else if (opts.allowLegacyMerkle === true || opts.allowLegacyTrustReceiptMerkle === true) {
      const leafHash = sha2562(canonicalLeaf);
      checks.inclusion = verifyMerkleAnchor(leafHash, lp.inclusion_path, hexOf7(lp.checkpoint.root_hash));
      if (!checks.inclusion)
        errors.push("legacy EP-MERKLE-v1 inclusion proof does not reconstruct the checkpoint root");
    } else {
      checks.inclusion = false;
      errors.push("log_proof is not EP-MERKLE-v2 (legacy v1 refused unless allowLegacyMerkle is set)");
    }
    if (logPublicKey && lp.checkpoint.log_signature) {
      const signedCheckpoint = { ...lp.checkpoint };
      delete signedCheckpoint.log_signature;
      checks.checkpoint_signature = verifyEd25519OverDigest(String(lp.checkpoint.log_signature).replace(/^b64u:/, ""), sha256Bytes(canonicalize(signedCheckpoint)), logPublicKey);
      if (!checks.checkpoint_signature)
        errors.push("checkpoint signature does not verify against the log key");
    } else {
      errors.push("missing log public key or checkpoint signature");
    }
  } else {
    errors.push("missing log_proof (inclusion path + checkpoint)");
  }
  if (opts.priorCheckpoint !== void 0) {
    checks.consistency = false;
    const prior = opts.priorCheckpoint;
    const priorSize = prior?.tree_size;
    const priorRoot = hexOf7(prior?.root_hash);
    const headSize = lp?.checkpoint?.tree_size;
    const headRoot = hexOf7(lp?.checkpoint?.root_hash);
    if (!prior || typeof prior !== "object" || !Number.isInteger(priorSize) || priorSize < 1 || !priorRoot) {
      errors.push("priorCheckpoint requires integer tree_size >= 1 and root_hash");
    } else if (!Number.isInteger(headSize) || !headRoot) {
      errors.push("priorCheckpoint is pinned but the receipt checkpoint is missing tree_size or root_hash");
    } else if (!Array.isArray(prior.consistency_proof)) {
      errors.push("priorCheckpoint is pinned but consistency_proof is missing");
    } else if (verifyCheckpointConsistency(priorRoot, priorSize, headRoot, headSize, prior.consistency_proof)) {
      checks.consistency = true;
    } else {
      errors.push("consistency_proof does not prove an append-only extension from the pinned prior checkpoint");
    }
  }
  if (opts.witnessQuorum !== void 0) {
    checks.witness_quorum = false;
    const wq = opts.witnessQuorum;
    const checkpoint = lp?.checkpoint;
    if (!checkpoint || typeof checkpoint !== "object") {
      optionalResults.witness_quorum = {
        ok: false,
        met: 0,
        required: 0,
        witness_ids: [],
        reasons: ["receipt has no checkpoint for witnesses to cosign"]
      };
      errors.push("witnessQuorum is set but the receipt checkpoint is missing");
    } else if (!wq || typeof wq !== "object") {
      optionalResults.witness_quorum = {
        ok: false,
        met: 0,
        required: 0,
        witness_ids: [],
        reasons: ["witnessQuorum must be an object { cosignatures, pinnedWitnessKeys, k }"]
      };
      errors.push("witnessQuorum must be an object with cosignatures, pinnedWitnessKeys, and k");
    } else {
      const res = requireWitnessQuorum(checkpoint, wq.cosignatures, wq.pinnedWitnessKeys, wq.k);
      optionalResults.witness_quorum = res;
      checks.witness_quorum = res.ok === true;
      if (!checks.witness_quorum) {
        errors.push(`witness quorum not met: ${res.met}/${res.required} distinct pinned witnesses cosigned this head`);
      }
    }
  }
  const timestampRequiredByPolicy = opts.requireTimestampProof === true;
  const timestampRequiredByFinancialProfile = verificationMode === "current" && isHighValueFinancialAction(receipt.action);
  const timestampRequired = timestampRequiredByPolicy || timestampRequiredByFinancialProfile;
  if (timestampRequired && opts.timestampProof === void 0) {
    const reason = timestampRequiredByFinancialProfile ? "high-value financial action requires timestampProof in current-evidence mode" : "relying-party policy requires timestampProof";
    checks.timestamp_proof = false;
    optionalResults.timestamp_proof = {
      verified: false,
      tsa_key_id: null,
      gen_time: null,
      reason
    };
    errors.push(reason);
  } else if (opts.timestampProof !== void 0) {
    checks.timestamp_proof = false;
    const tp = opts.timestampProof;
    if (!tp || typeof tp !== "object") {
      optionalResults.timestamp_proof = {
        verified: false,
        tsa_key_id: null,
        gen_time: null,
        reason: "timestampProof must be an object { token, expectedDigest, pinnedTsaKeys }"
      };
      errors.push("timestampProof must be an object with token, expectedDigest, and pinnedTsaKeys");
    } else {
      const res = verifyTimestampProof(tp.token, tp.expectedDigest, tp.pinnedTsaKeys);
      optionalResults.timestamp_proof = res;
      checks.timestamp_proof = res.verified === true;
      if (!checks.timestamp_proof) {
        errors.push(`timestamp proof did not verify: ${res.reason}`);
      }
    }
  }
  if (opts.revocationStatements !== void 0) {
    checks.revocation = false;
    const statements = opts.revocationStatements;
    const target = {
      target_type: "receipt",
      target_id: receipt.receipt_id,
      action_hash: receipt.action_hash
    };
    const reports = [];
    let exactPresented = false;
    let revoked = false;
    let indeterminate = false;
    if (!Array.isArray(statements)) {
      indeterminate = true;
      errors.push("revocationStatements must be an array");
    } else {
      for (const statement2 of statements) {
        const exact = statement2?.target_type === target.target_type && statement2?.target_id === target.target_id && hexOf7(statement2?.action_hash) === hexOf7(target.action_hash);
        if (!exact)
          continue;
        exactPresented = true;
        const report = verifyRevocation(target, statement2, {
          revokerKeys: opts.revokerKeys,
          now: opts.now
        });
        reports.push(report);
        if (report.valid)
          revoked = true;
        else
          indeterminate = true;
      }
    }
    const status = revoked ? "revoked" : indeterminate ? "indeterminate" : exactPresented ? "indeterminate" : "not_found_in_presented_set";
    optionalResults.revocation = {
      status,
      exact_target_statements: reports.length,
      reports,
      warning: status === "not_found_in_presented_set" ? "absence from the presented set is not proof of current non-revocation" : null
    };
    decisionScope.revocation_status = status;
    checks.revocation = status === "not_found_in_presented_set";
    if (status === "revoked")
      errors.push("receipt is revoked by an authentic exact-target statement");
    else if (status === "indeterminate")
      errors.push("exact-target revocation status is indeterminate");
  }
  if (opts.currency !== void 0) {
    checks.currency = false;
    const c = opts.currency && typeof opts.currency === "object" ? opts.currency : {};
    const res = evaluateCurrency({
      receipt,
      authentic_as_of_commit: c.authentic_as_of_commit === true,
      now: c.now,
      maxStalenessSeconds: c.maxStalenessSeconds,
      freshHead: c.freshHead,
      freshHeadRequired: c.freshHeadRequired
    });
    optionalResults.currency = res;
    checks.currency = res.currency_at_T.status === "fresh";
    if (!checks.currency) {
      errors.push(`currency gate not satisfied: status "${res.currency_at_T.status}" (${res.currency_at_T.reason}); only "fresh" passes`);
    }
  }
  if (opts.consumptionProof !== void 0) {
    checks.consumption = false;
    const res = verifyConsumptionProof(opts.consumptionProof);
    optionalResults.consumption = res;
    checks.consumption = res.valid === true;
    if (!checks.consumption) {
      errors.push(`consumption proof did not verify: ${res.reason}`);
    } else {
      decisionScope.replay_status = "presented_consumption_proof_verified_not_atomic_admission";
    }
  }
  if (opts.requireInitiatorAttestation === true) {
    checks.initiator_attestation = false;
    const att = receipt.action && typeof receipt.action === "object" ? receipt.action.initiator_software : void 0;
    if (att === void 0) {
      optionalResults.initiator_attestation = {
        ok: false,
        normalized: null,
        errors: ["requireInitiatorAttestation is set but action.initiator_software is absent"],
        statement_report: null
      };
      errors.push("requireInitiatorAttestation is set but action.initiator_software is absent");
    } else {
      const res = validateInitiatorAttestation(att);
      optionalResults.initiator_attestation = res;
      checks.initiator_attestation = res.ok === true;
      if (!checks.initiator_attestation) {
        errors.push(`initiator_software attestation is invalid: ${res.errors.join("; ")}`);
      }
    }
  }
  let windowsOk = validSignoffs.length > 0;
  for (const a of validSignoffs) {
    if (!withinWindow(a.signedAt, a.ctx.issued_at, a.ctx.expires_at)) {
      windowsOk = false;
      errors.push(`signed_at for ${a.approver} falls outside [issued_at, expires_at]`);
    }
  }
  const committedAt = receipt.consumption?.committed_at;
  if (!committedAt) {
    windowsOk = false;
    errors.push("missing consumption.committed_at");
  } else {
    if (verifierNow !== null && parseInstant2(committedAt) > verifierNow) {
      windowsOk = false;
      errors.push("committed_at is in the future relative to the verifier clock");
    }
    for (const ctx of contexts) {
      if (!withinWindow(committedAt, ctx.issued_at, ctx.expires_at)) {
        windowsOk = false;
        errors.push("committed_at falls outside a context validity window");
        break;
      }
    }
  }
  checks.windows = windowsOk;
  if (strict.enabled) {
    evaluateTrustReceiptStrict(strict, receipt, contexts, signoffs, contextByHash, approverKeys, logPublicKey, opts);
    if (!strict.valid) {
      errors.push(...strict.errors);
    }
  }
  const valid = Object.values(checks).every(Boolean) && strict.valid;
  return {
    valid,
    checks,
    errors,
    attestation,
    strict,
    decision_scope: decisionScope,
    ...optionalResults
  };
}

// ../../../../../private/tmp/emilia-ccs-aeb.TjuCWa/extracted/emilia-ccs-l1-aeb-e94314ab/packages/verify/dist/platform-attestation.js
import crypto9 from "node:crypto";
var EP_PLATFORM_ATTESTATION_VERSION = "EP-PLATFORM-ATTESTATION-v1";
var EP_PLATFORM_ATTESTATION_PROFILE = "tag:emiliaprotocol.ai,2026:platform-attestation/eat-jwt/v1";
var EP_PLATFORM_ATTESTATION_COMPONENT = "ep-platform-attestation";
var MAX_TOKEN_BYTES = 32 * 1024;
var MAX_HEADER_BYTES = 2 * 1024;
var MAX_PAYLOAD_BYTES = 24 * 1024;
var MAX_KEY_BYTES = 1024;
var MAX_REFERENCE_MEASUREMENTS = 64;
var MAX_ATTESTATION_AGE_SECONDS = 86400;
var BASE64URL2 = /^[A-Za-z0-9_-]+$/;
var SHA2563 = /^sha256:[0-9a-f]{64}$/;
var RFC3339_UTC3 = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})(?:\.(\d{1,9}))?Z$/;
function plainRecord(value) {
  if (value === null || typeof value !== "object" || Array.isArray(value))
    return false;
  try {
    const prototype = Object.getPrototypeOf(value);
    return prototype === Object.prototype || prototype === null;
  } catch {
    return false;
  }
}
function exactKeys3(value, expected) {
  try {
    const actual = Object.keys(value).sort();
    const wanted = [...expected].sort();
    return actual.length === wanted.length && actual.every((key, index) => key === wanted[index]);
  } catch {
    return false;
  }
}
function fail2(reason) {
  return { valid: false, action_digest: null, detail: { reason } };
}
function decodeBase64url2(segment, maxBytes) {
  if (typeof segment !== "string" || !BASE64URL2.test(segment))
    return null;
  try {
    const bytes = Buffer.from(segment, "base64url");
    if (bytes.length === 0 || bytes.length > maxBytes || bytes.toString("base64url") !== segment)
      return null;
    return bytes;
  } catch {
    return null;
  }
}
function decodeStrictJson(segment, maxBytes) {
  const bytes = decodeBase64url2(segment, maxBytes);
  if (!bytes)
    return { value: null, syntaxValid: false };
  try {
    const text = new TextDecoder("utf-8", { fatal: true }).decode(bytes);
    if (!strictJsonGate(text).ok)
      return { value: null, syntaxValid: false };
    const value = JSON.parse(text);
    return { value: plainRecord(value) ? value : null, syntaxValid: true };
  } catch {
    return { value: null, syntaxValid: false };
  }
}
function strictUtcInstantMs(value) {
  if (typeof value !== "string")
    return NaN;
  const match = value.match(RFC3339_UTC3);
  if (!match)
    return NaN;
  const [, year, month, day, hour, minute, second] = match;
  const base = `${year}-${month}-${day}T${hour}:${minute}:${second}`;
  const parsed = Date.parse(value);
  if (!Number.isFinite(parsed))
    return NaN;
  const normalized = new Date(parsed).toISOString().slice(0, 19);
  return normalized === base ? parsed : NaN;
}
function validExpectedNonce(value) {
  return typeof value === "string" && Buffer.byteLength(value, "utf8") >= 8 && Buffer.byteLength(value, "utf8") <= 88;
}
function referenceSet(value) {
  if (!Array.isArray(value) || value.length === 0 || value.length > MAX_REFERENCE_MEASUREMENTS)
    return null;
  const result = /* @__PURE__ */ new Set();
  for (const measurement of value) {
    if (typeof measurement !== "string" || !SHA2563.test(measurement) || result.has(measurement))
      return null;
    result.add(measurement);
  }
  return result;
}
function loadPinnedEd25519Key(value) {
  const der = decodeBase64url2(value, MAX_KEY_BYTES);
  if (!der)
    return null;
  try {
    const key = crypto9.createPublicKey({ key: der, format: "der", type: "spki" });
    return key.asymmetricKeyType === "ed25519" ? key : null;
  } catch {
    return null;
  }
}
function parseBuildMeasurement(value) {
  if (!Array.isArray(value) || value.length !== 1)
    return null;
  const group = value[0];
  if (!Array.isArray(group) || group.length !== 2 || group[0] !== "ep-build")
    return null;
  const results = group[1];
  if (!Array.isArray(results) || results.length !== 1)
    return null;
  const result = results[0];
  if (!Array.isArray(result) || result.length !== 2 || typeof result[0] !== "string" || !SHA2563.test(result[0]) || result[1] !== "success")
    return null;
  return result[0];
}
function verifyPlatformAttestationInternal(evidence, options) {
  if (!plainRecord(evidence) || !exactKeys3(evidence, ["@version", "token"]) || evidence["@version"] !== EP_PLATFORM_ATTESTATION_VERSION || typeof evidence.token !== "string" || Buffer.byteLength(evidence.token, "utf8") > MAX_TOKEN_BYTES) {
    return fail2("evidence_shape_invalid");
  }
  if (!plainRecord(options))
    return fail2("relying_party_policy_invalid");
  const verificationTimeMs = strictUtcInstantMs(options.verificationTime);
  const references = referenceSet(options.referenceMeasurements);
  if (!plainRecord(options.trustedAttesters) || options.expectedProfile !== EP_PLATFORM_ATTESTATION_PROFILE || typeof options.expectedAudience !== "string" || options.expectedAudience.length === 0 || options.expectedAudience.length > 2048 || !validExpectedNonce(options.expectedNonce) || typeof options.expectedActionDigest !== "string" || !SHA2563.test(options.expectedActionDigest) || !references || !Number.isFinite(verificationTimeMs) || !Number.isSafeInteger(options.maxAgeSeconds) || options.maxAgeSeconds < 0 || options.maxAgeSeconds > MAX_ATTESTATION_AGE_SECONDS) {
    return fail2("relying_party_policy_invalid");
  }
  const segments = evidence.token.split(".");
  if (segments.length !== 3 || segments.some((segment) => !segment))
    return fail2("token_format_invalid");
  const [headerSegment, payloadSegment, signatureSegment] = segments;
  const decodedHeader = decodeStrictJson(headerSegment, MAX_HEADER_BYTES);
  if (!decodedHeader.syntaxValid)
    return fail2("protected_header_json_invalid");
  const header = decodedHeader.value;
  if (!header || !exactKeys3(header, ["alg", "kid", "typ"]) || header.alg !== "EdDSA" || header.typ !== "eat+jwt" || typeof header.kid !== "string" || header.kid.length === 0 || header.kid.length > 256) {
    return fail2("protected_header_invalid");
  }
  const decodedPayload = decodeStrictJson(payloadSegment, MAX_PAYLOAD_BYTES);
  if (!decodedPayload.syntaxValid)
    return fail2("payload_json_invalid");
  const payload = decodedPayload.value;
  if (!payload || !exactKeys3(payload, [
    "iss",
    "aud",
    "iat",
    "exp",
    "eat_nonce",
    "eat_profile",
    "measres",
    "ep_action_digest"
  ]))
    return fail2("payload_shape_invalid");
  if (typeof payload.iss !== "string" || payload.iss.length === 0 || payload.iss.length > 2048 || typeof payload.aud !== "string" || payload.aud.length === 0 || payload.aud.length > 2048 || !validExpectedNonce(payload.eat_nonce) || typeof payload.eat_profile !== "string" || payload.eat_profile.length === 0 || payload.eat_profile.length > 2048 || typeof payload.ep_action_digest !== "string" || !SHA2563.test(payload.ep_action_digest)) {
    return fail2("payload_claims_invalid");
  }
  if (!Number.isSafeInteger(payload.iat) || !Number.isSafeInteger(payload.exp) || payload.exp <= payload.iat) {
    return fail2("time_claims_invalid");
  }
  const trustedIssuer = Object.prototype.hasOwnProperty.call(options.trustedAttesters, payload.iss) ? options.trustedAttesters[payload.iss] : null;
  if (!plainRecord(trustedIssuer) || !Object.prototype.hasOwnProperty.call(trustedIssuer, header.kid)) {
    return fail2("attester_untrusted");
  }
  const pinnedKey = loadPinnedEd25519Key(trustedIssuer[header.kid]);
  if (!pinnedKey)
    return fail2("attester_key_invalid");
  const signature = decodeBase64url2(signatureSegment, 64);
  if (!signature || signature.length !== 64)
    return fail2("signature_invalid");
  let signatureValid = false;
  try {
    signatureValid = crypto9.verify(null, Buffer.from(`${headerSegment}.${payloadSegment}`, "ascii"), pinnedKey, signature);
  } catch {
    signatureValid = false;
  }
  if (!signatureValid)
    return fail2("signature_invalid");
  if (payload.eat_profile !== options.expectedProfile)
    return fail2("profile_mismatch");
  if (payload.aud !== options.expectedAudience)
    return fail2("audience_mismatch");
  if (payload.eat_nonce !== options.expectedNonce)
    return fail2("nonce_mismatch");
  if (payload.ep_action_digest !== options.expectedActionDigest)
    return fail2("action_digest_mismatch");
  const buildMeasurement = parseBuildMeasurement(payload.measres);
  if (!buildMeasurement)
    return fail2("measurement_result_invalid");
  if (!references.has(buildMeasurement))
    return fail2("measurement_untrusted");
  if (payload.iat * 1e3 > verificationTimeMs)
    return fail2("token_from_future");
  if (verificationTimeMs >= payload.exp * 1e3)
    return fail2("token_expired");
  if (verificationTimeMs - payload.iat * 1e3 > options.maxAgeSeconds * 1e3)
    return fail2("token_too_old");
  return {
    valid: true,
    action_digest: payload.ep_action_digest,
    detail: {
      reason: null,
      profile: payload.eat_profile,
      issuer: payload.iss,
      key_id: header.kid,
      build_measurement: buildMeasurement,
      profile_alignment: "RFC9334-attestation-result/RFC9711-EAT-JWT",
      // This profile consumes a signed appraisal result. It deliberately does
      // not claim to independently verify hardware or generic EAT evidence.
      hardware_verified: false
    }
  };
}
function verifyPlatformAttestation(evidence, options) {
  try {
    return verifyPlatformAttestationInternal(evidence, options);
  } catch {
    return fail2("unexpected_verification_error");
  }
}

// ../../../../../private/tmp/emilia-ccs-aeb.TjuCWa/extracted/emilia-ccs-l1-aeb-e94314ab/packages/verify/dist/evidence-chain.js
var MAX_REQUIREMENT_LENGTH = 4096;
var MAX_REQUIREMENT_TOKENS = 256;
var MAX_REQUIREMENT_DEPTH = 32;
var MAX_QUORUM_MEMBERS = 32;
var MAX_JSON_DEPTH3 = 64;
var MAX_JSON_NODES2 = 5e4;
var MAX_JSON_STRING_BYTES2 = 1024 * 1024;
var IDENT_CHAR = /[A-Za-z0-9_.:-]/;
var IDENT = /^[A-Za-z0-9_.:-]+$/;
var HEX_256 = /^[0-9a-f]{64}$/;
var RFC3339_INSTANT3 = /^(\d{4})-(\d{2})-(\d{2})T(\d{2}):(\d{2}):(\d{2})(?:\.\d{1,9})?(?:Z|([+-])(\d{2}):(\d{2}))$/;
var isRecord2 = (v) => v !== null && typeof v === "object" && !Array.isArray(v);
var own2 = (obj, key) => isRecord2(obj) && Object.prototype.hasOwnProperty.call(obj, key);
var sha256hex = (s) => crypto10.createHash("sha256").update(s, "utf8").digest("hex");
function actionDigest(action) {
  return sha256hex(canonicalize(action));
}
function normDigest(d) {
  if (typeof d !== "string")
    return null;
  const bare = d.replace(/^sha256:/i, "").toLowerCase();
  return HEX_256.test(bare) ? bare : null;
}
function strictInstantMs(value) {
  if (typeof value !== "string")
    return NaN;
  const match = value.match(RFC3339_INSTANT3);
  if (!match)
    return NaN;
  const [, y, mo, d, h, mi, s, , oh, om] = match;
  const calendar = /* @__PURE__ */ new Date(0);
  calendar.setUTCFullYear(Number(y), Number(mo) - 1, Number(d));
  calendar.setUTCHours(Number(h), Number(mi), Number(s), 0);
  if (calendar.toISOString().slice(0, 19) !== `${y}-${mo}-${d}T${h}:${mi}:${s}`)
    return NaN;
  if (oh !== void 0 && (Number(oh) > 23 || Number(om) > 59))
    return NaN;
  return Date.parse(value);
}
function freshAt(context, verificationTime, maxAgeSec) {
  const at = strictInstantMs(verificationTime);
  const issued = strictInstantMs(context?.issued_at);
  const expires = strictInstantMs(context?.expires_at);
  return Number.isFinite(at) && Number.isFinite(issued) && Number.isFinite(expires) && Number.isInteger(maxAgeSec) && maxAgeSec >= 0 && issued <= at && at <= expires && at - issued <= maxAgeSec * 1e3;
}
function freshRegistrySnapshot(profile2, verificationTime) {
  const at = strictInstantMs(verificationTime);
  const checked = strictInstantMs(profile2?.registry_checked_at);
  return Number.isFinite(at) && Number.isFinite(checked) && Number.isInteger(profile2?.max_registry_age_sec) && profile2.max_registry_age_sec >= 0 && checked <= at && at - checked <= profile2.max_registry_age_sec * 1e3;
}
function activeDirectoryEntry(entry, verificationTime) {
  if (!isRecord2(entry) || entry.status !== "active")
    return false;
  const at = strictInstantMs(verificationTime);
  const from = strictInstantMs(entry.valid_from);
  const to = strictInstantMs(entry.valid_to);
  if (!Number.isFinite(at) || !Number.isFinite(from) || !Number.isFinite(to) || at < from || at > to)
    return false;
  if (entry.revoked_at === void 0 || entry.revoked_at === null)
    return true;
  const revoked = strictInstantMs(entry.revoked_at);
  return Number.isFinite(revoked) && at < revoked;
}
function allowedOriginSet(profile2) {
  if (!Array.isArray(profile2?.allowed_origins) || profile2.allowed_origins.length === 0 || profile2.allowed_origins.length > 16)
    return null;
  const origins = /* @__PURE__ */ new Set();
  for (const origin of profile2.allowed_origins) {
    if (typeof origin !== "string" || !origin || origin.length > 2048)
      return null;
    origins.add(origin);
  }
  return origins;
}
function webauthnOrigin(webauthn) {
  try {
    const encoded = webauthn?.client_data_json;
    if (typeof encoded !== "string" || !/^[A-Za-z0-9_-]+$/.test(encoded))
      return null;
    const bytes = Buffer.from(encoded, "base64url");
    if (bytes.toString("base64url") !== encoded)
      return null;
    const text = new TextDecoder("utf-8", { fatal: true }).decode(bytes);
    if (!strictJsonGate(text).ok)
      return null;
    const clientData = JSON.parse(text);
    return typeof clientData?.origin === "string" ? clientData.origin : null;
  } catch {
    return null;
  }
}
function validUnicodeString2(value) {
  for (let i = 0; i < value.length; i++) {
    const unit = value.charCodeAt(i);
    if (unit >= 55296 && unit <= 56319) {
      const next = value.charCodeAt(++i);
      if (!(next >= 56320 && next <= 57343))
        return false;
    } else if (unit >= 56320 && unit <= 57343)
      return false;
  }
  return true;
}
function boundedJson(value) {
  const stack = [{ value, depth: 0 }];
  const seen = /* @__PURE__ */ new WeakSet();
  let nodes = 0;
  let stringBytes = 0;
  while (stack.length) {
    const current = stack.pop();
    nodes++;
    if (nodes > MAX_JSON_NODES2 || current.depth > MAX_JSON_DEPTH3)
      return false;
    const v = current.value;
    if (v === null || typeof v === "boolean")
      continue;
    if (typeof v === "string") {
      if (!validUnicodeString2(v))
        return false;
      stringBytes += Buffer.byteLength(v, "utf8");
      if (stringBytes > MAX_JSON_STRING_BYTES2)
        return false;
      continue;
    }
    if (typeof v === "number") {
      if (!Number.isSafeInteger(v))
        return false;
      continue;
    }
    if (!isRecord2(v) && !Array.isArray(v))
      return false;
    if (seen.has(v))
      return false;
    seen.add(v);
    if (Array.isArray(v)) {
      for (const child of v)
        stack.push({ value: child, depth: current.depth + 1 });
    } else {
      for (const [key, child] of Object.entries(v)) {
        if (!validUnicodeString2(key))
          return false;
        stringBytes += Buffer.byteLength(key, "utf8");
        if (stringBytes > MAX_JSON_STRING_BYTES2)
          return false;
        stack.push({ value: child, depth: current.depth + 1 });
      }
    }
  }
  return true;
}
function builtinVerifiers() {
  return {
    // A signed platform attestation result consumed under a relying-party-owned
    // profile. Trust keys, nonce, profile, audience, build references, and
    // freshness all come from opts; the presenter supplies only the token.
    [EP_PLATFORM_ATTESTATION_COMPONENT]: (evidence, ctx) => {
      const profile2 = ctx?.policiesByType?.[EP_PLATFORM_ATTESTATION_COMPONENT];
      const trustedAttesters = ctx?.keysByType?.[EP_PLATFORM_ATTESTATION_COMPONENT];
      if (!isRecord2(profile2)) {
        return { valid: false, action_digest: null, detail: { reason: "missing relying-party platform-attestation profile" } };
      }
      let expectedActionDigest;
      try {
        expectedActionDigest = `sha256:${actionDigest(ctx?.action)}`;
      } catch {
        return { valid: false, action_digest: null, detail: { reason: "platform-attestation action is not canonicalizable" } };
      }
      return verifyPlatformAttestation(evidence, {
        trustedAttesters,
        expectedProfile: profile2.expected_profile,
        expectedAudience: profile2.expected_audience,
        expectedNonce: profile2.expected_nonce,
        expectedActionDigest,
        referenceMeasurements: profile2.reference_measurements,
        verificationTime: ctx?.verificationTime,
        maxAgeSeconds: profile2.max_age_sec
      });
    },
    // A distinct-human quorum (EP-QUORUM-v1) — the two-person-rule leg.
    "ep-quorum": (evidence, ctx) => {
      const profile2 = ctx?.policiesByType?.["ep-quorum"];
      const allowedOrigins = allowedOriginSet(profile2);
      const members = Array.isArray(evidence?.members) ? evidence.members : null;
      if (!isRecord2(profile2) || !isRecord2(profile2.policy) || typeof profile2.rp_id !== "string" || !profile2.rp_id || typeof profile2.context_policy !== "string" || !profile2.context_policy || !allowedOrigins || !Number.isInteger(profile2.max_age_sec) || profile2.max_age_sec < 0 || !freshRegistrySnapshot(profile2, ctx?.verificationTime) || !isRecord2(profile2.approvers) || !members || members.length === 0 || members.length > MAX_QUORUM_MEMBERS) {
        return { valid: false, action_digest: null, detail: { reason: "missing or malformed relying-party quorum profile" } };
      }
      const mode = profile2.policy.mode;
      if (mode !== "threshold" && mode !== "ordered") {
        return { valid: false, action_digest: null, detail: { reason: "quorum policy mode must be threshold or ordered" } };
      }
      const required = profile2.policy.required;
      const approverCount = Array.isArray(profile2.policy.approvers) ? profile2.policy.approvers.length : 0;
      if (!Number.isInteger(required) || required < 2 || required > approverCount || profile2.policy.distinct_humans !== true) {
        return { valid: false, action_digest: null, detail: { reason: "ep-quorum requires at least two distinct humans" } };
      }
      if (mode === "ordered" && profile2.policy.ordered_chain !== true) {
        return { valid: false, action_digest: null, detail: { reason: "ordered ep-quorum requires a signed predecessor chain" } };
      }
      try {
        if (!isRecord2(evidence?.policy) || canonicalize(evidence.policy) !== canonicalize(profile2.policy)) {
          return { valid: false, action_digest: null, detail: { reason: "presented quorum policy does not equal the relying-party-pinned policy" } };
        }
      } catch {
        return { valid: false, action_digest: null, detail: { reason: "quorum policy is not canonicalizable" } };
      }
      for (const m of members) {
        if (!isRecord2(m) || !isRecord2(m.signoff) || !isRecord2(m.signoff.context)) {
          return { valid: false, action_digest: null, detail: { reason: "malformed quorum member" } };
        }
        const k = m?.approver_public_key;
        const entry = typeof k === "string" && own2(profile2.approvers, k) ? profile2.approvers[k] : null;
        if (!activeDirectoryEntry(entry, ctx?.verificationTime) || entry.public_key !== k || typeof entry.approver_id !== "string" || entry.approver_id !== m.signoff.context.approver || !Array.isArray(entry.roles) || !entry.roles.includes(m.role) || m.signoff.context.policy !== profile2.context_policy || !webauthnOrigin(m.signoff.webauthn) || !allowedOrigins.has(webauthnOrigin(m.signoff.webauthn)) || !freshAt(m.signoff.context, ctx?.verificationTime, profile2.max_age_sec)) {
          return { valid: false, action_digest: null, detail: { reason: "quorum member is not bound to the pinned approver directory and policy" } };
        }
      }
      const r = (
        /** @type {{valid?:boolean, checks?:any}} */
        verifyQuorum(evidence, {
          rpId: profile2.rp_id,
          allowedOrigins: [...allowedOrigins]
        }) || {}
      );
      return { valid: !!r.valid, action_digest: r.valid ? evidence?.action_hash ?? null : null, detail: r.checks };
    },
    // A Section 6.2 human-authorization Trust Receipt. A bare operator-signed
    // EP-RECEIPT-v1 envelope is not human evidence. Acceptance requires a fresh
    // Class-A WebAuthn ceremony plus relying-party-pinned identity, audience,
    // policy, and log trust.
    "ep-receipt": (evidence, ctx) => {
      const profile2 = ctx?.policiesByType?.["ep-receipt"];
      const allowedOrigins = allowedOriginSet(profile2);
      const contexts = Array.isArray(evidence?.contexts) ? evidence.contexts : null;
      const signoffs = Array.isArray(evidence?.signoffs) ? evidence.signoffs : null;
      if (!isRecord2(profile2) || !isRecord2(profile2.approver_keys) || typeof profile2.log_public_key !== "string" || !profile2.log_public_key || typeof profile2.rp_id !== "string" || !profile2.rp_id || !allowedOrigins || !normDigest(profile2.expected_policy_hash) || !Number.isInteger(profile2.max_age_sec) || profile2.max_age_sec < 0 || !freshRegistrySnapshot(profile2, ctx?.verificationTime) || !contexts?.length || !signoffs?.length) {
        return { valid: false, action_digest: null, detail: { reason: "missing or malformed relying-party receipt profile" } };
      }
      const contextByHash = /* @__PURE__ */ new Map();
      try {
        for (const c of contexts) {
          if (!isRecord2(c) || normDigest(c.policy_hash) !== normDigest(profile2.expected_policy_hash)) {
            return { valid: false, action_digest: null, detail: { reason: "receipt context is outside the pinned policy" } };
          }
          contextByHash.set(sha256hex(canonicalize(c)), c);
        }
      } catch {
        return { valid: false, action_digest: null, detail: { reason: "receipt context is not canonicalizable" } };
      }
      const expectedRpHash = crypto10.createHash("sha256").update(profile2.rp_id, "utf8").digest();
      for (const s of signoffs) {
        const keyEntry = isRecord2(s) && own2(profile2.approver_keys, s.approver_key_id) ? profile2.approver_keys[s.approver_key_id] : null;
        const signedContext = contextByHash.get(normDigest(s?.context_hash) ?? "");
        let authData;
        try {
          authData = Buffer.from(s?.webauthn?.authenticator_data ?? "", "base64url");
        } catch {
          authData = null;
        }
        if (!activeDirectoryEntry(keyEntry, ctx?.verificationTime) || keyEntry.key_class !== "A" || !signedContext || keyEntry.approver_id !== signedContext.approver || !authData || authData.length < 37 || !authData.subarray(0, 32).equals(expectedRpHash) || !webauthnOrigin(s.webauthn) || !allowedOrigins.has(webauthnOrigin(s.webauthn)) || !freshAt(signedContext, ctx?.verificationTime, profile2.max_age_sec)) {
          return { valid: false, action_digest: null, detail: { reason: "receipt signoff is not a fresh pinned Class-A human ceremony" } };
        }
      }
      let r = {};
      try {
        r = verifyTrustReceipt(evidence, {
          approverKeys: profile2.approver_keys,
          logPublicKey: profile2.log_public_key,
          rpId: profile2.rp_id,
          allowedOrigins: [...allowedOrigins],
          expectedPolicyHash: profile2.expected_policy_hash
        }) || {};
      } catch {
        r = { valid: false };
      }
      return { valid: r.valid === true, action_digest: r.valid ? evidence.action_hash : null, detail: r.checks };
    }
  };
}
function tokenizeRequirement(expr) {
  if (typeof expr !== "string" || expr.length === 0 || expr.length > MAX_REQUIREMENT_LENGTH)
    return null;
  const toks = [];
  let i = 0;
  while (i < expr.length) {
    const ch = expr[i];
    if (ch === " " || ch === "	" || ch === "\r" || ch === "\n") {
      i++;
      continue;
    }
    if (ch === "(" || ch === ")") {
      toks.push(ch);
      i++;
    } else if (ch === "&" && expr[i + 1] === "&" || ch === "|" && expr[i + 1] === "|") {
      toks.push(ch + expr[i + 1]);
      i += 2;
    } else if (IDENT_CHAR.test(ch)) {
      let j = i + 1;
      while (j < expr.length && IDENT_CHAR.test(expr[j]))
        j++;
      toks.push(expr.slice(i, j));
      i = j;
    } else
      return null;
    if (toks.length > MAX_REQUIREMENT_TOKENS)
      return null;
  }
  return toks.length > 0 ? toks : null;
}
function evalRequirement(expr, satisfied) {
  const toks = tokenizeRequirement(expr);
  if (!toks)
    return { valid: false, value: false };
  let i = 0;
  const peek = () => toks[i];
  const eat = () => toks[i++];
  function parseExpr(depth = 0) {
    if (depth > MAX_REQUIREMENT_DEPTH)
      throw new Error("requirement nesting limit exceeded");
    let v = parseTerm(depth);
    while (peek() === "AND" || peek() === "OR" || peek() === "&&" || peek() === "||") {
      const op = eat();
      const r = parseTerm(depth);
      v = op === "AND" || op === "&&" ? v && r : v || r;
    }
    return v;
  }
  function parseTerm(depth) {
    if (peek() === "(") {
      eat();
      const v = parseExpr(depth + 1);
      if (peek() !== ")")
        throw new Error("unclosed requirement group");
      eat();
      return v;
    }
    const id = eat();
    if (id === void 0 || id === ")" || id === "AND" || id === "OR" || id === "&&" || id === "||" || !IDENT.test(id)) {
      throw new Error("invalid requirement term");
    }
    return satisfied.has(id);
  }
  try {
    const value = parseExpr();
    return { valid: i === toks.length, value: i === toks.length ? value === true : false };
  } catch {
    return { valid: false, value: false };
  }
}
var __aecSecurityInternals = Object.freeze({
  builtinVerifiers,
  isRecord: isRecord2,
  own: own2,
  sha256hex,
  normDigest,
  strictInstantMs,
  freshAt,
  freshRegistrySnapshot,
  activeDirectoryEntry,
  allowedOriginSet,
  webauthnOrigin,
  validUnicodeString: validUnicodeString2,
  boundedJson,
  tokenizeRequirement,
  evalRequirement
});

// ../../../../../private/tmp/emilia-ccs-aeb.TjuCWa/extracted/emilia-ccs-l1-aeb-e94314ab/packages/verify/dist/aeb-adapter-contract.js
var AEB_EVALUATION_VERSION = "AEB-EVALUATION-v1";
var AEB_EVALUATION_DOMAIN = `${AEB_EVALUATION_VERSION}\0`;
var AEB_NATIVE_VERIFICATION_ATTESTATION_VERSION = "EP-AEB-NATIVE-VERIFICATION-ATTESTATION-v1";
var AEB_NATIVE_VERIFICATION_ATTESTATION_DOMAIN = `${AEB_NATIVE_VERIFICATION_ATTESTATION_VERSION}\0`;
function canonicalize3(value) {
  return canonicalizeStrictJson(value);
}
function sha2563(value) {
  return `sha256:${crypto11.createHash("sha256").update(value).digest("hex")}`;
}
function digest(value) {
  return sha2563(Buffer.from(canonicalize3(value), "utf8"));
}
function profileDigest(id, pin) {
  return digest({
    profile_id: id,
    version: pin.version,
    definition: pin.definition ?? null,
    registry_entry_ref: pin.registry_entry_ref,
    mapper_id: pin.mapper_id,
    resolver: pin.resolver,
    semantic_equivalence: pin.semantic_equivalence
  });
}
function mappingProfileDigest(id, pin) {
  return profileDigest(id, pin);
}

// ../../../../../private/tmp/emilia-ccs-aeb.TjuCWa/extracted/emilia-ccs-l1-aeb-e94314ab/packages/verify/dist/aeb-ccs-adapter.js
import crypto12 from "node:crypto";
var CCS_L1_PYPI_DISTRIBUTION_VERSION = "1.1.14";
var CCS_L1_PYPI_SDIST_SHA256 = "9f75676e5b3d6ace8e91742d8b78b6d15b2d4250414326c17cc9e1aa361ec318";
var CCS_L1_PYPI_WHEEL_SHA256 = "04a7857253bac2fca25611d17280cebf92fd0a7a2987a4d7ece973d492b17c83";
var CCS_L1_REFERENCE_VECTOR_SHA256 = "5260e619c010d36729c57c5e8814613215e65e09abfba8a6a1d93f07e919762f";
var CCS_L1_PYPI_SOURCE_LOCK = "ccs-verifier-pypi-1.1.14-ed25519-l1";
var CCS_L1_AEB_ADAPTER_ID = "native:ccs-pypi-ed25519-l1-1.1.14";
var CCS_L1_AEB_ADAPTER_VERSION = "1";
var CCS_L1_AEB_CONFIG_VERSION = "AEB-CCS-PYPI-ED25519-CONFIG-v1";
var CCS_L1_AEB_TRUST_ROOT_VERSION = "AEB-CCS-PYPI-ED25519-ROOT-v1";
var CCS_L1_CAID_MAPPING_VERSION = "AEB-CCS-L1-TOOL-ACTION-MAPPING-v1";
var CCS_L1_CAID_MAPPER_ID = "mapper:ccs-pypi-l1-tool-action-v1";
var DIGEST_RE2 = /^sha256:[0-9a-f]{64}$/;
var IDENTIFIER_RE = /^[A-Za-z0-9][A-Za-z0-9._:/#@-]{0,511}$/;
var CCS_TOKEN_RE = /^[A-Za-z0-9][A-Za-z0-9._/-]{0,255}$/;
var ROLE_RE = /^[a-z][a-z0-9-]{0,127}$/;
var ACTION_TYPE_RE = /^[a-z][a-z0-9-]*(?:\.[a-z][a-z0-9-]*)+\.[1-9][0-9]*$/;
var SUBJECT_KEYS = /* @__PURE__ */ new Set(["id", "kind"]);
function isRecord3(value) {
  if (value === null || typeof value !== "object" || Array.isArray(value))
    return false;
  const prototype = Object.getPrototypeOf(value);
  return prototype === Object.prototype || prototype === null;
}
function exactKeys4(value, allowed) {
  const keys = Reflect.ownKeys(value);
  return keys.length === allowed.size && keys.every((key) => typeof key === "string" && allowed.has(key));
}
function validIdentifier(value) {
  return typeof value === "string" && IDENTIFIER_RE.test(value) && !/[\u0000-\u001f\u007f]/.test(value);
}
function validCcsToken(value) {
  return typeof value === "string" && CCS_TOKEN_RE.test(value);
}
function validText2(value) {
  return typeof value === "string" && value.length <= 4096 && !/[\u0000-\u0008\u000b\u000c\u000e-\u001f\u007f]/.test(value);
}
function safeInteger2(value) {
  return Number.isSafeInteger(value) && Number(value) >= 0;
}
function finiteNonNegative(value) {
  return typeof value === "number" && Number.isFinite(value) && value >= 0;
}
function sortedUniqueStrings2(value, predicate) {
  return Array.isArray(value) && value.length > 0 && value.every(predicate) && new Set(value).size === value.length;
}
function safeDigest(value) {
  try {
    return digest(value);
  } catch {
    return digest({ invalid_value: true });
  }
}
function sameDigest(left, right) {
  try {
    return digest(left) === digest(right);
  } catch {
    return false;
  }
}
function strictJsonClone(value) {
  try {
    return JSON.parse(canonicalize3(value));
  } catch {
    return null;
  }
}
function normalizeCcsInteropJson(value) {
  if (value === null || typeof value === "boolean")
    return value;
  if (typeof value === "string") {
    return /^[\x20-\x7e]*$/.test(value) ? value : void 0;
  }
  if (typeof value === "number") {
    return Number.isSafeInteger(value) ? value : void 0;
  }
  if (Array.isArray(value)) {
    const normalized = value.map(normalizeCcsInteropJson);
    return normalized.some((item) => item === void 0) ? void 0 : normalized;
  }
  if (isRecord3(value)) {
    const output = {};
    for (const key of Object.keys(value).sort()) {
      if (!/^[\x20-\x7e]+$/.test(key))
        return void 0;
      const normalized = normalizeCcsInteropJson(value[key]);
      if (normalized === void 0)
        return void 0;
      output[key] = normalized;
    }
    return output;
  }
  return void 0;
}
function statusDigest(status) {
  return safeDigest({
    checked_at: status?.checked_at,
    expires_at: status?.expires_at,
    revocation_checked: status?.revocation_checked,
    revoked: status?.revoked,
    consumed: status?.consumed,
    unavailable: status?.unavailable === true
  });
}
function statusDisposition(status, now) {
  const reasons = [];
  const nowMs = Date.parse(now);
  const checkedMs = Date.parse(status?.checked_at);
  const expiresMs = Date.parse(status?.expires_at);
  if (status?.unavailable === true)
    reasons.push("status_unavailable");
  if (status?.revocation_checked !== true)
    reasons.push("revocation_not_checked");
  if (status?.revoked === true)
    reasons.push("evidence_revoked");
  if (status?.consumed === true)
    reasons.push("evidence_consumed");
  if (!Number.isFinite(nowMs) || !Number.isFinite(checkedMs) || !Number.isFinite(expiresMs)) {
    reasons.push("status_time_invalid");
  } else {
    if (checkedMs > nowMs)
      reasons.push("status_checked_in_future");
    if (expiresMs <= nowMs)
      reasons.push("status_expired");
  }
  const unique = [...new Set(reasons)].sort();
  if (status?.revoked === true || status?.consumed === true || Number.isFinite(expiresMs) && expiresMs <= nowMs) {
    return { acceptance: "REJECTED", reasons: unique };
  }
  return unique.length === 0 ? { acceptance: "ACCEPTED", reasons: [] } : { acceptance: "INDETERMINATE", reasons: unique };
}
function combineAcceptance(left, right) {
  if (left === "REJECTED" || right === "REJECTED")
    return "REJECTED";
  if (left === "INDETERMINATE" || right === "INDETERMINATE")
    return "INDETERMINATE";
  return "ACCEPTED";
}
var CCS_L1_RECEIPT_KEYS = /* @__PURE__ */ new Set([
  "trace_id",
  "receipt_version",
  "verdict",
  "timestamp",
  "tool",
  "tool_call_id",
  "params_hash",
  "args_digest",
  "rule_summary",
  "rule_version",
  "request_hash",
  "response_hash",
  "runtime_context_hash",
  "config_hash",
  "verifier_source_class",
  "deployment_mode",
  "issuer",
  "audience",
  "nonce",
  "sequence",
  "issued_at",
  "expires_at",
  "max_clock_skew",
  "action",
  "signature",
  "signing_algorithm",
  "public_key_fingerprint",
  "public_key",
  "verified_at",
  "latency_us"
]);
var CCS_L1_CONFIG_KEYS = /* @__PURE__ */ new Set([
  "@version",
  "evidence_role",
  "subject",
  "issuer",
  "audience",
  "action_type",
  "allowed_actions",
  "allowed_tools",
  "required_rule_version",
  "max_receipt_age_seconds",
  "max_clock_skew_seconds",
  "deployment_scope"
]);
var CCS_L1_ROOT_KEYS = /* @__PURE__ */ new Set([
  "@version",
  "issuer",
  "key_id",
  "algorithm",
  "public_key_raw_base64",
  "public_key_fingerprint_sha256_16"
]);
var CCS_L1_ACTION_KEYS = /* @__PURE__ */ new Set(["action_type", "parameters"]);
var CCS_L1_ACTION_PARAMETER_KEYS = /* @__PURE__ */ new Set(["action", "tool", "arguments"]);
var CCS_L1_PROFILE_KEYS = /* @__PURE__ */ new Set([
  "version",
  "definition",
  "registry_entry_ref",
  "mapper_id",
  "resolver",
  "semantic_equivalence",
  "profile_digest"
]);
var CCS_L1_RESOLVER_KEYS = /* @__PURE__ */ new Set(["id", "version", "implementation_digest"]);
var CCS_L1_EQUIVALENCE_KEYS = /* @__PURE__ */ new Set([
  "assertion",
  "loss_policy",
  "omitted_material_fields",
  "omitted_nonmaterial_fields"
]);
var CCS_L1_MAPPING_PROFILE_ID = "ccs-l1-tool-action";
var CCS_L1_MAPPING_REGISTRY_REF = "mapping:ccs-l1-tool-action";
var CCS_L1_OMITTED_NONMATERIAL_FIELDS = Object.freeze([
  "trace_id",
  "timestamp",
  "tool_call_id",
  "params_hash",
  "rule_summary",
  "request_hash",
  "response_hash",
  "runtime_context_hash",
  "config_hash",
  "verifier_source_class",
  "deployment_mode",
  "nonce",
  "sequence",
  "issued_at",
  "expires_at",
  "max_clock_skew",
  "verified_at",
  "latency_us"
]);
var HEX_64_RE = /^[0-9a-f]{64}$/;
var HEX_FP16_RE = /^[0-9a-f]{16}$/;
var ED25519_SPKI_PREFIX = Buffer.from("302a300506032b6570032100", "hex");
function decodeCanonicalBase64(value, length) {
  if (typeof value !== "string" || !/^[A-Za-z0-9+/]*={0,2}$/.test(value) || value.length % 4 !== 0)
    return null;
  try {
    const decoded = Buffer.from(value, "base64");
    return decoded.length === length && decoded.toString("base64") === value ? decoded : null;
  } catch {
    return null;
  }
}
function strictFiniteJsonClone(value) {
  try {
    return JSON.parse(canonicalizeFiniteJson(value));
  } catch {
    return null;
  }
}
function validOptionalHash(value) {
  return value === "" || typeof value === "string" && HEX_64_RE.test(value);
}
function parseL1Receipt(value) {
  if (!isRecord3(value) || !exactKeys4(value, CCS_L1_RECEIPT_KEYS) || !validIdentifier(value.trace_id) || value.receipt_version !== "1.1" || !["allow", "deny", "escalate"].includes(String(value.verdict)) || !finiteNonNegative(value.timestamp) || !validCcsToken(value.tool) || !(value.tool_call_id === "" || validIdentifier(value.tool_call_id)) || !validText2(value.params_hash) || value.params_hash.length === 0 || typeof value.args_digest !== "string" || !HEX_64_RE.test(value.args_digest) || !validText2(value.rule_summary) || value.rule_summary.length === 0 || !validIdentifier(value.rule_version) || !validOptionalHash(value.request_hash) || !validOptionalHash(value.response_hash) || !validOptionalHash(value.runtime_context_hash) || !validOptionalHash(value.config_hash) || !validIdentifier(value.verifier_source_class) || !validIdentifier(value.deployment_mode) || !validIdentifier(value.issuer) || !validIdentifier(value.audience) || !validIdentifier(value.nonce) || !safeInteger2(value.sequence) || !finiteNonNegative(value.issued_at) || !finiteNonNegative(value.expires_at) || !finiteNonNegative(value.max_clock_skew) || !validIdentifier(value.action) || value.signing_algorithm !== "Ed25519" || typeof value.public_key_fingerprint !== "string" || !HEX_FP16_RE.test(value.public_key_fingerprint) || decodeCanonicalBase64(value.public_key, 32) === null || decodeCanonicalBase64(value.signature, 64) === null || !finiteNonNegative(value.verified_at) || !finiteNonNegative(value.latency_us))
    return null;
  return strictFiniteJsonClone(value);
}
function parseL1Config(value) {
  if (!isRecord3(value) || !exactKeys4(value, CCS_L1_CONFIG_KEYS) || value["@version"] !== CCS_L1_AEB_CONFIG_VERSION || typeof value.evidence_role !== "string" || !ROLE_RE.test(value.evidence_role) || !isRecord3(value.subject) || !exactKeys4(value.subject, SUBJECT_KEYS) || !validIdentifier(value.subject.id) || value.subject.kind !== "system" || !validIdentifier(value.issuer) || !validIdentifier(value.audience) || typeof value.action_type !== "string" || !ACTION_TYPE_RE.test(value.action_type) || !sortedUniqueStrings2(value.allowed_actions, validIdentifier) || !sortedUniqueStrings2(value.allowed_tools, validCcsToken) || !validIdentifier(value.required_rule_version) || !safeInteger2(value.max_receipt_age_seconds) || Number(value.max_receipt_age_seconds) === 0 || !safeInteger2(value.max_clock_skew_seconds) || value.deployment_scope !== "pinned-ed25519-issuer")
    return null;
  return strictJsonClone(value);
}
function parseL1Root(value, config) {
  if (!isRecord3(value) || !exactKeys4(value, CCS_L1_ROOT_KEYS) || value["@version"] !== CCS_L1_AEB_TRUST_ROOT_VERSION || value.issuer !== config.issuer || !validIdentifier(value.key_id) || value.algorithm !== "Ed25519" || typeof value.public_key_fingerprint_sha256_16 !== "string" || !HEX_FP16_RE.test(value.public_key_fingerprint_sha256_16))
    return null;
  const key = decodeCanonicalBase64(value.public_key_raw_base64, 32);
  if (!key)
    return null;
  const fingerprint = crypto12.createHash("sha256").update(key).digest("hex").slice(0, 16);
  if (fingerprint !== value.public_key_fingerprint_sha256_16)
    return null;
  const root = strictJsonClone(value);
  return root ? { root, key } : null;
}
function parseL1Pins(input) {
  const config = parseL1Config(input?.config);
  if (!config || !Array.isArray(input?.trust_roots) || input.trust_roots.length !== 1) {
    throw new TypeError("one valid relying-party-pinned CCS Ed25519 root is required");
  }
  const parsedRoot = parseL1Root(input.trust_roots[0], config);
  if (!parsedRoot)
    throw new TypeError("valid issuer-scoped CCS Ed25519 root required");
  return {
    config,
    root: parsedRoot.root,
    rootKey: parsedRoot.key,
    configDigest: digest(config),
    rootsDigest: digest(input.trust_roots)
  };
}
function l1SignatureValid(receipt) {
  const embedded = decodeCanonicalBase64(receipt.public_key, 32);
  const signature = decodeCanonicalBase64(receipt.signature, 64);
  if (!embedded || !signature)
    return false;
  const fingerprint = crypto12.createHash("sha256").update(embedded).digest("hex").slice(0, 16);
  if (fingerprint !== receipt.public_key_fingerprint)
    return false;
  let publicKey;
  try {
    publicKey = crypto12.createPublicKey({
      key: Buffer.concat([ED25519_SPKI_PREFIX, embedded]),
      format: "der",
      type: "spki"
    });
  } catch {
    return false;
  }
  const payload = { ...receipt };
  delete payload.signature;
  try {
    return crypto12.verify(null, Buffer.from(canonicalizeFiniteJson(payload), "utf8"), publicKey, signature);
  } catch {
    return false;
  }
}
function verifyL1Artifact(value, pins, now) {
  const receipt = parseL1Receipt(value);
  if (!receipt) {
    return { ok: false, verified: false, acceptance: "REJECTED", reason: "ccs:l1_artifact_malformed" };
  }
  if (!l1SignatureValid(receipt)) {
    return { ok: false, verified: false, acceptance: "REJECTED", reason: "ccs:l1_signature_invalid" };
  }
  const embedded = decodeCanonicalBase64(receipt.public_key, 32);
  if (!embedded || receipt.issuer !== pins.config.issuer || receipt.public_key_fingerprint !== pins.root.public_key_fingerprint_sha256_16 || embedded.length !== pins.rootKey.length || !crypto12.timingSafeEqual(embedded, pins.rootKey)) {
    return { ok: false, verified: true, acceptance: "REJECTED", reason: "ccs:l1_untrusted_signing_key" };
  }
  if (receipt.audience !== pins.config.audience) {
    return { ok: false, verified: true, acceptance: "REJECTED", reason: "ccs:l1_audience_mismatch" };
  }
  if (!pins.config.allowed_actions.includes(receipt.action)) {
    return { ok: false, verified: true, acceptance: "REJECTED", reason: "ccs:l1_action_not_pinned" };
  }
  if (!pins.config.allowed_tools.includes(receipt.tool)) {
    return { ok: false, verified: true, acceptance: "REJECTED", reason: "ccs:l1_tool_not_pinned" };
  }
  if (receipt.rule_version !== pins.config.required_rule_version) {
    return { ok: false, verified: true, acceptance: "REJECTED", reason: "ccs:l1_rule_version_mismatch" };
  }
  if (receipt.max_clock_skew > pins.config.max_clock_skew_seconds || receipt.expires_at <= receipt.issued_at || receipt.timestamp < receipt.issued_at || receipt.verified_at < receipt.issued_at || receipt.timestamp > receipt.expires_at + receipt.max_clock_skew || receipt.verified_at > receipt.expires_at + receipt.max_clock_skew) {
    return { ok: false, verified: true, acceptance: "REJECTED", reason: "ccs:l1_time_bounds_invalid" };
  }
  const nowSeconds = Date.parse(now) / 1e3;
  if (!Number.isFinite(nowSeconds)) {
    return { ok: false, verified: true, acceptance: "INDETERMINATE", reason: "ccs:l1_current_time_invalid" };
  }
  if (nowSeconds > receipt.expires_at + receipt.max_clock_skew) {
    return { ok: false, verified: true, acceptance: "REJECTED", reason: "ccs:l1_receipt_expired" };
  }
  if (receipt.issued_at > nowSeconds + receipt.max_clock_skew) {
    return { ok: false, verified: true, acceptance: "REJECTED", reason: "ccs:l1_receipt_not_yet_valid" };
  }
  if (nowSeconds - receipt.issued_at > pins.config.max_receipt_age_seconds) {
    return { ok: false, verified: true, acceptance: "REJECTED", reason: "ccs:l1_receipt_too_old" };
  }
  return {
    ok: true,
    value: {
      receipt,
      replayUnit: digest({
        source: CCS_L1_PYPI_SOURCE_LOCK,
        issuer: receipt.issuer,
        audience: receipt.audience,
        public_key_fingerprint: receipt.public_key_fingerprint,
        nonce: receipt.nonce,
        sequence: receipt.sequence,
        signature: receipt.signature
      })
    }
  };
}
function canonicalL1Action(value, actionType) {
  if (!isRecord3(value) || !exactKeys4(value, CCS_L1_ACTION_KEYS) || value.action_type !== actionType || !isRecord3(value.parameters) || !exactKeys4(value.parameters, CCS_L1_ACTION_PARAMETER_KEYS) || !validIdentifier(value.parameters.action) || !validCcsToken(value.parameters.tool))
    return null;
  const argumentsValue = normalizeCcsInteropJson(value.parameters.arguments);
  if (!isRecord3(argumentsValue))
    return null;
  return strictJsonClone({
    action_type: actionType,
    parameters: {
      action: value.parameters.action,
      tool: value.parameters.tool,
      arguments: argumentsValue
    }
  });
}
function l1ArgsDigest(value) {
  try {
    return crypto12.createHash("sha256").update(canonicalizeFiniteJson(value), "utf8").digest("hex");
  } catch {
    return null;
  }
}
function createCcsL1AebActionDefinition(actionType) {
  if (!ACTION_TYPE_RE.test(actionType))
    throw new TypeError("valid CAID action type required");
  return {
    "@version": CCS_L1_CAID_MAPPING_VERSION,
    source: CCS_L1_PYPI_SOURCE_LOCK,
    projection: "ccs-l1-signed-action-and-args-digest-v1",
    action_type: actionType,
    suite: "jcs-sha256",
    definitions: [{
      action_type: actionType,
      required_fields: [
        { name: "action_type", type: "string" },
        { name: "parameters", type: "object" }
      ],
      optional_fields: []
    }]
  };
}
function validL1MappingProfile(profile2, actionType) {
  const expectedResolverDigest = digest({
    implementation: CCS_L1_CAID_MAPPER_ID,
    version: "1"
  });
  if (!isRecord3(profile2) || !exactKeys4(profile2, CCS_L1_PROFILE_KEYS) || profile2.version !== CCS_L1_CAID_MAPPING_VERSION || profile2.registry_entry_ref !== CCS_L1_MAPPING_REGISTRY_REF || profile2.mapper_id !== CCS_L1_CAID_MAPPER_ID || !isRecord3(profile2.resolver) || !exactKeys4(profile2.resolver, CCS_L1_RESOLVER_KEYS) || profile2.resolver.id !== CCS_L1_CAID_MAPPER_ID || profile2.resolver.version !== "1" || profile2.resolver.implementation_digest !== expectedResolverDigest || !isRecord3(profile2.semantic_equivalence) || !exactKeys4(profile2.semantic_equivalence, CCS_L1_EQUIVALENCE_KEYS) || profile2.semantic_equivalence.assertion !== "EQUIVALENT_UNDER_PROFILE" || profile2.semantic_equivalence.loss_policy !== "NO_MATERIAL_FIELD_LOSS" || !Array.isArray(profile2.semantic_equivalence.omitted_material_fields) || profile2.semantic_equivalence.omitted_material_fields.length !== 0 || !Array.isArray(profile2.semantic_equivalence.omitted_nonmaterial_fields) || !sameDigest(profile2.semantic_equivalence.omitted_nonmaterial_fields, CCS_L1_OMITTED_NONMATERIAL_FIELDS) || !isRecord3(profile2.definition) || !Array.isArray(profile2.definition.definitions) || !sameDigest(profile2.definition, createCcsL1AebActionDefinition(actionType)) || profile2.profile_digest !== mappingProfileDigest(CCS_L1_MAPPING_PROFILE_ID, profile2))
    return null;
  return profile2.definition.definitions;
}
function fallbackL1(input, pins) {
  const evidenceDigest = safeDigest(input.artifact);
  return {
    native_verification: "FAILED",
    acceptance: "REJECTED",
    evidence_digest: evidenceDigest,
    status_digest: statusDigest(input.status),
    evidence_role: pins.config.evidence_role,
    subject: { ...pins.config.subject },
    replay_unit: evidenceDigest,
    reasons: []
  };
}
function createCcsPyPiL1AebAdapter(constructorPins) {
  const pins = parseL1Pins(constructorPins);
  return Object.freeze({
    id: CCS_L1_AEB_ADAPTER_ID,
    version: CCS_L1_AEB_ADAPTER_VERSION,
    verifyNative(input) {
      const result = fallbackL1(input, pins);
      try {
        if (safeDigest(input.adapter_config) !== pins.configDigest || safeDigest(input.trust_roots) !== pins.rootsDigest) {
          result.reasons = ["ccs:l1_constructor_pin_mismatch"];
          return result;
        }
        const verified = verifyL1Artifact(input.artifact, pins, input.now);
        if (!verified.ok) {
          result.native_verification = verified.verified ? "VERIFIED" : "FAILED";
          result.acceptance = verified.acceptance;
          result.reasons = [verified.reason];
          return result;
        }
        result.native_verification = "VERIFIED";
        result.replay_unit = verified.value.replayUnit;
        const status = statusDisposition(input.status, input.now);
        const decisionAcceptance = verified.value.receipt.verdict === "allow" ? "ACCEPTED" : verified.value.receipt.verdict === "deny" ? "REJECTED" : "INDETERMINATE";
        result.acceptance = combineAcceptance(decisionAcceptance, status.acceptance);
        result.reasons = [
          ...verified.value.receipt.verdict === "allow" ? [] : [`ccs:${verified.value.receipt.verdict}`],
          ...status.reasons
        ];
        return result;
      } catch {
        result.reasons = ["ccs:l1_unexpected_adapter_error"];
        return result;
      }
    },
    mapAction(input) {
      try {
        if (input.native.native_verification !== "VERIFIED" || input.native.acceptance !== "ACCEPTED") {
          return { mapping: "INDETERMINATE", caid: null, action_digest: null, reasons: ["native_acceptance_required"] };
        }
        if (safeDigest(input.adapter_config) !== pins.configDigest || safeDigest(input.trust_roots) !== pins.rootsDigest) {
          return { mapping: "INDETERMINATE", caid: null, action_digest: null, reasons: ["mapping_constructor_pin_mismatch"] };
        }
        const definitions = validL1MappingProfile(input.profile, pins.config.action_type);
        if (!definitions) {
          return { mapping: "INDETERMINATE", caid: null, action_digest: null, reasons: ["mapping_profile_invalid"] };
        }
        const verified = verifyL1Artifact(input.artifact, pins, input.now);
        if (!verified.ok || verified.value.receipt.verdict !== "allow") {
          return { mapping: "INDETERMINATE", caid: null, action_digest: null, reasons: ["accepted_allow_statement_required"] };
        }
        const expected = canonicalL1Action(input.expected_action, pins.config.action_type);
        if (!expected || !isRecord3(expected.parameters) || !isRecord3(expected.parameters.arguments)) {
          return { mapping: "INDETERMINATE", caid: null, action_digest: null, reasons: ["missing_or_ambiguous_exact_action"] };
        }
        const receipt = verified.value.receipt;
        const digest4 = l1ArgsDigest(expected.parameters.arguments);
        const semanticMatch = expected.parameters.action === receipt.action && expected.parameters.tool === receipt.tool && digest4 === receipt.args_digest;
        const actionDigest2 = digest(expected);
        if (!semanticMatch) {
          return { mapping: "MISMATCH", caid: null, action_digest: actionDigest2, reasons: ["exact_action_projection_mismatch"] };
        }
        let computed;
        try {
          computed = computeCaid(expected, { suite: "jcs-sha256", definitions });
        } catch {
          computed = null;
        }
        if (!isRecord3(computed) || typeof computed.caid !== "string" || typeof computed.digest !== "string" || !DIGEST_RE2.test(computed.digest) || computed.digest !== actionDigest2) {
          return { mapping: "INDETERMINATE", caid: null, action_digest: null, reasons: ["caid_mapping_failed"] };
        }
        return { mapping: "MATCH", caid: computed.caid, action_digest: actionDigest2, reasons: [] };
      } catch {
        return { mapping: "INDETERMINATE", caid: null, action_digest: null, reasons: ["ccs:l1_unexpected_mapping_error"] };
      }
    }
  });
}

// ../../../../../private/tmp/emilia-ccs-aeb.TjuCWa/extracted/emilia-ccs-l1-aeb-e94314ab/conformance/composition/ccs-l1-aeb-v1/run.mjs
var HERE = dirname(fileURLToPath(import.meta.url));
var ROOT = resolve(HERE, "../../..");
var REPORT_PATH = resolve(HERE, "report.reference.json");
var FIXTURE_PATH = resolve(ROOT, "interop/ccs-aeb/fixtures/ccs-verifier-pypi-1.1.14-reference-signed-001.json");
var ACTION_TYPE = "agent.tool-invocation.1";
var NOW = "2030-01-01T00:02:00Z";
function canonical(value) {
  if (Array.isArray(value))
    return `[${value.map(canonical).join(",")}]`;
  if (value !== null && typeof value === "object") {
    return `{${Object.keys(value).sort().map((key) => `${JSON.stringify(key)}:${canonical(value[key])}`).join(",")}}`;
  }
  return JSON.stringify(value);
}
function sha2564(value) {
  return `sha256:${crypto13.createHash("sha256").update(value).digest("hex")}`;
}
function fileSha256(path) {
  return crypto13.createHash("sha256").update(readFileSync(path)).digest("hex");
}
function check(id, layer, description, passed, observed) {
  return { id, layer, description, passed, observed };
}
function profile() {
  const pin = {
    version: CCS_L1_CAID_MAPPING_VERSION,
    definition: createCcsL1AebActionDefinition(ACTION_TYPE),
    registry_entry_ref: "mapping:ccs-l1-tool-action",
    mapper_id: CCS_L1_CAID_MAPPER_ID,
    resolver: {
      id: CCS_L1_CAID_MAPPER_ID,
      version: "1",
      implementation_digest: digest({ implementation: CCS_L1_CAID_MAPPER_ID, version: "1" })
    },
    semantic_equivalence: {
      assertion: "EQUIVALENT_UNDER_PROFILE",
      loss_policy: "NO_MATERIAL_FIELD_LOSS",
      omitted_material_fields: [],
      omitted_nonmaterial_fields: [
        "trace_id",
        "timestamp",
        "tool_call_id",
        "params_hash",
        "rule_summary",
        "request_hash",
        "response_hash",
        "runtime_context_hash",
        "config_hash",
        "verifier_source_class",
        "deployment_mode",
        "nonce",
        "sequence",
        "issued_at",
        "expires_at",
        "max_clock_skew",
        "verified_at",
        "latency_us"
      ]
    },
    profile_digest: digest(null)
  };
  pin.profile_digest = mappingProfileDigest("ccs-l1-tool-action", pin);
  return pin;
}
function buildFixture() {
  const vector = JSON.parse(readFileSync(FIXTURE_PATH, "utf8"));
  const config = {
    "@version": CCS_L1_AEB_CONFIG_VERSION,
    evidence_role: "machine-policy-decision",
    subject: { id: "system:ccs-reference-verifier", kind: "system" },
    issuer: "ccs-verifier/reference",
    audience: "public",
    action_type: ACTION_TYPE,
    allowed_actions: ["shell.execute"],
    allowed_tools: ["shell"],
    required_rule_version: "1.1.14",
    max_receipt_age_seconds: 300,
    max_clock_skew_seconds: 5,
    deployment_scope: "pinned-ed25519-issuer"
  };
  const root = {
    "@version": CCS_L1_AEB_TRUST_ROOT_VERSION,
    issuer: config.issuer,
    key_id: "ccs-reference-ed25519-1",
    algorithm: "Ed25519",
    public_key_raw_base64: vector.public_key_raw_b64,
    public_key_fingerprint_sha256_16: vector.public_key_fingerprint_sha256_16
  };
  const action = {
    action_type: ACTION_TYPE,
    parameters: {
      action: "shell.execute",
      tool: "shell",
      arguments: { command: "echo reference" }
    }
  };
  const status = {
    checked_at: NOW,
    expires_at: "2030-01-01T00:04:00Z",
    revocation_checked: true,
    revoked: false,
    consumed: false
  };
  const adapter = createCcsPyPiL1AebAdapter({ config, trust_roots: [root] });
  const input = {
    artifact: structuredClone(vector.receipt),
    artifact_ref: "ccs:l1:reference-signed-001",
    status,
    trust_roots: [root],
    adapter_config: config,
    expected_action: action,
    now: NOW
  };
  return { vector, config, root, action, adapter, input, profile: profile() };
}
function runSuite() {
  const f = buildFixture();
  const native = f.adapter.verifyNative(f.input);
  const mapping = f.adapter.mapAction({ ...f.input, profile: f.profile, native });
  const signatureTamper = structuredClone(f.input.artifact);
  signatureTamper.signature = `${signatureTamper.signature[0] === "A" ? "B" : "A"}${signatureTamper.signature.slice(1)}`;
  const invalidSignature = f.adapter.verifyNative({ ...f.input, artifact: signatureTamper });
  const expired = f.adapter.verifyNative({ ...f.input, now: "2030-01-01T00:05:01Z" });
  const unavailable = f.adapter.verifyNative({
    ...f.input,
    status: { ...f.input.status, unavailable: true }
  });
  const substitutedAction = {
    ...f.action,
    parameters: { ...f.action.parameters, arguments: { command: "echo substituted" } }
  };
  const substitutedMapping = f.adapter.mapAction({
    ...f.input,
    expected_action: substitutedAction,
    profile: f.profile,
    native
  });
  const wrongKey = Buffer.alloc(32, 7);
  const wrongRoot = {
    ...f.root,
    public_key_raw_base64: wrongKey.toString("base64"),
    public_key_fingerprint_sha256_16: crypto13.createHash("sha256").update(wrongKey).digest("hex").slice(0, 16)
  };
  const wrongRootAdapter = createCcsPyPiL1AebAdapter({ config: f.config, trust_roots: [wrongRoot] });
  const untrusted = wrongRootAdapter.verifyNative({
    ...f.input,
    trust_roots: [wrongRoot]
  });
  const checks = [
    check("CCS-1.1.14-SOURCE-PIN", "CCS", "The exact published PyPI 1.1.14 release and reference vector are pinned.", f.vector.package_version === CCS_L1_PYPI_DISTRIBUTION_VERSION && fileSha256(FIXTURE_PATH) === CCS_L1_REFERENCE_VECTOR_SHA256, {
      distribution: f.vector.package_version,
      source_lock: CCS_L1_PYPI_SOURCE_LOCK,
      vector_sha256: fileSha256(FIXTURE_PATH)
    }),
    check("CCS-1.1.14-ED25519-ACCEPT", "CCS", "The reference L1 signature verifies and its issuer key is accepted only under the relying-party pin.", native.native_verification === "VERIFIED" && native.acceptance === "ACCEPTED", { verification: native.native_verification, acceptance: native.acceptance }),
    check("CCS-1.1.14-SIGNATURE-TAMPER", "CCS", "A signature mutation is refused before semantic mapping.", invalidSignature.native_verification === "FAILED", invalidSignature),
    check("CCS-1.1.14-UNTRUSTED-ISSUER", "CCS", "A self-consistent receipt not matching the relying-party key pin is rejected.", untrusted.native_verification === "VERIFIED" && untrusted.acceptance === "REJECTED", untrusted),
    check("CCS-1.1.14-EXPIRY", "CCS", "A correctly signed receipt past expires_at is rejected.", expired.native_verification === "VERIFIED" && expired.acceptance === "REJECTED", expired),
    check("AEB-EXACT-ACTION-MAP", "AEB", "The signed CCS action, tool, and full args_digest map to one executor-constructed CAID.", mapping.mapping === "MATCH", mapping),
    check("AEB-ACTION-SUBSTITUTION", "AEB", "Changing the executor action arguments produces MISMATCH.", substitutedMapping.mapping === "MISMATCH", substitutedMapping),
    check("AEB-STATUS-UNAVAILABLE", "AEB", "Unavailable authenticated status remains INDETERMINATE.", unavailable.native_verification === "VERIFIED" && unavailable.acceptance === "INDETERMINATE", unavailable)
  ];
  const report = {
    "@version": "CCS-L1-AEB-COMPOSITION-REPORT-v1",
    profile: "ccs-l1-aeb-v1",
    pins: {
      ccs_distribution: CCS_L1_PYPI_DISTRIBUTION_VERSION,
      ccs_sdist_sha256: CCS_L1_PYPI_SDIST_SHA256,
      ccs_wheel_sha256: CCS_L1_PYPI_WHEEL_SHA256,
      ccs_reference_vector_sha256: CCS_L1_REFERENCE_VECTOR_SHA256,
      ccs_source_lock: CCS_L1_PYPI_SOURCE_LOCK,
      adapter_id: CCS_L1_AEB_ADAPTER_ID,
      adapter_version: CCS_L1_AEB_ADAPTER_VERSION,
      mapping_profile_digest: f.profile.profile_digest
    },
    checks,
    passed: checks.every((entry) => entry.passed),
    known_limits: [
      "The reference signing seed and key are public test material and are not a production trust anchor.",
      "CCS supplies machine-policy-decision evidence, not human authorization, provider admission, or effect proof.",
      "AEB reconstructs the exact action from the executor and checks the signed action, tool, and args_digest; it does not trust an action string as a CAID.",
      "A passing report reproduces the EMILIA reference adapter and is not independent implementation, deployment, certification, IETF adoption, or endorsement."
    ],
    implementation_status_markdown: `The runner reproduced ${checks.filter((entry) => entry.passed).length}/${checks.length} source-locked CCS 1.1.14 to AEB checks. It verified the pinned Ed25519 L1 receipt and mapped its signed action, tool, and full argument digest to one executor-constructed CAID. This is a reproduction of the EMILIA reference adapter, not an independent implementation or IETF endorsement.`
  };
  report.report_digest = sha2564(canonical(report));
  return report;
}
function main() {
  const report = runSuite();
  const rendered = `${JSON.stringify(report, null, 2)}
`;
  if (process.argv.includes("--write"))
    writeFileSync(REPORT_PATH, rendered);
  if (process.argv.includes("--check")) {
    const expected = readFileSync(REPORT_PATH, "utf8");
    if (expected !== rendered) {
      console.error("CCS L1 to AEB reference report is stale");
      process.exitCode = 1;
    }
  }
  console.log(rendered.trimEnd());
  if (report.passed !== true)
    process.exitCode = 1;
}
if (process.argv[1] && resolve(process.argv[1]) === fileURLToPath(import.meta.url))
  main();
export {
  runSuite
};
/**
 * @emilia-protocol/verify — Checkpoint CONSISTENCY proofs
 *
 * Wired into verifyTrustReceipt() as the OPT-IN `opts.priorCheckpoint` knob
 * (checks.consistency, fail-closed). Also exported directly from index.js for
 * log tooling and witnesses.
 *
 * This module addresses the DoD-audit MED-HIGH transparency finding: a trust
 * receipt today carries a SINGLE-signer checkpoint {log_key_id, root_hash,
 * tree_size, log_signature} and NO append-only (consistency) proof between
 * checkpoints. A malicious log operator can therefore present two different,
 * internally-consistent histories to two verifiers (a "split view" /
 * equivocation) and neither can detect it offline. See
 * docs/security/TRANSPARENCY-LAYER-DESIGN.md for the full threat + fix design.
 *
 * A consistency proof (RFC 6962 §2.1.2 / RFC 9162 §2.1.4) proves that the log
 * of size `newSize` with root `newRoot` is an APPEND-ONLY extension of the log
 * of size `oldSize` with root `oldRoot` — i.e. nothing already committed was
 * removed or rewritten. Combined with witness cosignatures + gossip (see the
 * design doc), it converts "the operator's word" into a cryptographically
 * enforced, non-equivocable history.
 *
 * DOMAIN SEPARATION: this uses the EP-MERKLE-v2 branch construction
 * (SHA-256(0x01 || left || right), hex) so it composes with the v2 inclusion
 * proofs already verified by verifyMerkleAnchor(..., { v2: true }) in index.js.
 * It stays standalone (no imports from index.js) so it can also be used alone.
 *
 * HONESTY: a consistency proof shows append-only extension between two
 * OBSERVED heads. It does NOT establish currency or split-view honesty by
 * itself — that needs independent witnesses + gossip (see the design doc).
 *
 * @license Apache-2.0
 */
/**
 * @emilia-protocol/verify — WITNESS COSIGNATURE verification (EP-WITNESS-v1)
 *
 * Step 3 of the transparency layer (see docs/security/TRANSPARENCY-LAYER-DESIGN.md
 * and consistency.js). A transparency-log operator signs its own checkpoint
 * {tree_size, root_hash, log_key_id, ...}. A single operator signature does NOT
 * make a split view (equivocation) detectable: the operator can sign two
 * internally-consistent but divergent heads and show each to a different
 * verifier. An INDEPENDENT WITNESS re-signs the SAME committed checkpoint bytes.
 * When several independent witnesses each cosign whatever head they observed,
 * two verifiers who later gossip their witness cosignatures can detect that the
 * log presented divergent heads at the same tree_size.
 *
 * WHAT A WITNESS COSIGNATURE PROVES
 *   "I, witness <witness_id>, observed a checkpoint claiming this tree_size and
 *    this root_hash under this log_key_id, and I attest to having seen exactly
 *    these committed bytes."
 *
 * WHAT IT DOES *NOT* PROVE (honesty)
 *   - It does NOT vouch for the log's honesty or that the log is append-only. A
 *     witness signs the bytes it was shown; it does not re-derive the tree.
 *   - It does NOT establish CURRENT validity. A cosignature attests to a head as
 *     OBSERVED at cosign time only; currency needs a fresh signed head / online
 *     check, exactly as for the log's own signature.
 *   - A SINGLE witness detects nothing. Equivocation is only detectable when
 *     multiple INDEPENDENT witnesses cosign and their views are later compared
 *     (gossip). requireWitnessQuorum() enforces the "multiple distinct pinned
 *     witnesses agree on ONE head" half of that; cross-view gossip is the
 *     deployment's job.
 *
 * DOMAIN SEPARATION (critical)
 *   The log signs   Ed25519( null, SHA-256( canonicalize(signedCheckpoint) ) ).
 *   A witness signs  Ed25519( null, SHA-256( WITNESS_DOMAIN_TAG || canonicalize(signedCheckpoint) ) ).
 *   `signedCheckpoint` is the checkpoint with its own `log_signature` removed —
 *   i.e. the identical committed bytes the log signed. Prepending the domain tag
 *   to the pre-image means a witness cosignature and a log signature are
 *   computed over DIFFERENT bytes and can never be confused or replayed for one
 *   another, even if (by misconfiguration) the same key were pinned in both
 *   roles. Byte-identical convention used by witness/server.mjs.
 *
 * KEY / HASH ENCODING (matches index.js exactly)
 *   - Public keys: base64url-encoded SPKI DER, verified with crypto.verify(null,…).
 *   - Signatures:  base64url.
 *   - Hashes in the checkpoint: "sha256:<hex>" or bare hex; compared prefix-stripped.
 *
 * FAIL-CLOSED
 *   Every check refuses on missing / malformed / unrecognized input and never
 *   silently passes. An unknown or unpinned witness key refuses. A signature over
 *   different bytes refuses. A cosignature presented for a different checkpoint
 *   (different tree_size / root_hash / log_key_id than the one being verified)
 *   refuses. The k-of-n helper refuses on fewer than k DISTINCT pinned witnesses.
 *
 * This module imports canonicalize() from index.js so the witness and every other
 * signed-material computation in the package share one canonicalization source of
 * truth. It adds NO new canonicalization.
 *
 * @license Apache-2.0
 */
/**
 * @emilia-protocol/verify — THIRD-PARTY-verifiable one-time CONSUMPTION proofs
 * (sparse-Merkle-over-nonce consumption profile). EXPERIMENTAL / additive.
 *
 * THE PROBLEM THIS CLOSES. A trust receipt's `consumption` block today is an
 * OPERATOR ASSERTION: the operator says "I committed this nonce once." Nothing
 * in the receipt makes double-spend of a nonce detectable OFFLINE. A malicious
 * operator can commit the SAME nonce twice and hand each relying party a receipt
 * that verifies in isolation; catching it needs an ONLINE audit that walks the
 * whole log. This profile replaces the assertion with a proof: the operator must
 * maintain a sparse Merkle tree keyed by nonce, and produce, at commit time, a
 * proof that the nonce transitioned ABSENT -> PRESENT exactly once between two
 * WITNESSED log heads. A second commit of the same nonce cannot also exhibit a
 * valid absent-at-h1 proof under the same append-only log, so double-consumption
 * becomes offline-detectable by any third party holding these two heads.
 *
 * WHAT A CONSUMPTION BUNDLE PROVES (all three, conjunctively, fail-closed):
 *   (a) NON-INCLUSION at head h1: the nonce's leaf held the DEFAULT (empty)
 *       value at h1  -> the nonce was not yet consumed as of h1.
 *   (b) INCLUSION at head h2: the same nonce's leaf holds the PRESENT marker at
 *       h2  -> the nonce is consumed as of h2.
 *   (c) APPEND-ONLY h1 -> h2: h2 is a consistency-proven extension of h1 (reuses
 *       verifyCheckpointConsistency from consistency.js — the SAME EP-MERKLE-v2
 *       branch construction; this module does NOT invent a second Merkle scheme).
 * Together: the nonce went absent -> present exactly once between two heads that
 * are provably the same append-only log. There is no valid bundle in which the
 * nonce is BOTH absent-at-h1 under this log AND was already consumed earlier.
 *
 * HONESTY / SCOPE (this is a house rule, stated in code on purpose):
 *   - This module ships BOTH sides at reference level: the VERIFIER
 *     (`verifyConsumptionProof`) and the reference issuer-side EMITTER
 *     (`ReferenceConsumptionTree`, exported). The emitter maintains a sparse
 *     consumption tree, inserts a nonce leaf, and PRODUCES the non-inclusion /
 *     inclusion sub-proofs in the exact wire format the verifier accepts, so a
 *     third party can reproduce a bundle, not only check one. It is a
 *     spec-faithful REFERENCE that pins the wire format; a production issuer
 *     emits byte-equivalent proofs from its own ledger. The reference emitter is
 *     NOT itself a production consumption ledger (in-memory present set, roots
 *     recomputed by DFS). Running an independent issuer/log is deployment.
 *   - Offline verification of a bundle establishes append-only consistency
 *     between two OBSERVED heads. It does NOT establish CURRENCY (that h2 is the
 *     log's latest head) and does NOT by itself defeat split-view equivocation
 *     (a log showing different histories to different verifiers). Currency and
 *     non-equivocation need a fresh signed head plus independent witnesses /
 *     gossip. See docs/security/TRANSPARENCY-LAYER-DESIGN.md.
 *   - The sparse-tree construction here binds VALUES to leaves. It does NOT by
 *     itself verify the two checkpoints' log SIGNATURES; that is the caller's
 *     job (verifyTrustReceipt checks checkpoint_signature). This function proves
 *     the tree-shaped facts; pass it roots you have independently authenticated.
 *
 * DOMAIN SEPARATION (reuses EP-MERKLE-v2 branch bytes; adds distinct LEAF bytes):
 *   - Branch  = SHA-256(0x01 || leftHex || rightHex) -> hex   [SAME as EP-MERKLE-v2]
 *   - PRESENT leaf = SHA-256(0x02 || keyHex || valueHex) -> hex   [EP-SMT-CONSUME-v1]
 *   - DEFAULT leaf = SHA-256(0x03) -> hex (the empty-subtree/absent marker)
 *   Distinct 0x02 (present) and 0x03 (default) leaf domains mean a DEFAULT leaf
 *   can never be reinterpreted as a PRESENT leaf at the same key, and neither can
 *   collide with a dense-log leaf (0x00) or a branch (0x01). The empty-subtree
 *   marker at every level is derived by folding DEFAULT leaves up with the SAME
 *   0x01 branch rule, so a non-inclusion proof and an inclusion proof share one
 *   hash construction end to end.
 *
 * SPARSE-MERKLE SHAPE. Fixed depth D (default SMT_DEPTH). The key path is the
 * top D bits of SHA-256(nonce), MSB first (bit i selects left=0/right=1 at level
 * i from the root). Each proof is D sibling hashes, root-to-leaf order. A leaf is
 * PRESENT (value = SHA-256 of the nonce commitment content) or DEFAULT (absent).
 *
 * @license Apache-2.0
 */
/**
 * @emilia-protocol/verify — Federation (PIP-006)
 *
 * Operator-B cross-operator verification client.
 *
 * PIP-006 defines the minimal contract that lets an EP-RECEIPT-v1 issued by
 * Operator A be verified by an independent Operator B using only A's published
 * discovery surfaces — no shared database, no central authority, no trust in
 * A's policy decisions. This module is the relying-party (Operator B) side of
 * that contract.
 *
 * Cross-operator semantics (PIP-006 §"Cross-operator semantics"). Given a
 * receipt from Operator A, Operator B MUST:
 *   1. Resolve A's verification key from A's /.well-known/ep-keys.json
 *      (current key, or a historical key if the receipt predates a rotation).
 *   2. Verify the Ed25519 signature over the canonical receipt payload.
 *   3. Confirm the receipt is not in A's revocation set.
 *   4. Apply B's *local* trust policy to the verified receipt.
 *
 * This module performs steps 1–3 and returns the evidence, and it enforces the
 * decisive part of step 4: a receipt is only ever `accepted` when the relying
 * party has independently, out-of-band, pinned the issuing operator.
 *
 * TRUST ANCHOR — fail closed. `verified` and `accepted` are DIFFERENT verdicts:
 *   - `verified` = the signature checks out against a key the receipt's own
 *     discovery surface advertises. This proves the payload was signed by
 *     whoever controls `signature.signer`'s key — nothing more.
 *   - `accepted` = the relying party trusts that signer. This decision MUST be
 *     anchored in a caller-supplied, out-of-band trust source (a pinned issuer
 *     allowlist and/or an expectedSigner and/or a pinned key set). It is NEVER
 *     derived solely from fields the receipt carries.
 *
 * The receipt-carried `signature.signer` and `signature.key_discovery` are
 * ATTACKER-CONTROLLED. An attacker can mint a receipt with their own key, host
 * a matching ep-keys.json at a URL they control, and point key_discovery there.
 * Such a receipt will `verify` (its signature is internally consistent) but it
 * must NEVER `accept` unless the relying party has already pinned that issuer.
 *
 * PINNING THE ID IS NOT ENOUGH — PIN THE KEY SOURCE. A bare signer-id pin does
 * not authenticate WHERE the verifying key comes from. The receipt still names
 * the discovery URL, so an attacker who sets `signature.signer` to a pinned id
 * and points `key_discovery` at their own ep-keys.json (advertising THEIR key
 * under the pinned id) would otherwise verify-and-accept — laundering trust
 * through a pinned string. To close this, a pin MUST bind the key SOURCE for
 * that signer: an expected discovery origin/URL and/or a pinned public key. A
 * receipt-supplied key_discovery is honored ONLY when its origin matches what
 * the relying party pinned for that signer (online), and a matched key is
 * accepted ONLY when it is the pinned key, if one was pinned (online + offline).
 * A caller-supplied opts.keyDiscoveryUrl is the relying party's OWN choice and
 * needs no such origin match. A receipt-carried key_discovery URL is at most a
 * *hint*: it is only fetched when the signer is pinned AND its origin is bound,
 * and every such fetch is routed through an SSRF guard (see assertSafeFetchUrl).
 *
 * "Federation enables receipt portability. It does not enable trust
 * laundering." — PIP-006.
 *
 * Zero runtime dependencies. Works fully offline when the caller supplies the
 * discovery document and revocation set. Online verification requires a
 * caller-provided resolver + pinned transport boundary; a plain injected or
 * global fetch cannot prevent DNS rebinding and is never treated as safe.
 *
 * @license Apache-2.0
 */
/**
 * @emilia-protocol/verify — Zero-Dependency Trust Verification
 *
 * Verify EP trust receipts, Merkle anchors, and commitment proofs
 * using ONLY Node.js built-in crypto. No EP infrastructure required.
 *
 * This is the core primitive that makes EP a protocol, not an API.
 * Anyone can verify. No account. No API key. Just math.
 *
 * @license Apache-2.0
 */
