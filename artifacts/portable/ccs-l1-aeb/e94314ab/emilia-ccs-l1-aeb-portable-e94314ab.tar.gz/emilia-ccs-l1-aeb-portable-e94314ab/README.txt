EMILIA CCS 1.1.14 to AEB portable reproduction bundle

Source commit:
e94314ab2e6979aba271afae61f645b6c035faa8

Run from this directory with Node.js 20 or newer:

  npm test

No npm install or external dependency is required. The readable bundled
runtimes contain the exact JavaScript dependency graph needed by the profile.
The original TypeScript runner sources, fixture, and report.reference.json are
included alongside them.

Expected result:

  2 tests pass
  8 profile checks pass
  report.reference.json is byte-identical to deterministic output

This bundle is a transport convenience for independent reproduction. The
source commit above remains the source of truth.
